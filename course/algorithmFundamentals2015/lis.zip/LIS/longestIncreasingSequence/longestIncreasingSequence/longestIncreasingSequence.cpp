//6.11.1 (pr1.3) longestIncreasingSequence for students, if you detect bugs,please email me to szhou@ustc.edu.cn

#include "stdafx.h"
#include "windows.h"
#include <vector>
#include <set>
#include <iostream>
#include <iterator>
#include "cppHelper.h"
using namespace std;

template<class T>
vector<T> LIS(const vector<T>& S){
	vector< vector<T> > bis;
	ForIndex(i,S.size())
	{
		int j;
		for (j=bis.size()-1; j>=0; j--)
		{
			if( S[i]>bis[j].back() ){
				if(j==bis.size()-1) bis.push_back(vector<T>()); //�����һ��BIS����������Ҫ�½�һ��
				bis[j+1] = bis[j];
				bis[j+1].push_back(S[i]);
				break;
			}
		}
		if(j==-1){
			if(bis.size()==0)
				bis.push_back(vector<T>(1, S[i]));
			else
				bis.front().front()= S[i];
		}
		ForIndex(i, bis.size()){
			std::copy(bis[i].begin(), bis[i].end(),std::ostream_iterator<T>(std::cout,", ")); std::cerr<<"\n";
		}
		std::cerr<<"\n";
		std::cerr<<"\n";
	}
	return bis.back();
}

int _tmain(int argc, _TCHAR* argv[])
{
	vector<int> S;
	srand(GetTickCount());
	for (int i=0; i<8; i++){
		S.push_back(Random(10,30));
	}

	std::copy(S.begin(), S.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
	vector<int> lis = LIS(S);
	std::cerr<<"the longest increasing subsequence \n";
	std::copy(lis.begin(), lis.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
	int y;
	scanf("%d", &y);
	return 0;
}