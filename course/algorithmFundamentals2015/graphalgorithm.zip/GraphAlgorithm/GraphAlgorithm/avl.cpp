#include "stdafx.h"
#include "bst.h"
#include "avl.h"
#include "windows.h"
#include "math.h"
using namespace _BINARY_TREE;


bool draw_bst(false);

bool worst_case = false; //average case if false;
avlTree<int> avl;
bstTree<int> bst;

int N = 10000;
int tN= 50000;
int *sample = new int[N];

void makeSample(){
	if(worst_case){
		for (int i=0; i<N; i++)	sample[i] = i;
	}
	else{
		srand(GetTickCount());
		for (int i=0; i<N; i++)	sample[i] = rand();
	}
}

void init2Trees()
{
	bst.clear();
	avl.clear();
	for (int i=0; i<N; i++)
	{
		bst.insert(sample[i]);
		avl.insert(sample[i]);
	}
}

#include "c:\Lib\glut\include\GL\glut.h"

void printString(char *s);
void init(void);

void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho (0.0, w, 0.0, h, -1.0, 1.0);
   glMatrixMode(GL_MODELVIEW);
}

GLfloat white[3] = { 1.0, 1.0, 1.0 };
GLfloat blue[3] = {  0.0, 0.0, 1.0 };
void display(void)
{	
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3fv(blue);
	glRasterPos2f(20, 40);
	printString("PRESS A TO BUILD NEW TREE");
	glRasterPos2f(20, 20);
	printString("PRESS B TO SHOW AVL OR BST");

	glColor3fv(white);	
	if(draw_bst)
		bst.draw();
	else
		avl.draw();
	glFlush ();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'a':
		makeSample();
		init2Trees();
		glutPostRedisplay();
		break;
	case 'b':
		draw_bst = !draw_bst ;
		glutPostRedisplay();
		break;
	}
}
#define  DO_DRAW 1

void performance();
void useBTree(int argc, char** argv)
{
	performance();
	init2Trees();
#if DO_DRAW
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE| GLUT_RGB);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition (100, 100);
	glutCreateWindow("DRAW TREE");
 	init();
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutSwapBuffers();
	glutMainLoop();
#endif 
	delete[] sample;
	avl.clear();
	bst.clear();
}