/*simple graph class for students:  Di/Undi-graph. (some algo could work for multigraph, but NOT for graph with self-pointing edges !) */
#pragma  once
#pragma warning(disable:4800)
#include <vector>
#include <queue>
#include "cppHelper.h"
#include "heap.h"
#include "tree.h"
#include "gltools.h"
#include "stringify.h"
#include <map>
#include <list>
#include "assert.h"
namespace _GRAPH{

#undef max 
#undef min 
using namespace std;
template<class NodeType, class _dT> class Edge;
static bool gDrawCoords = false;
class Node{
	typedef Edge<Node, float> EDGE;
public:
	char name;
	bool visited;
	int order;
	int high;
	int outDegree, inDegree;
	float x, y;
	Node* parent;
	std::vector<EDGE*>	e_in, e_out;
	float color[3];
	int compo;
	bool on_the_path;
	Node(){
		visited = false;
		name = ' ';
		order= -1;
		high = 9999;
		compo  = -1;
	}
	void print(){
		printf("[%c", name);
		//printf(" at order %d]", order);
		//printf("h %d", high);
		printf("\t");
	}
	void draw(){
		if(compo==-1)
			glColor3f(1,1,1);
 		else
			glColor3f(color[0], color[1], color[2]);
		
		glPointSize(15);
		glBegin(GL_POINTS);
		glVertex2f(x,y);
		glEnd();
		glColor3f(1,0,0);
		glPrintString(&name, x+10,y+10);
		glColor3f(1,1,0);
		glPrintInt(order, x+25,y+10);

		if(gDrawCoords){			
			glColor3f(0.5, 0.5, 0);
			string sx = "[" + stringify(x) + "," + stringify(y) + "]";
			glPrintString(sx, x+40, y);
		}
	}
	float dist(float dx, float dy){
		return sqrt((x-dx)*(x-dx)+(y-dy)*(y-dy));
	}
	void setXY(float xx, float yy){
		x = xx; y=yy;
	}
};

static const float arrow_len = 30;

template<class NodeType, class _dT>
class Edge{
public:
	Edge(NodeType *_from, NodeType *_to, _dT _w = 0){
		from = _from;
		to = _to;
		weight = _w;
		visited = false;
		compo  = -1;
	}
	NodeType *from, *to;
	_dT weight;
	bool visited;
	int order;
	int compo;
	float color[3];
	void draw(){	
	
		glColor3f(1,1,1);
		glPrintFloat(weight, (from->x+to->x)*0.5-20, (from->y+to->y)*0.5-20);

		if(compo==-1){
			if(visited){
				glColor3f(0,1,0);
				glLineWidth(order);
			}
			else{
				glColor3f(1,1,1);
				glLineWidth(1);
			}
		}
		else{
			glColor3f(color[0],color[1],color[2]);
			glLineWidth(4);
			glPrintInt(compo, (from->x+to->x)*0.5+10, (from->y+to->y)*0.5+10);
		}

		glBegin(GL_LINES);
			glVertex2d(from->x,	from->y);
			glVertex2d(to->x,	to->y);
		glEnd();	

		if(isDirected){
			float vx = to->x - from->x;
			float vy = to->y - from->y;
			float len = sqrt(vx*vx + vy*vy);
			float theta = acos(float(vx)/len);
			float l = theta+0.2;
			float r = theta-0.2;
			float lx = to->x - cos(l)*arrow_len;	
			float rx = to->x - cos(r)*arrow_len;	
			float ly = to->y - (vy>0?sin(l)*arrow_len:sin(l)*-arrow_len);
			float ry = to->y - (vy>0?sin(r)*arrow_len:sin(r)*-arrow_len);
			glBegin(GL_LINES);
			glVertex2d(to->x,	to->y); 
			glVertex2d(lx,		ly);
			glVertex2d(to->x,	to->y); 
			glVertex2d(rx,		ry);
			glEnd();
		}
	}

	void print(){
		printf("[%c", from->name);
		printf("--%c]", to->name);
		printf("\t");
	}

	static bool isDirected;
};
template<class NodeType, class _dT>
bool Edge<NodeType, _dT>::isDirected;

template<class NType, class _dT>
class Graph{
	typedef typename Edge<Node, _dT> EType;	
public:
	vector<NType> nodes;
	vector<EType> edges;
	Graph(bool _directed = true){
		EType::isDirected = _directed;
		nodes.reserve(1000000);
		edges.reserve(1000000);
		directed = _directed;
	}
	bool& isDirected(){ return directed;}
	void clear(){
		nodes.clear();
		edges.clear();
	}
	void draw(){
		EType::isDirected = directed;
		ForIndex(i, edges.size())	edges[i].draw();
		ForIndex(i, nodes.size())	nodes[i].draw();
		
		glColor3f(0.8, 0.5, 0);
		if(isDirected())
			glPrintString("DIRECTED \\u", 50, 50);
		else	
			glPrintString("UNDIRECTED \\u", 50, 50);		
	}
	
	int nearestNode(float x, float y){
		float mindis(999999);
		int ii;
		ForIndex(i, nodes.size()){
			if(mindis>nodes[i].dist(x,y))
			{
				mindis = nodes[i].dist(x,y);
				ii = i;
			}
		}
		if(mindis<20)	return ii;
		return -1;
	}

	void addNode(char name, float x = Random(200,600), float y = Random(200,600)){
		NType nd;
		nd.name = name;
		nd.x = x; nd.y = y;
		nodes.push_back(nd);
	}
	void addEdge(NType* from, NType* to, _dT wt = 0){
		edges.push_back(EType(from, to, wt));
		from->e_out.push_back(&edges.back());
		if(directed)
			to->e_in.push_back(&edges.back()); 
		else 
			to->e_out.push_back(&edges.back());
	}
	void addEdge(int f, int t, _dT wt=0){
		if(ValidRange(f,0,sizeNode()-1) && 
		   ValidRange(t,0,sizeNode()-1))
		{
			NType* from = &nodes[f];
			NType* to = &nodes[t];
			addEdge(from, to, wt);
		}
	}
	void addEdge(EType e){
		addEdge(e.from, e.to, e.weight);
	}
	void removeAllEdge(){
		edges.clear();
		ForIndex(i, sizeNode()){
			nodes[i].e_out.clear();
			nodes[i].e_in.clear();
		}
	}
	bool directed;
	int sizeNode(){ return nodes.size(); }
	int sizeEdge(){ return edges.size(); }
	void print(){
		ForIndex(i, nodes.size())	nodes[i].print();
	}
	vector<NType*> order;
	void resetOrder(){
		ForIndex(i, nodes.size())	nodes[i].order = i;
		ForIndex(i, edges.size())	edges[i].order = i;
	}
	void tagOrder(){
		ForIndex(i, order.size())
			order[i]->order = i;
	}
	void dfsOrdering(int v0){
		order.clear();
		_DFS(&nodes[v0]);
		tagOrder();
	}
	void bfsOrdering(int v0){
		order.clear();
		_BFS(&nodes[v0]);
		tagOrder();
	}
	bool findCycle_singleSource(int v0){ //works for both (non-multiple) di/undi-graph
		order.clear();
		cycles.clear();
		ForIndex(i, nodes.size()){
			nodes[i].visited = false;
			nodes[i].on_the_path = false;					
		}
		_DFS_find_cycle(&nodes[v0]);
		/*for next unmarked vertex, detect again,to find all cycles, even unconnected*/
		
		ForIndex(i, cycles.size()){
			std::reverse(cycles[i].begin(), cycles[i].end());
			std::cerr<<"\ncycle "<<i<<":\n";
			ForIndex(j, cycles[i].size())
				cycles[i][j]->print();
		}
		return cycles.size();
	}

	bool findAllCycle(){ //brutal force searching originating from each verex
		order.clear();
		cycles.clear();
		ForIndex(i, nodes.size()){
			ForIndex(ii, nodes.size()){
				nodes[ii].visited = false;
				nodes[ii].on_the_path = false;
			}
			_DFS_find_cycle(&nodes[i]);
		}

		map<set<NType*>, vector<int> > uni;
		map<set<NType*>, vector<int> >::iterator it;
		ForIndex(i, cycles.size()){
			set<NType*> ss;
			ForIndex(j, cycles[i].size())
				ss.insert(cycles[i][j]);				
			it = uni.find(ss);
			if(it!=uni.end() )
				it->second.push_back( i );
			else
				uni.insert(make_pair(ss, vector<int> (1,i)));
		}
		/*for next unmarked vertex, detect again,to find all cycles, even unconnected*/
		int cc=0;	
		for(it = uni.begin(); it != uni.end(); it++){
			std::cerr<<"\ncycle "<<cc++<<"  \t";
			ForIndex(j, cycles[it->second[0]].size())
				cycles[it->second[0] ][ j ]->print();
			
// 			std::cerr<<"orientation:\n";
// 
// 			NType* n0 = cycles[it->second[0]][0];
// 			ForIndex(j, it->second.size()){ //for each cycle instance
// 				int head=-1;
// 				int n = cycles[it->second[j]].size();
// 				ForIndex(k, n){
// 					if(cycles[it->second[j]][k] == n0){
// 						head = k;
// 						break;
// 					}				
// 				}
// 				assert(head!=-1); //there must be a head.
// 				vector<NType*> headedCycle;
// 				ForIndex(k, n){
// 					headedCycle.push_back(cycles[it->second[j]][head%n]);
// 					head++;
// 				}
// 				std::cerr<<" \n";
// 				ForIndex(k, headedCycle.size())
// 					headedCycle[k]->print();
// 			}
// 			std::cerr<<" \n";
		}
		return cycles.size();
	}
	vector<int> adjacency;
	void formAdjMatrix(){
		adjacency.clear();
		int nnd = nodes.size();
		adjacency.resize(nnd * nnd, 0);
		resetOrder();
		ForIndex(i, edges.size())
			adjacency[ edges[i].from->order + edges[i].to->order*nnd ] = 1;
	}

	void find_all_chordless_cycles()
	{
		formAdjMatrix();
		int dim = nodes.size(); 
		for(int i=0; i<dim-2; i++)
		{
			for(int j=i+1; j<dim-1; j++)
			{
				if(!adjacency[i+j*dim])
					continue;
				list<vector<int> > candidates;
				for(int k=j+1; k<dim; k++)
				{
					if(!adjacency[i+k*dim])
						continue;
					if(adjacency[j+k*dim])
					{
						cout << i+1 << " " << j+1 << " " << k+1 << endl;
						continue;
					}
					vector<int> v;
					v.resize(3);
					v[0]=j;
					v[1]=i;
					v[2]=k;
					candidates.push_back(v);
				}
				while(!candidates.empty())
				{
					vector<int> v = candidates.front();
					candidates.pop_front();
					int k = v.back();
					for(int m=i+1; m<dim; m++)
					{
						if(find(v.begin(), v.end(), m) != v.end())
							continue;
						if(!adjacency[m+k*dim])
							continue;
						bool chord = false;
						int n;
						for(n=1; n<v.size()-1; n++)
							if(adjacency[m+v[n]*dim])
								chord = true;
						if(chord)
							continue;
						if(adjacency[m+j*dim])
						{
							for(n=0; n<v.size(); n++)
								cout<<v[n]+1<<" ";
							cout<<m+1<<endl;
							continue;
						}
						vector<int> w = v;
						w.push_back(m);
						candidates.push_back(w);
					}
				}
			}
		}
	}

	vector<vector<NType*>> cycles;
	void _DFS_find_cycle(NType* v){  
		
		v->visited = true;
		v->on_the_path = true;
		ForIndex(i, v->e_out.size()){
			Node* w;
			if(isDirected())
				w = v->e_out[i]->to;
			else
				w = v==v->e_out[i]->to? v->e_out[i]->from : v->e_out[i]->to;

			//if(cycle.size()!=0) return; /*uncomment this if you only need to know if cycle exists.*/
			if( !w->visited ){
				w->parent = v;
				_DFS_find_cycle(w);
			}

			bool cycleEdgefound;
			if(isDirected()){ 
				cycleEdgefound = w->on_the_path;
			}
			else{
			
				cycleEdgefound = w!=v->parent && w->on_the_path; //NOTE: if we use this also for digraph, it will ignores 2-node cycle. 
																 //Can not handle self-cycle now!	
			}

			if(cycleEdgefound){ //a cycle is found.
				cycles.push_back(vector<Node*>());
				cycles.back().push_back(w);	
				cycles.back().push_back(v);	
				Node* p = v->parent;
				while(p!=cycles.back().front()){
					cycles.back().push_back(p);	
					p = p->parent;
				}
			}
		}
		v->on_the_path = false;
	}

	void topologicalSort(){
		ForIndex(i, nodes.size())	nodes[i].inDegree = nodes[i].e_in.size();
		order.clear();

		queue<NType*> q;
		ForIndex(i, nodes.size()){
			if(nodes[i].inDegree == 0)	q.push(&nodes[i]);
		}
		while(!q.empty())
		{
			NType *nd = q.front();
			q.pop();
			order.push_back(nd);
			ForIndex(i, nd->e_out.size()){
				NType *w = nd->e_out[i]->to;
				w->inDegree--;
				if(w->inDegree==0)
					q.push(w);
			}
		}
		tagOrder();
	}
	void closeSimpleCycle(){

		ForIndex(i, nodes.size()){
			nodes[i].inDegree = nodes[i].e_in.size();
			nodes[i].outDegree= nodes[i].e_out.size();
		}
		order.clear();

		queue<NType*> q;
		ForIndex(i, nodes.size())
			if(nodes[i].inDegree == 0)	q.push(&nodes[i]);
		
		while(!q.empty())
		{
			NType *nd = q.front();
			q.pop();
			nd->outDegree = 0;
			nd->visited = true;
			order.push_back(nd);
			ForIndex(i, nd->e_out.size()){
				NType *w = nd->e_out[i]->to;
				w->inDegree--;
				w->outDegree--;
				if(w->inDegree==0)
					q.push(w);
			}
		}
		tagOrder();
	}

	void dijkstra_SingleSource(int v0, vector<_dT> &_dist, vector<int> &_pred)
	{
		struct ShortestPathRecord{
			int vi;
			int pred;
			_dT sp;
			EType *e;
		public:
			bool operator> (const ShortestPathRecord& r) const{	return sp>r.sp;}
		};

		resetOrder();
		_dist.resize(sizeNode(), numeric_limits<_dT>::max());
		_pred.resize(sizeNode(), -1);
		Heap<ShortestPathRecord> q;
		ShortestPathRecord r;
		int e_order = 1;
		r.vi = v0;
		r.pred = -1;
		r.sp = 0;
		r.e = NULL;
		q.push(r);
		
		_dist[v0] = 0.0;
		_pred[v0] = -1;
		while(!q.empty()){
			
			r = q.top(); q.pop();

			//std::cerr<<"r.sp "<<r.sp<<"\n";

			NType *v = &nodes[r.vi];
			if(r.sp<=_dist[r.vi]){
				if(r.e){
					e_order++;
					r.e->order = e_order;
					r.e->visited = true;
					//std::cerr<<"from "<<r.e->from->name<<" to "<<r.e->to->name<<"\n";
				}
				_dist[r.vi] = r.sp;
				
				ForIndex(i, v->e_out.size()){
					
					NType *w = v==v->e_out[i]->to? v->e_out[i]->from : v->e_out[i]->to;
					
					if( v->e_out[i]->weight+_dist[v->order] <_dist[w->order]){
						_dist[w->order] = v->e_out[i]->weight+_dist[v->order];
						_pred[w->order] = v->order;

						r.vi = w->order;
						r.pred = v->order;
						r.sp = _dist[w->order];
						r.e = v->e_out[i];
						q.push(r);
					}
				}
			}
		}
	}
	_dT minSpanTree_Prim(vector<_dT> &_e_dist)
	{
		struct MinEdgeRecord{
			int vi;
			_dT sp;
			EType *e;
		public:
			bool operator> (const MinEdgeRecord& r) const{	return sp>r.sp;}
		};

		resetOrder();
		_e_dist.resize(sizeNode(), numeric_limits<_dT>::max());
		Heap<MinEdgeRecord> q;
		MinEdgeRecord r;
		int e_order = 0;
		_dT minEcost = numeric_limits<_dT>::max();
		ForIndex(i,edges.size()){
			if(minEcost>edges[i].weight){
				minEcost = edges[i].weight;
				r.vi = edges[i].from->order;
				r.sp = edges[i].weight;
				r.e =  &edges[i];
			}
		}
		q.push(r);
		_dT costSum = 0.0;
		while(!q.empty()){

			r = q.top(); q.pop();

			NType *v = &nodes[r.vi];
			if(r.sp<=_e_dist[r.vi]){
				costSum += r.sp;
				if(r.e){
					e_order++;
					r.e->order = e_order;
					r.e->visited = true;
				}
				_e_dist[r.vi] = r.sp;

				ForIndex(i, v->e_out.size()){
	
					NType *w = v==v->e_out[i]->to? v->e_out[i]->from : v->e_out[i]->to;
	
						
					if( v->e_out[i]->weight<_e_dist[w->order]){
						_e_dist[w->order] = v->e_out[i]->weight;

						r.vi = w->order;
						r.sp = _e_dist[w->order];
						r.e = v->e_out[i];
						q.push(r);
					}
				}
			}
		}
		return costSum;
	}
	_dT maxSpanTree_Prim(vector<_dT> &_e_dist)
	{
		struct MinEdgeRecord{
			int vi;
			_dT sp;
			EType *e;
		public:
			bool operator> (const MinEdgeRecord& r) const{	return sp<r.sp;}
		};
		
		resetOrder();
		_e_dist.resize(sizeNode(), numeric_limits<_dT>::min());
		Heap<MinEdgeRecord> q;
		MinEdgeRecord r;
		int e_order = 0;
		_dT maxCost = numeric_limits<_dT>::min();
		ForIndex(i,edges.size()){
			if(maxCost<edges[i].weight){
				maxCost = edges[i].weight;
				r.vi = edges[i].from->order;
				r.sp = edges[i].weight;
				r.e =  &edges[i];
			}
		}
		q.push(r);
		_dT costSum = 0.0;
		while(!q.empty()){

			r = q.top(); q.pop();

			NType *v = &nodes[r.vi];
			if(r.sp>=_e_dist[r.vi]){
				costSum += r.sp;
				if(r.e){
					e_order++;
					r.e->order = e_order;
					r.e->visited = true;
				}
				_e_dist[r.vi] = r.sp;

				ForIndex(i, v->e_out.size()){
					
					NType *w = v==v->e_out[i]->to? v->e_out[i]->from : v->e_out[i]->to;

					if( v->e_out[i]->weight>_e_dist[w->order]){
						_e_dist[w->order] = v->e_out[i]->weight;

						r.vi = w->order;
						r.sp = _e_dist[w->order];
						r.e = v->e_out[i];
						q.push(r);
					}
				}
			}
		}
		return costSum;
	}
	void allPairShortestPath_floydWarshall(vector<vector<_dT> >& D){
		resetOrder();
		D.clear();
		int n = sizeNode();
		D.resize(n);
		ForIndex(i, D.size()){
			D[i].resize(sizeNode(), numeric_limits<_dT>::max());
			D[i][i] = 0;
		}
		ForIndex(i, edges.size()){
			D[edges[i].from->order] [edges[i].to->order] = edges[i].weight;
			if(!directed)
				D[edges[i].to->order] [edges[i].from->order] = edges[i].weight;
		}
		ForIndex(m, n){
			ForIndex(x, n)	ForIndex(y, n){
				if(D[x][m] + D[m][y] < D[x][y])
					D[x][y]	= D[x][m] + D[m][y];
			}
		}
	}
private:
	void _DFS(NType* v){
		v->visited = true;
		order.push_back(v);
		ForIndex(i, v->e_out.size()){
			if(isDirected()){
				Node* w = v->e_out[i]->to;
				if( !w->visited ){
					v->e_out[i]->visited = true;
					_DFS(w);
				}
			}
			else{
				Node* w = v== v->e_out[i]->to? v->e_out[i]->from : v->e_out[i]->to;
				if( !w->visited ){
					v->e_out[i]->visited = true;
					_DFS(w);
				}
			}
		}
	}
	void _BFS(NType* v){
		queue<Node*> q;
		q.push(v);
		while(!q.empty()){
			NType *nd = q.front();
			q.pop();
			nd->visited = true;	
			order.push_back(nd);
			ForIndex(i, nd->e_out.size()){
				if(isDirected()){
					if(!nd->e_out[i]->to->visited){

						nd->e_out[i]->visited = true;
						nd->e_out[i]->to->visited = true;
						q.push(nd->e_out[i]->to);
					}
				}
				else{
					Node* w = nd== nd->e_out[i]->to? nd->e_out[i]->from : nd->e_out[i]->to;
					if(!w->visited){
						nd->e_out[i]->visited = true;
						w->visited = true;
						q.push(w);
					}					
				}
			}
		}
	}
	int _traverse_order;
	vector<EType*> _e_order;
	vector< vector<EType*> > m_e_stack;
	void _DFS_articulation(NType* v){
		v->visited = true;
		v->order = _traverse_order++;
		order.push_back(v);
		v->high = v->order;

		ForIndex(i, v->e_out.size()){

			Node* nbr = v== v->e_out[i]->to? v->e_out[i]->from : v->e_out[i]->to;

			if( !nbr->visited )
			{	//child on DFS tree
				
				nbr->parent = v;

				_e_order.push_back(v->e_out[i]);

				_DFS_articulation(nbr);

				v->e_out[i]->visited = true;
				
				v->high = min(v->high, nbr->high); //get highest back edge, the smaller , the higher(higher means ancestor)
				
				if( v->order <= nbr->high ){  //check if this back edge has climbed up over the current node.
					/*articulated vertex found!*/
					
					printf("%c is anticulation of %c\n", v->name, nbr->name);

					vector<EType*> e_compo;  //trace back this biconnected component
				
					do{
						e_compo.push_back(_e_order.back());
						_e_order.pop_back();
					}
					while (e_compo.back()!=v->e_out[i] );
					
					std::cerr<<"new component with "<<e_compo.size()<<" edges.\n";
					
					m_e_stack.push_back(e_compo);
				}
			}
			else  
			{
				if( v->parent != nbr /*�����ֻ��ֱϵ���׵Ļر�,�ǲ�һ���γɻ�·��һ��ҪԽ�����ף������Ƴ�һ����·�Ӷ����˫��ͨ*/ 
					&& v->order > nbr->order )
				{ 
					/*back edge:
					the edge point back to an ancestor, 
					but not the parent, on DFS tree.*/
					_e_order.push_back(v->e_out[i]);
				
					v->high = min(v->high, nbr->order); /*���ɷ���������,�������������.�����ֻ��ֱϵ���׵Ļر�,�ǲ�һ���γɻ�·��
														��������Ҳ���������Ϊ���ռ��artiVertex�õ���С�ڵ���!:v->order <= nbr->high 
														{����7.25��AB������һ����֧������}*/
				}
			}
		}
	}
public:
	void biconnectedComponent(){
		_traverse_order = 0;
		ForIndex(i, nodes.size()){
			nodes[i].visited = false;
			nodes[i].compo = -1;
		}
		m_e_stack.clear();
		order.clear();
		_e_order.clear();
		_DFS_articulation(&nodes[0]);
		std::cerr<<"#bi-components : "<<m_e_stack.size()<<"\n\n";
		srand(GetTickCount());
		ForIndex(i, m_e_stack.size()){
			float color[3] = {Random(0,1), Random(0,1), Random(0,1)};
			ForIndex(j, m_e_stack[i].size()){
				m_e_stack[i][j]->compo = i;
				ForIndex(k,3) m_e_stack[i][j]->color[k] = color[k];
			}
		}

		ForIndex(i, sizeNode())
			std::cerr<<nodes[i].name<<"_"<<nodes[i].high<<"\n";
	}
private:
	int _traverse_compo;

	vector< vector<NType*> > m_n_stack;

	void _DFS_SCC(NType *v){
		v->visited = true;
		v->order = _traverse_order++;
		order.push_back(v);
		v->high = v->order ;
		ForIndex(i, v->e_out.size()){
			Node* nbr = v->e_out[i]->to;//? v->e_out[i]->from : v->e_out[i]->to;
			if( !nbr->visited )
			{	//child on DFS tree

				_DFS_SCC(nbr);

				v->e_out[i]->visited = true;

				v->high = min(nbr->high, v->high); //get highest back edge

			}
			else  //ancestor on DFS tree //cross edge or back edge
			{
				if( nbr->order < v->order && nbr->compo == -1 )
					v->high = min(v->high, nbr->order);
			}
		}
		if( v->order ==  v->high ){  //find a scc root
			printf("%c is a scc root\n", v->name);
			v->compo = _traverse_compo;
			//trace back this scc
			vector<NType*> nd;
			while(order.back()!=v){
				nd.push_back(order.back());
				nd.back()->compo = _traverse_compo;
				order.pop_back();
			}
			nd.push_back(order.back());
			m_n_stack.push_back(nd);
			order.pop_back();
			_traverse_compo++;
		}
	} 
public:
	void stronglyConnectedComponent(  ){
		_traverse_order = 0;
		_traverse_compo = 0;
		ForIndex(i, nodes.size())	nodes[i].visited = false;
		m_n_stack.clear();

		NType* nd(NULL);
		int n(0);
		while(nd==NULL){
			nd = NULL;
			ForIndex(i, sizeNode()){
				if(nodes[i].order==-1){
					nd = &nodes[i];
					break;
				}
			}
			if(nd)	{
				order.clear();
				_DFS_SCC(nd);
				n++;
			}
		}
		std::cerr<<"run  "<<n<<"\n";

		srand(GetTickCount());
		ForIndex(i, m_n_stack.size()){
			//vertex
			float color[3] = {Random(0,1), Random(0,1), Random(0,1)};
			std::cerr<<"new component:";
			ForIndex(j, m_n_stack[i].size()){
				printf("%c(%d)", m_n_stack[i][j]->name, m_n_stack[i][j]->high);
				ForIndex(k,3) m_n_stack[i][j]->color[k] = color[k];
			}
			std::cerr<<"\n";
		}
	}
};

}