#include "stdafx.h"
#include "bst.h"
#include "avl.h"
#include "StopWatch.h"
using namespace _BINARY_TREE;

extern int N;
extern int tN;
extern int* sample;
int *order  = new int[tN];

StopWatch timer;
extern bool worst_case;

void makeSample();

void search_order(){
	srand(GetTickCount());
	for (int i=0; i<tN; i++)	order[i] = min(max(rand(), 0), N-1);		
}

extern bstTree<int> bst;
extern avlTree<int> avl;

void build_tree(){
	
	avl.clear();
	bst.clear();

	timer.StartTimer();
	for (int i=0; i<N; i++)	bst.insert(sample[i]);
	timer.StopTimer();
	std::cerr<<"build bst: "<<timer.GetElapsedTime()*1000<<"ms\n";
	

	timer.StartTimer();
	for (int i=0; i<N; i++)	avl.insert(sample[i]);
	timer.StopTimer();
	std::cerr<<"build avl: "<<timer.GetElapsedTime()*1000<<"ms\n";

	std::cerr<<" avl.min "<<avl.min_key();
	std::cerr<<" avl.max "<<avl.max_key()<<"\n";
	std::cerr<<" bst.min "<<bst.min_key();
	std::cerr<<" bst.max "<<bst.max_key()<<"\n";
}

void complexity_find(){

	search_order();
	
	if(worst_case)	std::cerr<<"worst case testing��\n";
	else			std::cerr<<"average case testing��\n";

	timer.StartTimer();
	for (int i=0; i<tN; i++)	bst.find(sample[order[i]]);
	timer.StopTimer();
	std::cerr<<"find in bst "<<tN<<": "<<timer.GetElapsedTime()*1000<<"ms\n";

	timer.StartTimer();
	for (int i=0; i<tN; i++)		avl.find(sample[order[i]]);
	timer.StopTimer();
	std::cerr<<"find in avl "<<tN<<": "<<timer.GetElapsedTime()*1000<<"ms\n";
	std::cerr<<"\n";
}

void performance(){
	
	std::cerr<<"tree has "<<N<<" nodes.\n";

	worst_case = true;
	makeSample();
	build_tree();
	for (int i=0; i<3; i++)	complexity_find();

	worst_case = false;
	makeSample();
	build_tree();
	for (int i=0; i<3; i++)	complexity_find();

	delete[] order;
}