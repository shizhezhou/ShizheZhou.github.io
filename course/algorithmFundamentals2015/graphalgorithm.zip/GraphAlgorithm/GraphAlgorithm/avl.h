/*if you detect bugs, please email to szhou@ustc.edu.cn*/

/*AVL tree for students.*/

#include "bst.h"

#pragma once

using namespace std;

namespace _BINARY_TREE{

template<class T>
class avlTree : public bstTree<T>{	
	typedef typename binary_nodeType<T> Node;
	typedef typename avlTree<T>	 Tree;
private:
	void _Rrotate_1(Node *A){
		if(A==NULL)	return;
		Node* B =  A->l();
		Node* C =  A->r();
		swap(A->a(), B->a());

		A->l() = B->l();
		A->r() = B;	
		B->l() = B->r();
		B->r() = C;

		B->newDepth(); //update depth: make sure child first!
		A->newDepth();
	}
	void _Lrotate_1(Node *A){
		if(A==NULL)	return;
		Node* B =  A->l();
		Node* C =  A->r();
		swap(A->a(), C->a());

		A->r() = C->r();
		A->l() = C;
		C->r() = C->l();
		C->l() = B;

		C->newDepth();
		A->newDepth(); 
	}
	void _Rrotate_2(Node *A){
		if(A==NULL)	return;
		Node* B =  A->l();
		Node* C =  A->r();
		Node* D =  B->r();
		swap(A->a(), D->a());

		A->r() = D;	
		B->r() = D->l();
		D->l() = D->r();	D->r() = C;

		D->newDepth();
		B->newDepth();
		A->newDepth();
	}
	void _Lrotate_2(Node *A){
		if(A==NULL)	return;
		Node* B =  A->l();
		Node* C =  A->r();
		Node* D =  C->l();
		swap(A->a(), D->a());

		A->l() = D;	
		C->l() = D->r();
		D->r() = D->l();	D->l() = B;

		D->newDepth();
		C->newDepth();
		A->newDepth();
	}
public:
	void insert(T t){
		if(m_root==NULL){
			m_root = new Node(t);
			return;
		}
		Node* parent;
		Node* rt = m_root;
		bool toleft(false);

		Node** path = new Node*[m_root->depth()];
		int c = 0;
		while(rt)
		{
			parent = rt;

			if(parent->a()==t){
				delete path;
				return;
			}
			else{
				path[c] = parent;
				c++;
				if( t > parent->a() ){
					rt = parent->r();
					toleft = false;
				}
				else{
					rt = parent->l();
					toleft = true;
				}
			}
		}
		if(toleft){
			parent->l() = new Node(t);
		}
		else{
			parent->r() = new Node(t);
		}
		for (int i=c-1; i>=0; i--){ //trace-back the path
			if(path[i]->newDepth()){  
				path[i]->newBalance();
				if(path[i]->balance()>1){
					if(t<path[i]->l()->a())	_Rrotate_1(path[i]);
					else					_Rrotate_2(path[i]);
					break; 
				}
				if(path[i]->balance()<-1){
					if(t>path[i]->r()->a())	_Lrotate_1(path[i]);
					else					_Lrotate_2(path[i]);
					break; 
				}
			}
			else{
				break;  //if depth stays the same, all of its ancestors keep balance.
			}
		}
		delete path;
	}
	void allBalance(){ //compute balance number for all nodes.
		std::cerr<<"\nall the balance:\n";
		_allBalance(m_root);
	}
	void allDepth(){ 
		std::cerr<<"\nall the depth:\n";
		_allDepth(m_root);
	}
private:
	void _allBalance(Node* rt){
		if(rt){
			rt->newBalance();	
			if(abs(rt->balance())>1)
				printf("%d,", rt->balance());
			if(rt->l())	_allBalance(rt->l());
			if(rt->r())	_allBalance(rt->r());
		}
	}
	void _allDepth(Node *rt){
		if(rt){
			if(rt->l())	_allDepth(rt->l());
			if(rt->r())	_allDepth(rt->r());
			rt->depth();
		}
	}
	void remove(T t){ /*removal of the root is supported.*/
		
	}
};

}