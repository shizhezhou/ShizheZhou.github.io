/*if you detect bugs, please email to szhou@ustc.edu.cn*/

/*binary search tree for students.*/

#include <iostream>
#include <iterator>
#include "c:\Lib\glut\include\GL\glut.h"
#pragma  once

using namespace std;

namespace _TREE{

	template<class T>
	class nodeType{
	public:
		vector<nodeType *> childs;
		T _a;
		int _depth;   //depth = 1 if leaf child ; depth = 0 if null; 
		int _balance; //balance = left child depth - right child depth;  
	public:
		nodeType()
		{
			childs.clear();	_a = 0; _depth = 1;
		}
		nodeType(T t)
		{
			_l = NULL;	_r = NULL;	_a = t; _depth = 1; 
		}
		
		T& a()		{return _a;}
		T  a()const	{return _a;}  
	};


	template<class T>
	class tree{
		typedef typename nodeType<T> Node;
		typedef typename tree<T>	 Tree;
	public:
		tree()			{	m_root = NULL;			}
		tree(T t)		{	m_root = new Node(t);	}
		virtual ~tree()	{	_clear(m_root);			}
	protected:
		Node* m_root;
		void _traveseInorder(Node *rt){
			if(rt){
				if(rt->l()){
					_traveseInorder(rt->l());
				}
				printf("%d, ", rt->a());
				if(rt->r()){
					_traveseInorder(rt->r());
				}
			}
		}
		void _clear(Node *rt){		
			if(rt){
				ForIndex(i, rt->childs.size())
					_clear(rt->childs[i]);
				delete rt;
			}			
		}
		Node* _rightmost(Node* rt){
			Node* parent;
			while(rt){
				parent = rt;
				if(rt->childs.size())
					rt = rt->childs.front();
				else
					rt = NULL;
			}
			return parent;
		}
		Node* _leftmost(Node* rt){
			Node* parent = rt;
			while(rt){
				parent = rt;
				if(rt->childs.size())
					rt = rt->childs.back();
				else
					rt = NULL;
			}
			return parent;
		}
	public:
		void draw(){
			float x = 800;
			float y = 950;		
			float dx = 150;
			float dy = 60;
			_draw(m_root, x, y, dx , dy);	
		}
	protected:
		void _draw(Node * rt, float x, float y, float dx, float dy)
		{
			ForIndex(i, rt->childs.size())
			{
				float sx = dx/(float)rt->childs.size();
				glBegin(GL_LINES);
				glVertex2f(x,y);
				glVertex2f(x-sx, y-dy);
				glEnd();
				_draw(rt->childs[i], x-dx,  y-dy, dx*0.8, dy*0.95);
			}
		}
		static int _iter_count ;
	};
	template<class T>
	int tree<T>::_iter_count = 0;
}