/*if you detect bugs, please email to szhou@ustc.edu.cn*/

/*binary search tree for students.*/

#include <iostream>
#include <iterator>
#include "c:\Lib\glut\include\GL\glut.h"
#pragma  once

using namespace std;

namespace _BINARY_TREE{

template<class T>
class binary_nodeType{
private:
	binary_nodeType *_l;
	binary_nodeType *_r;
	T _a;
	int _depth;   //depth = 1 if leaf child ; depth = 0 if null; 
	int _balance; //balance = left child depth - right child depth;  
public:
	binary_nodeType()
	{
		_l = NULL;	_r = NULL;	_a = 0; _depth = 1;
	}
	binary_nodeType(T t)
	{
		_l = NULL;	_r = NULL;	_a = t; _depth = 1; 
	}
	(binary_nodeType*) & l()	{ return _l; }
	binary_nodeType* l() const { return _l; }

	(binary_nodeType*) & r()	{ return _r; }
	binary_nodeType* r() const { return _r; }

	T& a()		{return _a;}
	T  a()const	{return _a;}  

	bool newDepth()	{ 
		int d = _depth;
		_depth = max((_l?l()->depth():0), (_r?r()->depth():0)) + 1; 
		if(d == _depth) return false;
		else			return true;
	}
	int& depth()		{return _depth;}
	int  depth()const	{return _depth;}  

	void newBalance()	{ _balance = (_l?l()->depth():0) - (_r?r()->depth():0); /* printf("%d,", _balance);*/ }	
	int& balance()		{return _balance;}
	int  balance()const	{return _balance;}  
};


template<class T>
class bstTree{
	typedef typename binary_nodeType<T> Node;
	typedef typename bstTree<T>	 Tree;
public:
	bstTree()		{	m_root = NULL;			}
	bstTree(T t)	{	m_root = new Node(t);	}
	virtual ~bstTree()		{	_clear(m_root);			}
protected:
	Node* m_root;
	Node* _search(Node* rt, T t, Node** _pparent = NULL){ /*_pparent points to targets'parent, null if target is the root.*/
		Node* parent = NULL;
		while(rt)
		{
			if(rt->a()==t){
				if(_pparent) *_pparent = parent;
				return rt;
			}
			parent = rt;
			if( t > parent->a() )
				rt = parent->r();
			else
				rt = parent->l();
		}
		return NULL;
	}	
	void _traveseInorder(Node *rt){
		if(rt){
			if(rt->l()){
				_traveseInorder(rt->l());
			}
			printf("%d, ", rt->a());
			if(rt->r()){
				_traveseInorder(rt->r());
			}
		}
	}
	void _clear(Node *rt){		
		if(rt){
			if(rt->l())	_clear(rt->l());
			if(rt->r())	_clear(rt->r());
			delete rt;
		}			
	}
	Node* _rightmost(Node* rt){
		Node* parent;
		while(rt){
			parent = rt;
			rt = rt->r();
		}
		return parent;
	}
	Node* _leftmost(Node* rt){
		Node* parent = rt;
		while(rt){
			parent = rt;
			rt = rt->l();
		}
		return parent;
	}
private:
	Node* _RrotateErase(Node *nd){
		if(nd==NULL)	return NULL;
		Node* left = _leftmost( nd->r());	
		nd->a() = left->a();

		Node* parent_left;
		_search(nd->r(), left->a(), &parent_left); 

		if(parent_left==NULL)
			nd->r() = left->r();
		else
			parent_left->l() = left->r();
		return left;
	}
	Node* _LrotateErase(Node *nd){
		if(nd==NULL)	return NULL;
		Node* right = _rightmost( nd->l());	
		nd->a() = right->a();

		Node* parent_right;
		_search(nd->l(), right->a(), &parent_right); 

		if(parent_right==NULL)
			nd->l() = right->l();
		else
			parent_right->r() = right->l();
		return right;
	}
public:
	void insert(T t){
		if(m_root==NULL){
			m_root = new Node(t);
			return;
		}
		Node* parent;
		Node* rt = m_root;
		bool toleft(false);
		while(rt)
		{
			parent = rt;

			if(parent->a()==t)
				return;
			else if( t > parent->a() ){
				rt = parent->r();
				toleft = false;
			}
			else{
				rt = parent->l();
				toleft = true;
			}
		}
		if(toleft)
			parent->l() = new Node(t);
		else
			parent->r() = new Node(t);
	}
	void remove(T t){ /*removal of the root is supported.*/
		Node *parent;
		Node *rt = _search(m_root, t, &parent);
		if(rt==NULL){
			return;
		}
		else{
			if(rt->l()==NULL && rt->r()==NULL){
				if(NULL==parent)				m_root = NULL;
				else if(rt->a()>parent->a())	parent->r() = NULL;
				else							parent->l() = NULL;
			}
			else if(rt->r() && rt->l()==NULL){
				if(NULL==parent) 				m_root = rt->r();
				else if(rt->a()>parent->a())	parent->r() = rt->r();
				else							parent->l() = rt->r();
			}
			else if(rt->l() && rt->r()==NULL){
				if(NULL==parent) 				m_root = rt->l();
				else if(rt->a()>parent->a())	parent->r() = rt->l();
				else							parent->l() = rt->l();
			}
			else{ /*method 2, Right rotation*/
				rt = _RrotateErase(rt);
				//rt = _LrotateErase(rt);
			}	
			delete rt;			
		}
	}
	void traveseInorder(){
		_traveseInorder(m_root);
	}
	bool find(T t){
		if(_search(m_root, t))	return true;
		else					return false;
	}
	void clear(){ _clear(m_root); m_root = NULL; }
	T min_key(){ return _leftmost(m_root)->a(); }
	T max_key(){ return _rightmost(m_root)->a();}

	T find_smallest(int k){
		_iter_count = 0;
		int x;
		_traveseStep(m_root, k, x);
		return x;
	}
protected:
	static int _iter_count ;
	void _traveseStep(Node *rt, int k, int& x){
		if(rt){
			if(rt->l()){
				_traveseStep(rt->l(), k, x);
			}
			_iter_count++;
			if(_iter_count==k) {
				x = rt->a(); return;
			}
			if(rt->r()){
				_traveseStep(rt->r(), k, x);
			}
		}
	}
public:
	void draw(){
		float x = 800;
		float y = 950;		
		float dx = 150;
		float dy = 60;
		_draw(m_root, x, y, dx , dy);	
	}
protected:
	void _draw(Node * rt, float x, float y, float dx, float dy){

		if(rt){
 			if(rt->l()){	
				glBegin(GL_LINES);
				glVertex2f(x,y);
				glVertex2f(x-dx, y-dy);
				glEnd();
				_draw(rt->l(), x-dx,  y-dy, dx*0.8, dy*0.95);

			}
 			if(rt->r()){
				glBegin(GL_LINES);
				glVertex2f(x,y);
				glVertex2f(x+dx, y-dy);
				glEnd();
				_draw(rt->r(), x+dx, y-dy, dx*0.8, dy*0.95);
			}
		}
	}
};
template<class T>
int bstTree<T>::_iter_count = 0;
}