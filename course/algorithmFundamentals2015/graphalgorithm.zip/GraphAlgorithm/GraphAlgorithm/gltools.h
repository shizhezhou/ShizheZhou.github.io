#pragma once

void glPrintInt(int s, float x, float y);

void glPrintFloat(float s, float x, float y);

void glPrintString(char *s, float x, float y);

void glPrintString(const std::string &s, float x, float y);

void glPrintChar(char s, float x, float y);