#include "stdafx.h"
#include "c:\Lib\glut\include\GL\glut.h"
#include "graph.h"
#include <iostream>
#include <iterator>

using namespace _GRAPH;
extern Graph<Node, float> g;
extern int c, d;
extern bool travelDfs;
extern bool travelBfs;
int glwdn_height = 800;
void traverseGraph();
void dijkstra();
void mst();
void max_mst();
void allPairSP();
void biconnectedComponent();
void biconnectedComponent2();
void biconnectedComponent3();
void scc();
void testDijk_inDirected();
void topoSort();
void findCycle();

void reshape(int w, int h)
{
	glwdn_height  = h;
	glViewport(0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho (0.0, w, 0.0, h, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
}

void display(void)
{	
	glClear(GL_COLOR_BUFFER_BIT);
	g.draw();
	glFlush ();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'u': //switch directed/undirected graph
		g.isDirected()=!g.isDirected();
		display();	
		break;
	case 'w':
		ForIndex(i, g.nodes.size())
			g.nodes[i].setXY(g.nodes[i].x, g.nodes[i].y+2);
		display();	
		break;
	case 's':
		ForIndex(i, g.nodes.size())
			g.nodes[i].setXY(g.nodes[i].x, g.nodes[i].y-2);
		display();
		break;
	case 'a':
		ForIndex(i, g.nodes.size())
			g.nodes[i].setXY(g.nodes[i].x-2, g.nodes[i].y);
		display();
		break;
	case 'd':
		ForIndex(i, g.nodes.size())
			g.nodes[i].setXY(g.nodes[i].x+2, g.nodes[i].y);
		display();
		break;
	case 'e':
		c++;
		dijkstra();
		display();
		break;
	case 'f':
		d++;
		dijkstra();
		display();
		break;
	case 'x':
		testDijk_inDirected();
		display();
		break;
	case 'c':
		topoSort();
		display();
		break;
	case 't':
		travelDfs = true;
		travelBfs = false;
		traverseGraph();
		display();
		break;
	case 'T':
		travelDfs = false;
		travelBfs = true;
		traverseGraph();
		display();
		break;
	case 'C':
		gDrawCoords = !gDrawCoords;
		display();
		break;
	case 'y':
		findCycle();
		display();
		break;
	}
}

int pickedNid = -1;
void mouse(int button, int state, int x, int y)
{
	pickedNid = -1;
	switch (button) {
	case GLUT_LEFT_BUTTON:
		pickedNid = g.nearestNode(x,glwdn_height-y);
		break;
	default:
		break;
	}
}

void motion(int x, int y)
{
	if(pickedNid!=-1){
		g.nodes[pickedNid].setXY(x, glwdn_height - y);
		display();
	}
}

void drawGraph(int argc, char** argv)
{
	//tranverseGraph();

	 //max_mst();

	 //mst();

	//dijkstra();
	
	//allPairSP();

	//biconnectedComponent();

	//biconnectedComponent2();

	//biconnectedComponent3();

	//scc();

	//testDijk_inDirected();

	//topo();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE| GLUT_RGB);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition (100, 100);
	glutCreateWindow("draw graph");
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutDisplayFunc(display);
	glutSwapBuffers();
	glutMainLoop();
}	

