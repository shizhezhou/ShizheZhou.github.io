#include "stdafx.h"

void drawGraph(int argc, char** argv);

int _tmain(int argc, char** argv)
{
	drawGraph(argc, argv);
	_CrtDumpMemoryLeaks();
	return 0;
}

