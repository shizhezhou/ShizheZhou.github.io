#include "stdafx.h"
#include <windows.h>
#include "graph.h"
#include <set>
#include <iostream>
#include <iterator>
template<class T>
inline void printStl(char *name, const T& vct){
	cerr<<name<<"  ";
	copy(vct.begin(), vct.end(), ostream_iterator<T::value_type>(cerr,", "));
	//cerr<<"\n";
}

using namespace _GRAPH;
Graph<Node, float> g;
bool travelDfs = true;
bool travelBfs = false;
void traverseGraph(){
	//g.isDirected()=false;
	//give nodes
	g.clear();
	g.addNode('A',400,700);	g.addNode('B',240,526);	g.addNode('C',85,360);	
	g.addNode('D',232,363);	g.addNode('E',237,180);	g.addNode('F',400,356);	
	g.addNode('G',471,477);	g.addNode('H',666,226);	g.addNode('I',470,220);
	g.addNode('J',698,477);
	//give edges
	g.addEdge(0,1);	g.addEdge(0,5);
	g.addEdge(0,6);	g.addEdge(0,9);	

	g.addEdge(1,2); g.addEdge(1,3);	g.addEdge(1,5);	

	g.addEdge(3,4);	g.addEdge(5,3); 

	g.addEdge(4,5);	

	g.addEdge(0,2); //a - c

	g.addEdge(1,4);//b - e

	g.addEdge(6,1);//f - g

	/**NOTE: swap edge adding order (6,9) and (6,7) , leads to different DFS order&tree.**/

	g.addEdge(6,7);	g.addEdge(6,9); g.addEdge(6,8);	

	g.addEdge(7,8);	g.addEdge(7,9);	

	g.addEdge(8,9);	
	
	//pure travelling, no connected-component detection.
	if(travelBfs)
		g.bfsOrdering(0);
	else
		g.dfsOrdering(0);
}

void findCycle(){	
	system("cls");
 	g.clear();
	//g.isDirected() = true;

	g.addNode('A',400,700);	g.addNode('B',240,526);	g.addNode('C',85,360);	
	g.addNode('D',232,363);	g.addNode('E',237,180);	g.addNode('F',400,356);	
	g.addNode('G',471,477);	g.addNode('H',666,226);	g.addNode('I',470,220);
	g.addNode('J',698,477);
	
	g.addEdge(0,1);	g.addEdge(0,5); //g.addEdge(5,0);
	g.addEdge(0,6);	g.addEdge(0,9);	
	g.addEdge(1,2); g.addEdge(1,3);	g.addEdge(1,5);	
	g.addEdge(3,4);	g.addEdge(5,3); //(5,3) gives a cycle.
	g.addEdge(4,5);	g.addEdge(5,2);		
	g.addEdge(6,7);	g.addEdge(9,6); g.addEdge(6,8);	
	g.addEdge(7,8);	g.addEdge(7,9);	
	g.addEdge(8,9);	

// 	g.addNode('0',240,526);	g.addNode('1',232,363);	g.addNode('2',237,180);	g.addNode('3',400,356);	
// 	g.addEdge(0,1);	
// 	g.addEdge(1,3);
// 	g.addEdge(2,1);
// 	g.addEdge(3,0);
// 	g.addEdge(3,2);
// 	g.addEdge(0,2);	
	
	//g.findCycle_singleSource(0);
	g.findAllCycle();
	//g.find_all_chordless_cycles();
}

int c = 1;
int d = 0;
void dijkstra(){
	//g.isDirected()=false;
	//give nodes
	g.clear();
	g.addNode('v',300,400);	g.addNode('a',200,400);	g.addNode('b',400,400);	
	g.addNode('c',200,300);	g.addNode('d',300,300);	g.addNode('e',400,300);	
	g.addNode('f',200,200);	g.addNode('g',300,200);	g.addNode('h',400,200);	
	//give edges
	g.addEdge(0,1,.1*c+d);	g.addEdge(0,2,.5*c+d);	
	g.addEdge(3,4,.4*c+d);	g.addEdge(4,5,.2*c+d);
	g.addEdge(7,6,.2*c+d);	g.addEdge(8,7,.3*c+d);
	g.addEdge(1,3,.2*c+d);	g.addEdge(4,0,.1*c+d); g.addEdge(2,5,.3*c+d);
	g.addEdge(3,6,.9*c+d);	g.addEdge(4,7,.4*c+d); g.addEdge(5,8,.1*c+d);

	vector<float> dist;
	vector<int>   pred;
	g.dijkstra_SingleSource(7, dist, pred);
	std::copy(dist.begin(), dist.end(),std::ostream_iterator<float>(std::cout,", ")); std::cerr<<"\n";
	std::copy(pred.begin(), pred.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
	//g.print();
}

void mst(){
	//g.isDirected()=false;
	srand(GetTickCount());
	g.clear();
	//give nodes
	g.addNode('v',300,300);	g.addNode('a',200,300);	g.addNode('b',400,300);
	g.addNode('c',200,200); g.addNode('d',300,200);	g.addNode('e',400,200);	
	g.addNode('f',200,100);	g.addNode('g',300,100);	g.addNode('h',400,100);	
	//give edges
	g.addEdge(0,1,1);	g.addEdge(0,2,6);
	g.addEdge(3,4,4);	g.addEdge(4,5,7);
	g.addEdge(7,6,13);	g.addEdge(8,7,11);
	g.addEdge(1,3,2);	g.addEdge(0,4,9); g.addEdge(2,5,3);
	g.addEdge(3,6,10);	g.addEdge(4,7,12); g.addEdge(5,8,5);

	vector<float> dist;
	g.minSpanTree_Prim(dist);
	std::copy(dist.begin(), dist.end(),std::ostream_iterator<float>(std::cout,", ")); std::cerr<<"\n";
}

void max_mst(){
	//g.isDirected()=true;
	using namespace std;
	srand(GetTickCount());
	g.clear();
	ForIndex(i,123)
		g.addNode(' ', Random(100, 700), Random(100, 700));
	ForIndex(i,g.sizeNode()){
		int from = i;

		set<int> tos;
		while(tos.size()<3){
			int to =from;
			while(from==to){
				to = Random(0, g.sizeNode()-1);
			}
			tos.insert(to);
		}	
		for(set<int>::const_iterator it = tos.begin(); it!=tos.end(); ++it)
			g.addEdge(from, *it, Random(0,10));
	}
// 	ForIndex(i, g.sizeNode()){
// 
// 		g.addEdge(i, (i+1)%g.sizeNode(), Random(1,10));
// 		g.addEdge(i, (i+2)%g.sizeNode(), Random(1,10));
// 
// 	}
	vector<float> dist;
	float maxc = g.maxSpanTree_Prim(dist);
	ForIndex(i, g.sizeEdge()){	
		g.edges[i].weight *= -1.0f;
	}
	float minc = -g.minSpanTree_Prim(dist);
	//if(maxc!=minc)
	std::cerr<<"maxc "<<maxc<< " minc "<<minc<<"\n";
}


void allPairSP(){
	std::cerr<<"all-pair shortest path length matrix:\n";
	//g.isDirected() = true;
	g.clear();

	g.clear();
	g.addNode('v',300,400);	g.addNode('a',200,400);	g.addNode('b',400,400);	
	g.addNode('c',200,300);	g.addNode('d',300,300);	g.addNode('e',400,300);	
	g.addNode('f',200,200);	g.addNode('g',300,200);	g.addNode('h',400,200);	
	//give edges
	//g.addEdge(3,3,1*c+d);	
	
	g.addEdge(0,1,1*c+d);	g.addEdge(0,2,5*c+d);	
	g.addEdge(3,4,4*c+d);	g.addEdge(4,5,2*c+d);
	g.addEdge(7,6,2*c+d);	g.addEdge(8,7,3*c+d);
	g.addEdge(1,3,2*c+d);	g.addEdge(0,4,9*c+d); g.addEdge(2,5,3*c+d);
	g.addEdge(3,6,9*c+d);	g.addEdge(4,7,4*c+d); g.addEdge(5,8,1*c+d);

	vector<vector<float>> D;
	g.allPairShortestPath_floydWarshall(D);

	ForIndex(i, D.size()){
		printStl(" ", D[i]);
		std::cerr<<"\n";
	}
}

void biconnectedComponent(){
	g.clear();
	//g.isDirected() = false;
	g.addNode('A',210,600-48); //0
	g.addNode('B',200,600-308); //1
	g.addNode('C',341,600-443); //2
	g.addNode('D',198,600-446); //3
	g.addNode('E',198,600-579); //4
	g.addNode('F',350,600-156); //5
	g.addNode('G',110,600-519); //6
	g.addNode('H',42,600-391); //7
	g.addNode('I',111,600-583); //8
	g.addNode('J',20,600-223); //9
	g.addNode('K',112,600-401); //10
	g.addNode('L',100,600-145); //11
	g.addNode('M',100,600-308); //12
	g.addEdge(0, 11, 1);//A-L
	g.addEdge(0, 1, 1); //A-B
	g.addEdge(0, 2, 1); //A-C
	g.addEdge(0, 5, 1); //A-F 
	g.addEdge(11,12, 1);//L-M
	g.addEdge(9,11, 1); //L-J
	g.addEdge(9,12, 1); //J-M
	g.addEdge(1,7, 1); //B-H
	g.addEdge(1,3, 1); //B-D
	g.addEdge(1,2, 1); //B-C
	g.addEdge(3,4, 1); //D-E
	g.addEdge(1,12, 1); //B-M
	g.addEdge(7,10, 1); //H-K
	g.addEdge(10,6, 1); //K-G
	g.addEdge(6, 8, 1); //G-I
	g.addEdge(1, 6, 1); //B-G
	g.addEdge(7, 6, 1); //H-G

// 	g.addEdge(4,8);
// 	g.addEdge(7, 12);
	g.biconnectedComponent();
}

void biconnectedComponent2(){ //����7.25
	g.clear();
	//g.isDirected() = false;
	g.addNode('A'); //0
	g.addNode('B'); //1
	g.addNode('C'); //2
	g.addNode('D'); //3
	g.addNode('E'); //4
	g.addNode('F'); //5
	g.addNode('G'); //6
	g.addNode('H'); //7
	g.addNode('I'); //8
	g.addNode('J'); //9
	g.addNode('K'); //10
	g.addNode('L'); //11
	g.addNode('M'); //12
	g.addNode('N'); //13
	g.addNode('O'); //14
	g.addNode('P'); //15
	
	g.addEdge(0, 1, 1);//ab
	g.addEdge(1, 2, 1); //bc
	g.addEdge(3, 2, 1); //cd
	g.addEdge(3, 4, 1); //de 
	g.addEdge(3, 5, 1);//df
	g.addEdge(6, 2, 1); //cg
 	g.addEdge(1, 7, 1); //bh
	g.addEdge(8,7, 1); //hi
	//g.addEdge(7,9, 1); //hj  /*���Ӹ����ߺϲ�������֧*/
 	g.addEdge(8,9, 1); //ij
 	g.addEdge(9,10, 1); //jk
	g.addEdge(9,11, 1); //jl
 	g.addEdge(0,12, 1); //am
 	g.addEdge(12,13, 1); //mn
 	g.addEdge(13, 14, 1); //no
 	g.addEdge(13, 15, 1); //np
	//dash
 	g.addEdge(7, 0, 1); //ah
	g.addEdge(1, 6, 1); //gb
	g.addEdge(2, 5, 1); //cf
	g.addEdge(1, 4, 1); //eb
	g.addEdge(8, 10, 1); //ik
	g.addEdge(8, 11, 1); //il
	g.addEdge(0, 13, 1); //an
	g.addEdge(0, 15, 1); //ap
	
	g.biconnectedComponent() ;
}

void biconnectedComponent3(){ //another example.
	g.clear();
	//g.isDirected() = false;
	g.addNode('A',210,600-48); //0
	g.addNode('B',200,600-308); //1
	g.addNode('C',341,600-443); //2
	g.addNode('D',198,600-446); //3
	g.addNode('E',198,600-579); //4
	g.addNode('F',350,600-156); //5
	g.addNode('G',110,600-519); //6
	g.addNode('H',42,600-391); //7
	g.addNode('I',111,600-583); //8
	g.addNode('J',20,600-223); //9
	g.addNode('K',112,600-401); //10
	g.addNode('L',100,600-145); //11
	g.addEdge(0, 2, 1);	//A-C
	g.addEdge(0, 5, 1); //A-F
	g.addEdge(1, 3, 1); //B-D
	g.addEdge(7, 1, 1); //B-H
	g.addEdge(3, 7, 1); //H-D
	g.addEdge(2, 7, 1); //C-H
	g.addEdge(5, 4, 1); //E-F
	g.addEdge(7, 4, 1); //H-E
	g.addEdge(7, 6, 1); //H-E
	g.addEdge(7, 8, 1); //H-I
	g.addEdge(8, 4, 1); //I-E
	g.addEdge(8, 9, 1); //I-J
	g.addEdge(9, 10, 1); //I-K
	g.addEdge(9, 11, 1); //L-K
	g.addEdge(10,11, 1); //J-L
	g.addEdge(10,8, 1); //J-L
	//g.dfsOrdering(7);
	g.biconnectedComponent();
}

void scc(){
	g.clear();
	//g.isDirected() = true;
	g.addNode('A'); //0
	g.addNode('B'); //1
	g.addNode('C'); //2
	g.addNode('D'); //3
	g.addNode('E'); //4
	g.addNode('F'); //5
	g.addNode('G'); //6
	g.addNode('H'); //7
	g.addNode('I'); //8
	g.addNode('J'); //9
	g.addNode('K'); //10

	g.addEdge(0,1);//ab
	g.addEdge(1,2);//bc
	g.addEdge(2,3);//cd
	g.addEdge(3,4);//de
	g.addEdge(2,5);//cf
	g.addEdge(5,6);//fg
	g.addEdge(6,10);//gk
	g.addEdge(0,7);//ah
	g.addEdge(7,8);//hi
	g.addEdge(8,10);//ik
	g.addEdge(8,9);//ij

	g.addEdge(4,1);//eb
	g.addEdge(6,4);//ge
	g.addEdge(7,2);//hc
	g.addEdge(9,5);//jf
	g.addEdge(10,6);//kg
	g.addEdge(9,0);//ja

	g.stronglyConnectedComponent();
}


void testDijk_inDirected()
{	
	using namespace std;
	srand(GetTickCount());
	g.clear();
	g.isDirected() = true;
// 	ForIndex(i,5)
// 		g.addNode(' ', Random(100, 700), Random(100, 700));
// 	typedef Edge<Node,float> ETYPE;	
// 	vector<ETYPE> es;
// 	ForIndex(i,g.sizeNode()){
// 		int from = i;
// 		set<int> tos;
// 		while(tos.size()<2){
// 			int to =from;
// 			while(from==to){
// 				to = Random(0, g.sizeNode()-0.1);
// 			}
// 			tos.insert(to);
// 		}	
// 		for(set<int>::const_iterator it = tos.begin(); it!=tos.end(); ++it)
// 			es.push_back(ETYPE(&g.nodes[from], &g.nodes[*it], Random(0, 10)));
// 	}
// 	g.isDirected() = false;
// 	g.removeAllEdge();
// 	ForIndex(i, es.size())	g.addEdge(es[i]);
// 	g.isDirected() = true;
// 	g.removeAllEdge();
// 	ForIndex(i, es.size())	g.addEdge(es[i]);

	g.addNode('a', 100, 100);
	g.addNode('b', 100, 200);
	g.addNode('c', 200, 200);
	g.addNode('d', 200, 100);
	g.removeAllEdge();
	g.addEdge(0,1,1);
	g.addEdge(0,0,0.5);
	g.addEdge(1,2,2);
	g.addEdge(2,3,1);
	g.addEdge(3,0,3);
	g.addEdge(2,1,0.5);

	vector<float> dist;
	vector<int>   pred;
	g.dijkstra_SingleSource(0, dist, pred);
	std::copy(dist.begin(), dist.end(),std::ostream_iterator<float>(std::cout,", ")); std::cerr<<"\n";
	std::copy(pred.begin(), pred.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";

// 	g.removeAllEdge();
// 	g.addEdge(0,1,1);
// 	g.addEdge(1,2,2);
// 	g.addEdge(2,3,3);
// 	g.addEdge(3,0,4);
// 
// 	vector<float> dist_dir;
// 	vector<int>   pred_dir;
// 	g.dijkstra_SingleSource(0, dist_dir, pred_dir);
// 	std::copy(dist_dir.begin(), dist_dir.end(),std::ostream_iterator<float>(std::cout,", ")); std::cerr<<"\n";
// 	std::copy(pred_dir.begin(), pred_dir.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
// 
// 	ForIndex(i, dist.size()){
// 		if(dist[i]!=dist_dir[i])
// 			std::cerr<<"dist not match\n";
// 		if(pred[i]!=pred_dir[i])
// 			std::cerr<<"pred not match\n";
// 	}
}

void topoSort(){
	g.clear();
	//g.isDirected() = true;

	g.addNode('A'); //0	
	g.addNode('B'); //1
	g.addNode('C'); //2
	g.addNode('D'); //3
	g.addNode('E'); //4

	g.addEdge(0, 1, 1);
	g.addEdge(0, 2, 1);
	g.addEdge(0, 4, 1);
	g.addEdge(1, 3, 1);
	g.addEdge(1, 2, 1);
	
	g.addEdge(3, 2, 1);
	g.addEdge(4, 3, 1);
	
	g.addEdge(2, 1, 1);

	g.topologicalSort();
}
