// integerPartition.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <vector>
#include <iostream>
#include <iterator>
using namespace std;
// bool integerPartition(const vector<int> &a)
// {
// 	int n = a.size();
// 	int S = 0;	
// 	
// 	for (int i=0; i<n; i++)
// 		S += a[i];
// 	
// 	int halfS = S/2+1;
// 	vector<vector<bool> > DPtable(halfS);
// 	for (int i=0; i<halfS; i++)
// 		DPtable[i].resize(n+1);
// 	
// 	for (int i=0; i<n+1; i++)
// 		DPtable[0][i] = true;
// 
// 	for (int i=1; i<halfS; i++)
// 		DPtable[i][0] = false;
// 
// 	for (int i=1; i<halfS; i++)
// 	{
// 		for (int j=1; j<=n; j++)
// 		{
// 			int rest = i-a[j-1];
// 			if(rest>=0 ){
// 				if(DPtable[i][j-1] == true  || DPtable[ rest ][j-1] == true)
// 					DPtable[i][j] = true;
// 			}
// 			else{
// 				if(DPtable[i][j-1] == true )
// 					DPtable[i][j] = true;
// 			}
// 		}
// 	}
// 	
// 	return DPtable[S/2][n];
// }

bool integerPartition_path(const vector<int> &a, vector<int> &_solution){
	int n = a.size();
	if(n<2){
		_solution = a;
		return false;
	}
	int S = 0;	
	for (int i=0; i<n; i++){
		if(a[i]<0){
			std::cerr<<"error : must be positive!\n";
			return false;
		}
		S += a[i];
	}
	
	//std::cerr<<"sum "<<S<<"\n";

	int midS = S/2;

	vector<vector< pair<bool,int> > > table(midS+1);
	for (int i=0; i<=midS; i++)
		table[i].resize(n+1);

	for (int i=0; i<=n; i++)
		table[0][i] = make_pair(true,-1);

	for (int i=1; i<=midS; i++)
		table[i][0] = make_pair(false,-1);

	bool strictEqul = false;
	
	if(S%2!=0)
		strictEqul = false;

	for (int i=1; i<=S; i++)
	{
		if(i>midS){
			if(table[midS][n].first==true){
				if(S%2==0)
					strictEqul = true;
				//std::cerr<<"~~~~~~~quit at midS = < "<<midS<<" >\n";
				break;
			}

			if(table[i-1].back().first==true){
				//std::cerr<<"~~~~~~~quit at < "<<i-1<<" >\n";
				break;
			}
			table.resize(i+1);
			table[i].resize(n+1);
			table[i][0] = make_pair(false,-1);
		}


		for (int j=1; j<=n; j++)
		{
			if(table[i][j-1].first == true)
				table[i][j] = make_pair(true, -1);
			else{
				int rest = i-a[j-1];
				if(rest>=0 ){
					if( table[ rest ][j-1].first == true)
						table[i][j] = make_pair(true, a[j-1]);
				}
			}
		}
	}

	/*search where to backtrack, i.e., closest row to midS*/
	int e=-1;
	if(strictEqul){
		e = midS;
	}
	else{
		for (int offset=0; ; offset++)
		{
			int sum_pos = midS + offset;
			if(sum_pos<=table.size()-1){
				if(table[sum_pos].back().first==true){
					e = sum_pos;
					break;
				}
			}

			int sum_neg = midS - offset;
			if(sum_neg>0){
				if(table[sum_neg].back().first==true){
					e = sum_neg;
					break;
				}
			}
		}
	}

	
	_solution.clear();

	for (int i=e; i>0; )
	{
		for (int j=n; j>=0; j--){
			int tail = table[i][j].second;
			if(tail!=-1){
				_solution.push_back(tail);
				i -= tail;
				break;
			}
		}
	}

	return strictEqul;
}

#include "windows.h"
#include <numeric>
int _tmain(int argc, _TCHAR* argv[])
{
	
	int success = 0;
	int fail = 0;

	int nTest = 10000;
	int N = 10;
	while (nTest>=0){
		vector<int> a;
		nTest--;
		srand(GetTickCount());
		for (int i=0; i<N; i++)
		{
			a.push_back(rand()/float(RAND_MAX) * 200);
		}
	
		int sum = std::accumulate(a.begin(), a.end(), 0);
	
		if(sum%2){
			a.push_back(1); //make sure the sum is even.
			sum++;
		}

		vector<int> solution;
		bool s = integerPartition_path(a,solution);

		if(s){
			success ++;
			if(0){
				std::cerr<<" a :";
				std::copy(a.begin(), a.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"sum["<<sum<<"]\n";

				std::cerr<<"exact solution exist.\n";
				std::cerr<<"part 1 : ";
				std::copy(solution.begin(), solution.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
			}
		}
		else{
			fail ++;
		}
	}

	std::cerr<<"success "<<success<<"\n";
	std::cerr<<"fail "<<fail<<"\n";

	return 0;
}

