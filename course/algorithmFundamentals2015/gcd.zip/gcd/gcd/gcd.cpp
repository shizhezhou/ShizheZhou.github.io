// gcd.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int gcd_v0(int a, int b){
	while(1){		
		if( b>=a ){ /*�����whileѭ������ĳ����֧���ܲ��ı��κ���ֵ��Ҳ���˳����ͻᵼ��һ����ѭ��*/
			b -= a;		
			if(b==0) return a;
		}
		else{
			a -= b;
			if(a==0) return b;
		}		
	}
}


int gcd_v1(int a, int b){
	while(1){	
		if(b==0) return a;
		if(a==0) return b;
		else{
			if( b>=a ){
				b -= a;		
				if(b==0) return a;
			}
			else{
				a -= b;
				if(a==0) return b;
			}
			
		} 
	}
}

int gcd_v2(int a, int b){
	while(1){	
		if(b==0) return a;
		if(a==0) return b;
		else{
			if( b>=a )	b -= a;						
			else		a -= b;							
		} 
	}
}

/*least common multiple*/
int lcm(int a, int b){
	if(a==0) return 0;
	if(b==0) return 0;
	int ma = a, mb = b;
	while(1){	
		if(mb==ma) return ma;		
		else{
			if( mb>=ma ) ma += a;						
			else		 mb += b;							
		} 
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	//int x =  gcd_v0(75,38);

	int x =  lcm(9,15);


	printf("%d", x);

	return 0;
}

