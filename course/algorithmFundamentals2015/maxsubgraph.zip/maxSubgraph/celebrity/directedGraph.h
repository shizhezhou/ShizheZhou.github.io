#pragma  once
#include "windows.h"
#include <vector>
using namespace std;

static int N = 5;
static vector< vector<bool> > matrix;

inline void initMatrix(){
	matrix.resize(N);
	for (int i=0; i<N; i++)
		matrix[i].resize(N);
}

inline void setDirectedGraph(){
	srand(GetTickCount());
	for (int i=0; i<N; i++)	
		for (int j=0; j<N; j++)
			matrix[i][j] = rand()%2? true : false;
	for (int i=0; i<N; i++)	
		matrix[i][i] = false;
}

inline void printGraph(const vector<vector<bool> >& g){
	printf("the graph:\n");
	for (int i=0; i<g.size(); i++){
		for (int j=0; j<g.size(); j++)	printf("%d, ", g[i][j]); 
		printf("\n");
	}
}

inline int degree(int v, const vector<vector<bool>>& g){
	int de(0);
	int nv = g.size();
	for (int i=0; i<nv; i++){
		if(i==v)	continue;
		if(g[v][i])	de++;
	}
	return de;
}

inline bool isCompleteGraph(const vector<vector<bool> >& g){
	int nv = g.size();
	for (int i=0; i<nv; i++)
	for (int j=0; j<nv; j++)
	{
		if(i==j) continue;
		if(!g[i][j]) return false;
	}
	return true;
}

inline void subgraph(const vector<int> &v, const vector<vector<bool> > &g, vector<vector<bool> > &_sub){
	int nv = v.size();
	_sub.resize(nv);
	for (int vi=0; vi<nv; vi++){
		_sub[vi].resize(nv);
		for (int vj=0; vj<nv; vj++)
			_sub[vi][vj] = g[v[vi]][v[vj]];
	}
}