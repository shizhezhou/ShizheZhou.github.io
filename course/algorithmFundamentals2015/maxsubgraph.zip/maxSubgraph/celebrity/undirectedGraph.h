#pragma  once
#include "windows.h"
#include "directedGraph.h"

extern int N;
extern vector<vector<bool> > matrix;

inline void setUndirectedGraph() //symmetrize the matrix
{ 	
	setDirectedGraph();
	for (int i=0; i<N; i++) //each row
	for (int j=0; j<i; j++)	//each column to the diagonal. 
		matrix[i][j] = matrix[j][i];
};