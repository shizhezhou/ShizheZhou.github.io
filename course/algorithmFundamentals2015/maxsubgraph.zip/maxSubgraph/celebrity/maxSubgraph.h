#include "stdafx.h"
#include "undirectedGraph.h"

// inline bool maxSubgraph(int k, const vector<vector<bool> >& g){ 
// 	vector<int> subV;
// 	for (int i=0; i<g.size(); i++){
// 		if( degree(i, g)>=k ) 
// 			subV.push_back(i);
// 	}
// 	if(subV.size()==g.size()){
// 		printf("the %d-subgraph:\n", k);
// 		printGraph(g);
// 		return true;
// 	}
// 	else{
// 		vector<vector<bool> > subG;
// 		subgraph(subV, g, subG);
// 
// 		if(subG.size()==k){
// 			if(isCompleteGraph(subG)){
// 				printf("the %d-subgraph:\n", k);
// 				printGraph(subG);
// 				return true;
// 			}
// 			else
// 				return false;
// 		}
// 		else if(subG.size()<k){
// 			return false;
// 		}
// 		else {
// 			return maxSubgraph(k, subG);
// 		}
// 	}
// }

static vector<int> subVs;

inline bool maxSubgraph(int k, const vector<vector<bool> >& g){ 
	if(g.size()<k){
		subVs.clear();
		return false;
	}
	else if(g.size()==k+1){
		if(isCompleteGraph(g)){
			printf("the %d-subgraph:\n", k);
			printGraph(g);
			return true;
		}
		else{
			subVs.clear();
			return false;
		}
	}
	else{
		vector<int> subV;
		for (int i=0; i<g.size(); i++){
			if( degree(i, g)>=k ) 
				subV.push_back(i);
		}
		vector<int> vs;
		for (int i=0; i<subV.size(); i++)
			vs.push_back(subVs[subV[i]]);
		subVs = vs;

		if(subV.size()==g.size()){
			printf("the %d-subgraph:\n", k);
			printGraph(g);
			return true;
		}
		else{
			vector<vector<bool> > subG;
			subgraph(subV, g, subG);
			return maxSubgraph(k, subG);
		}
	}
}

