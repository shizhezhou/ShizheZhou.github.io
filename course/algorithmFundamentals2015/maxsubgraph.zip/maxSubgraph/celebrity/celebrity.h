// celebrity.cpp : Defines the entry point for the console application.
//
#pragma  once
#include "stdafx.h"
#include "directedGraph.h"

static int candidate;

inline bool findCelebrity(){
	
	int i = 0, j = 1;
	int next = j+1;
	while(next<N){
		if(matrix[i][j]){
			i = j;
			j = next;
		}
		else{
			j = next;
		}
		next++;
	}
	if(matrix[i][j]){
		candidate = j;
	}
	else
		candidate = i;

	i = 0;
	while(i<N){
		if(i!=candidate){
			if(matrix[candidate][i] || !matrix[i][candidate])
				return false;
		}
		i++;
	}
	return true;
}


