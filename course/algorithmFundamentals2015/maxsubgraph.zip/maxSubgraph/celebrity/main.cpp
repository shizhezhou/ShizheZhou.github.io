#include "stdafx.h"
#include <vector>
#include <iterator>
#include <iostream>
#include "celebrity.h"
#include "maxSubgraph.h"

void solve_Celebrity(){
	setDirectedGraph();
	int c=0;
	do{
		setDirectedGraph();
		c++;
	}
	while(!findCelebrity());
	printGraph(matrix);
	std::cerr<<"celebrity "<<candidate<<" in "<<c<<"th search\n";
}

void solve_maxSubgraph(int k){
	int c=0;
	do{
		setUndirectedGraph();
		subVs.clear();
		for (int i=0; i<matrix.size(); i++)	subVs.push_back(i);
		c++;
	}
	while(!maxSubgraph(k, matrix));

	printf("sub v: ");
	std::copy(subVs.begin(), subVs.end(),std::ostream_iterator<int>(std::cout,", "));
	std::cerr<<"\n";

	printGraph(matrix);
	std::cerr<<"in "<<c<<" search"<<"\n";
}
int _tmain(int argc, _TCHAR* argv[])
{
	N = 7;
	initMatrix();
	//solve_Celebrity();
	solve_maxSubgraph(4);

	return 0;
}