// quickSort.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

template<class T> 
int partition(T* a, int left, int right){
	int L = left;
	int R = right;
	int oldPivot = left;
	while(L<R){
		while(a[oldPivot]>=a[L] && L<=right)
			L++;
		while(a[oldPivot]<a[R] && R>=left)
			R--;

		if(L<R){
			swap(a[L], a[R]);
		}
	}

	int pivot = R;
	swap(a[oldPivot], a[pivot]);
	return pivot;
}

template<class T>
void q_sort_run(T* a, int L, int R){
	if(L<R){
		int mid = partition(a, L, R);
		q_sort_run(a, L, mid-1);
		q_sort_run(a, mid+1, R);
	}
	
};

template<class T>
void quickSort(T* a, int n){
	q_sort_run(a, 0, n-1);
}

template<class T>
T select_run(T *a , int left, int right , int k){
	if(left==right)
		return a[left];
	else{
		int mid = partition(a, left, right);
		if(mid-left+1>=k)
			return select_run(a, left, mid, k);
		else
			return select_run(a, mid+1, right, k-(mid-left+1));
	}
}

template<class T>
T selection(T* a, int n , int K){
	if(K<0 || K>=n ){
		std::cerr<<"error!";
		return -1;
	}
	else
		return select_run(a, 0, n-1, K);

}

#include <math.h>
#include <windows.h>
#include <vector>
#include <iterator>
#include <iostream>
using namespace std;

vector<int> x;

int _tmain(int argc, _TCHAR* argv[])
{


	int n = 12;
	srand(GetTickCount());

// 	x.push_back(6);
// 	x.push_back(2);
// 	x.push_back(8);
// 	x.push_back(5);
// 	x.push_back(10);
// 	x.push_back(9);
// 	x.push_back(12);
// 	x.push_back(1);
// 	x.push_back(15);
// 	x.push_back(7);
// 	x.push_back(3);
// 	x.push_back(13);
// 	x.push_back(4);
// 	x.push_back(11);
// 	x.push_back(16);
// 	x.push_back(14);

	for (int i=0; i<n; i++)
	{
		x.push_back(rand());
	}
	
	std::copy(x.begin(), x.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
	
	int kk = 5;
	std::cerr<<"selection: the "<<kk<<"th min element:"; 
	std::cerr<<selection(&x[0], x.size(), kk);
	std::cerr<<"\n";

	vector <int> y = x;
	quickSort(&y[0],y.size());
	
	std::cerr<<"\n[";
	std::copy(y.begin(), y.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\b\b]";
	return 0;
}

