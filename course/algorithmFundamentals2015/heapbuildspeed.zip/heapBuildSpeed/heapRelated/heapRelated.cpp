//simple heap class for students, if you detect bugs, please email to szhou@ustc.edu.cn

#include "stdafx.h"
#include <Windows.h>
#include "StopWatch.hpp"
#include <vector>
#include <iterator>
#include <iostream>
Stopwatch timer;

/*A MAXHEAP */

enum buildHeapStrategy{topDown = 0, downTop = 1};
template<class T>  
class Heap{
public: 
	buildHeapStrategy strategy;
	Heap(T *array, int _n, buildHeapStrategy _strategy){
		if(array&&_n){
			strategy = _strategy;
			m_h = array;
			m_n= _n;
			if(strategy==topDown)
				buildHeapTopDown();
			else
				buildHeapBottomUp();

			if(!isValidHeap())	
				std::cerr<<"build failed!\n";
		
		}
	}
	//~Heap(){ if(m_h) delete[] m_h; }

protected:
	void buildHeapTopDown(){  //make inplace heap by insertion one-after one !  this is top-down manner, slow!
		timer.Reset();
		for(int i=0; i<m_n; i++){
			node_climb_at(i);
		}
		std::cerr<<"top-down building: "<<timer.GetTime()*1000<<"ms\n";
	}
	void node_climb_at(int i){

		int parent = int((i+1)/2)-1;
		int child = i;
		while(parent>=0){
			if( m_h[child]>m_h[parent] ){
				swap(m_h[child], m_h[parent]);
				child = parent;
				parent = int((parent+1)/2) - 1;
			}
			else
				break;
		}
	}
	void buildHeapBottomUp(){
		timer.Reset();
		
		int node = m_n/2-1;// the subheap top, skip all the leaves!

		while(node>=0){
			
			int i = node ; //now we iteratively adjust the heap lead by this node. So i will climb down the tree!
			 
			while (i <= m_n/2-1){
				int child_L = i*2+1;
				int child_R = i*2+2;

				int biggerChild;

				//get the bigger child!
				if(child_R>m_n-1){
					biggerChild = child_L;
				}
				else{
					if(m_h[child_L] > m_h[child_R])
						biggerChild = child_L;
					else
						biggerChild  = child_R;
				}
			
				if(m_h[i]<m_h[biggerChild]){
					swap(m_h[biggerChild], m_h[i]);
					i = biggerChild;
				}
				else 
					break;
			}
			node--;
		}
		std::cerr<<"bottom-Up building: "<<timer.GetTime()*1000<<"ms\n";
	}

	bool isValidHeap(){
		int i = 0;
		while(i<m_n/2){

			int child_L = i*2+1;
			int child_R = i*2+2;
			if(child_R>m_n-1){
				if( m_h[i]<m_h[child_L])
					return false;
			}
			else{
				if( m_h[i]<m_h[child_L] ||  m_h[i]<m_h[child_R]){
					return false;
				}
			}
			
			i++;
		}
		return true;
	}
protected:
	int m_n;	
	T  *m_h;

private:
void swap(T &a, T &b){
	T c = a;
	a = b;
	b = c;
}

public:
	T pop(){
		if(m_n>0){
			T top = m_h[0];
			m_h[0] = m_h[m_n-1];
			m_n--;
			int parent = 0;
			int child = parent*2+1;  
	
			while( child <=m_n-1 ){
				if(m_h[child]<m_h[child+1])
					child = child + 1; 
				if(m_h[child] > m_h[parent]){
					swap(m_h[child], m_h[parent]);
					parent = child;
					child = child*2+1; 
				}
				else
					break;
			}
			return top;
		}
		else{
			return 0;
		}
	}

	T top(){ return m_h[0]; }

	void print(){
		for (int i=0; i<m_n; i++)	printf("%d ", m_h[i]);
	}
};

const int n = 66666;
double G_topDown[n];
double G_downTop[n];


void testSpeed(){
	
	std::cerr<<"testing two building method of heapsort, #elements = "<<n<<"\n";

	timer.Start();

	for (int test=0; test<115; test++)
	{
		srand(time(0));
		for(int i=0; i<n; i++){	
			G_topDown[i] = rand();
			G_downTop[i] = G_topDown[i];
		}		


		Heap<double> H_downTop(G_downTop, n, downTop);
		Heap<double> H_topDown(G_topDown, n, topDown);


		for(int i=0; i<n; i++){
			//std::cerr<<H_downTop.top()<<" ";
			if(H_downTop.pop()!=H_topDown.pop())
				Beep(1000,3000);
		}

	}
}


int _tmain(int argc, _TCHAR* argv[])
{
	testSpeed();
	_CrtDumpMemoryLeaks();
}

