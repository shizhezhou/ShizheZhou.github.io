//code for student taking the course of Algorithm Fundamentals(00125401), bug report please email: shizhezhou2014@gmail.com


#include "stdafx.h"
#include <vector>
#include <iterator>
#include <iostream>
using namespace std;

template<class T> 
int partition(T* a, int left, int right){
	int L = left;
	int R = right;
	int oldPivot = left;
	while(L<R){
		while(a[oldPivot]>=a[L] && L<=right)
			L++;
		while(a[oldPivot]<a[R] && R>=left)
			R--;

		if(L<R){
			swap(a[L], a[R]);
		}
	}

	int pivot = R;
	swap(a[oldPivot], a[pivot]);
	return pivot;
}

template<class T>
T select_run(T *a , int left, int right , int k){
	if(left==right)
		return a[left];
	else{
		int mid = partition(a, left, right);	
		if(mid-left>=k){
			if(a[left]==a[mid])
				return a[left];
			return select_run(a, left, mid, k);
		}
		else{
			if(a[right]==a[mid+1])
				return a[right];
			return select_run(a, mid+1, right, k-(mid-left+1));
		}
	}
}

template<class T>
T selection(T* a, int n, int K){ /*function : 6.5.2 pick the i th min element.*/
	if(K<0 || K>=n ){
		std::cerr<<"error!";
		return -1;
	}
	else
		return select_run(a, 0, n-1, K);
}

template<class T>
void multiplicity(vector<T>& a){ /*function :6.10 computing the majority in an array by validating the median 
									  (if there is a majority it must be the median[the n/2 the min element])*/
	int n = a.size();
	T median = selection(&a[0], n, n/2);

	//validating
	int mul = 0;
	for (int i=0; i<n; i++)
		if(a[i]==median)	mul++;
	
	if(mul>n/2)
		std::cerr<<"majority is "<<median<<"\n";
	else
		std::cerr<<"no majority\n";
}

#include "windows.h"
#include <algorithm>

void sortingBySelection(){
	
	std::cerr<<"sortingBySelection\n";

	for (int j=0; j<3; j++)
	{	
		std::cerr<<"test "<<j<<"\n";

		vector<int> a;

		srand(GetTickCount());

		int N = 10;
		for (int i=0; i<N; i++){
			a.push_back(rand());
			a.push_back(rand()*0.1);
		}

		vector<int> aa;

		for (int i=0; i<a.size(); i++) 
		{
			int s = selection(&a[0], a.size(), i); //attention: crashes if 'a' contains identical elements.
			std::cerr<<s<<" , ";
			aa.push_back(s);
		}

		if(a!=aa){
			for (int i=0; i<a.size(); i++)
			{
				if(a[i]!=aa[i])
					std::cerr<<"i="<<i<<" wrong \t";
			}
			Beep(1000,200);
		}
		else
			std::cerr<<"[correct!]\n";
	}
}

void findMajority(){
	std::cerr<<"\nmultiplicity\t";

	vector<int> a;
	srand(GetTickCount());
	for (int i=0; i<9; i++)
	{
		a.push_back(float(rand())/FLOAT(RAND_MAX)*3.0f);
	}
	
	std::sort(a.begin(), a.end());
	std::copy(a.begin(), a.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";

	multiplicity(a);
}

int _tmain(int argc, _TCHAR* argv[])
{	
	sortingBySelection();
	findMajority();
	return 0;
}

