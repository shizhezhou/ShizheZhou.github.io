#define ForIndex(I,N)          for (int I=0;I<int(N);I++)
#define ForRange(I,A,B)        for (int I=int(A);I<=int(B);I++)
#define ForRangeReverse(I,A,B) for (int I=int(A);I>=int(B);I--)
#define SAFEDELETE(p)   {if(p) {delete  p; p=NULL;}}
#define SAFEDELETES(p)  {if(p){delete[] p;p=NULL;}}
inline bool ValidRange(int a, int low, int up){ return (a>=low&&a<=up);	}
#include "math.h"
#include "stdlib.h"
inline float Random(){ return (float)(rand()) / (float)(RAND_MAX);}
inline float Random(float f1, float f2){ return Random() * (f2 - f1) + f1;}
