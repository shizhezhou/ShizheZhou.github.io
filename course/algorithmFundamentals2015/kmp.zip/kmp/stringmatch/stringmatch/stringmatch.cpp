// stringmatch.cpp : Defines the entry point for the console application.

#include "stdafx.h"
#include "stdio.h"
#include "cpphelper.h"

#include <iostream>
#include <iterator>
#include <windows.h>

int* next(char* s){
	int n = strlen(s);
	int *m = new int[n];
	m[0] = -1;
	m[1] = 0;

	ForRange(i, 2, n-1){	
		int suf = i-1;		
		int pre = m[i-1];	
		while( s[pre] != s[suf] && pre>=0 )
		{
			pre = m[pre];	
		}
		m[i] = pre+1;
	}
	return m;
}

int _tmain(int argc, _TCHAR* argv[])
{
	char s[] = "xyxyyxyxyxx";
	int n = strlen(s);
	int *m = next(s);
	std::copy(&m[0], &m[n],std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
	return 0;
}

