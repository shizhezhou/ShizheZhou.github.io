#include "stdafx.h"
#include <vector>
#include <iostream>
#include <iterator>
using namespace std;

class node{
public:
	bool bFit;
	int tail;
	int n;
	float price; // summation of price over current choice. sigma(Pi*Ni)
	node(bool _bfit, int _tail, int _n ){
		bFit = _bfit;
		tail = _tail;
		n = _n;
	}
	node(){
		bFit = false;
		tail = -1;
		n = 0;
	}
};

bool packing_unique(int K, const vector<int> &a, vector<int> &_solution)
{	
	if(K<=0) return false;

	int n = a.size();
	
	int S = 0;
	for (int i=0; i<n; i++){
		S+=a[i];
		if(a[i]<=0){
			std::cerr<<"error : must be strictly positive!\n";
			return false;
		}
	}
	std::cerr<<"sumation "<<S<<"\n";

	vector<vector< node > > table(K+1);
	for(int i=0; i<=K; i++)
		table[i].resize(n+1);

	for(int i=0; i<=n; i++)
		table[0][i] = node(true, -1, 0);

	for (int i=1; i<=K; i++)
		table[i][0] = node(false,-1,0);


	for (int i=1; i<=K; i++)
	{
		for (int j=1; j<=n; j++)
		{
			if(table[i][j-1].bFit == true)
				table[i][j] = node(true, -1, 0);
			else{
				int rest = i-a[j-1];
				if(rest>=0 ){
					if( table[ rest ][j-1].bFit== true)
						table[i][j] = node(true, a[j-1], 1);
				}
			}
		}
	}

	/*search where to backtrack, i.e., closest row to midS*/
	
	if(table.back().back().bFit==true){

		_solution.clear();

		for (int i=K; i>0; )
		{
			for (int j=n; j>=0; j--){
				int tail = table[i][j].tail;
				if(tail!=-1){
					_solution.push_back(tail);
					i -= tail;
					break;
				}
			}
		}
		return true;
	}
	else
		return false;
}


bool packing_multiple(int K, const vector<int> &a, vector<pair<int,int> > &_solution)
{	
	if(K<=0) return false;

	int n = a.size();

	int S = 0;
	for (int i=0; i<n; i++){
		S+=a[i];
		if(a[i]<=0){
			std::cerr<<"error : must be positive!\n";
			return false;
		}
	}
	//std::cerr<<"sumation "<<S<<"\n";

	vector<vector< node > > table(K+1);
	for(int i=0; i<=K; i++)
		table[i].resize(n+1);

	for(int i=0; i<=n; i++)
		table[0][i] = node(true, -1, 0);

	for (int i=1; i<=K; i++)
		table[i][0] = node(false,-1,0);


	for (int i=1; i<=K; i++)
	{
		for (int j=1; j<=n; j++)
		{
			if(table[i][j-1].bFit == true)
				table[i][j] = node(true, -1, 0);
			else{
				int tail = a[j-1];
				int mod = 1;
				int rest = i-mod*tail;
				while( rest>=0  ){
					if(table[ rest ][j-1].bFit== true){
						table[i][j] = node(true, tail, mod);
						break;
					}
					else{
						rest-=tail;
						mod++;
					}		
				}
				if(rest<0){
					table[i][j] = node(false, -1, 0);
				}
			}
		}
	}

	/*search where to backtrack, i.e., closest row to midS*/

	if(table.back().back().bFit==true){  /*test if multi-backtracking leads to all possible solution!!*/

		_solution.clear();

		for (int i=K; i>0; )
		{
			for (int j=n; j>=0; j--){
				int tail = table[i][j].tail;
				if(tail!=-1){
					_solution.push_back(make_pair(tail, table[i][j].n));
					i -= _solution.back().first * _solution.back().second;
					break;
				}
			}
		}
		return true;
	}
	else
		return false;
}

vector<int> E;
const int numE = 100;
#include "windows.h"
void initElements()
{
	srand(GetTickCount());
	for (int i=0; i<numE; i++)
	{
		int y = rand()/float(RAND_MAX) * 20 + 1 ;
		if(y!=1)
			E.push_back(y) ;
	}

	/*
	//coin problems!
	E.push_back(1);
	E.push_back(2);
	E.push_back(5);
	*/

	std::copy(E.begin(), E.end(),std::ostream_iterator<int>(std::cout,", ")); std::cerr<<"\n";
}

int _tmain(int argc, _TCHAR* argv[])
{
	int K = 1000;
	initElements();
	
	bool hasSolultion; 

	vector<int> solution_unique;
	hasSolultion = packing_unique(K, E, solution_unique);
	if(hasSolultion){
		std::cerr<<"solution exist.\n";
		for (int i=0; i<solution_unique.size(); i++)
			std::cerr<<solution_unique[i]<<", ";	
	}
	else
		std::cerr<<"no solution when K=" <<K<<".\n";

	vector<pair<int,int> > solution;
	hasSolultion = packing_multiple(K, E, solution);
	if(hasSolultion){
		std::cerr<<"solution exist.\n";
		for (int i=0; i<solution.size(); i++)
			std::cerr<<"("<<solution[i].first<<"x"<<solution[i].second<<"), ";	
	}
	else
		std::cerr<<"no solution when K=" <<K<<".\n";

	return 0;
}

