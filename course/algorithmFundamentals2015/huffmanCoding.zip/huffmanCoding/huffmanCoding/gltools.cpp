#include "stdafx.h"
#include <string>
#include <xstring>
#include "cppHelper.h"
#include "c:\Lib\glut\include\GL\glut.h"
inline int NumDigits(int x)  
{  
	x = abs(x);  
	return (x < 10 ? 1 :   
		(x < 100 ? 2 :   
		(x < 1000 ? 3 :   
		(x < 10000 ? 4 :   
		(x < 100000 ? 5 :   
		(x < 1000000 ? 6 :   
		(x < 10000000 ? 7 :  
		(x < 100000000 ? 8 :  
		(x < 1000000000 ? 9 :  
		10)))))))));  
}

static char buffer [33];
void glPrintInt(int s, float x, float y){
	glRasterPos2f(x,y);
	int d = NumDigits(s);
	if(s<0) d++;
	_itoa_s(s,buffer,10);
	ForIndex(i,d)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, buffer[i]);
}

void glPrintFloat(float s, float x, float y){
	glRasterPos2f(x,y);
	sprintf_s(buffer, "%0.2f", s);
	ForIndex(i,strlen(buffer))
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, buffer[i]);
}

void glPrintString(char *s, float x, float y){
	glRasterPos2f(x,y);
	int d = strlen(s);
	ForIndex(i,d)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[i]);
}

void glPrintString(const std::string &s, float x, float y){
	glRasterPos2f(x,y);
	int d = s.size();
	ForIndex(i,d)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[i]);
}


void glPrintChar(char s, float x, float y){
	glRasterPos2f(x,y);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s);
}