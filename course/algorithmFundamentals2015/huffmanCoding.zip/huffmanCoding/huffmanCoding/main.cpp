#include "stdafx.h"
#include "minheap.h"
#include "bst.h"
#include <string>


typedef heapNodeType<float, std::string> Node;

typedef _TREE::huffmanTree<Node> HTree;

HTree htree;

Heap<Node> H(downTop);

void huffman(){
	H.insert(Node(5,	"A"));
	H.insert(Node(2,	"B"));
	H.insert(Node(3,	"C"));
	H.insert(Node(4,	"D"));
	H.insert(Node(10,	"E"));
	H.insert(Node(1,	"F"));
	H.print();
}

void huffmanTree_oneStep(){
	if(H.size()==0) return;

	if(H.size()==1){
		H.pop();
	}
	else{
		Node a = H.pop();
			
		Node b = H.pop();



		HTree* A = new HTree(a);
		HTree* B = new HTree(b);

		std::cerr<<a.key<<", "<<b.key<<" | ";

		Node *z = new Node(a+b);
		z->l() = A->m_root;
		z->r() = B->m_root;

		H.insert(*z);

		htree.m_root = z;		
	}

	H.print();
}


#include "c:\Lib\glut\include\GL\glut.h"

void printString(char *s);
void initFonts(void);

void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho (0.0, w, 0.0, h, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
}

GLfloat white[3] = { 1.0, 1.0, 1.0 };
GLfloat blue[3] = {  0.0, 0.0, 1.0 };
GLfloat red[3] = {  1.0, 0.0, 0.0 };

void display(void)
{	
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3fv(red);
	glPrintString("character Heap", 100, 900);
	glPrintString("huffman tree", 100, 600);

	glColor3fv(blue);
	glPrintString("PRESS A TO REDO HUFFMAN TREE BUILDING",20, 40);
	glPrintString("PRESS B TO DO NOTHING",20, 20);

	glColor3fv(white);	
	H.draw();
	htree.draw();

	glFlush();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'a':
		huffman();
		glutPostRedisplay();
		break;
	case 'b':
		huffmanTree_oneStep();
		glutPostRedisplay();
		break;
	}
}
#define  DO_DRAW 1


int _tmain(int argc, char* argv[])
{
	huffman();
	_CrtDumpMemoryLeaks();

#if DO_DRAW
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE| GLUT_RGB);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition (100, 100);
	glutCreateWindow("Huffman Encoding");
	initFonts();
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutSwapBuffers();
	glutMainLoop();
#endif 

	return 0;
}

