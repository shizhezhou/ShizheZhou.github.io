/*if you detect bugs, please email to szhou@ustc.edu.cn*/

/*binary search tree for students.*/

#include <iostream>
#include <iterator>
#include "minheap.h"
#include "c:\Lib\glut\include\GL\glut.h"

void glPrintInt(int s, float x, float y);
void glPrintFloat(float s, float x, float y);
void glPrintString(char *s, float x, float y);
void glPrintString(const std::string &s, float x, float y);
void glPrintChar(char s, float x, float y);

#pragma  once

using namespace std;

namespace _TREE{
// 
// template<class ValueType>  //not have to be key. We do not compare in Huffman tree!
// class heapNodeType{
// private:
// 	heapNodeType *_l;
// 	heapNodeType *_r;
// 	ValueType _a;
// public:
// 	heapNodeType()
// 	{
// 		_l = NULL;	_r = NULL;	
// 	}
// 	heapNodeType(ValueType t)
// 	{
// 		_l = NULL;	_r = NULL; _a = t;
// 	}
// 	(heapNodeType*) & l()	{ return _l; }
// 	heapNodeType* l() const { return _l; }
// 
// 	(heapNodeType*) & r()	{ return _r; }
// 	heapNodeType* r() const { return _r; }
// 
// 	ValueType& a()		{return _a;}
// 	ValueType  a()const	{return _a;}  
// 
// 	void draw(float x, float y){
// 		glPrintString(a(), x,y);
// 	}
// };


template<class Node>
class huffmanTree{
	
public:
	huffmanTree()			{	m_root = new Node;		}
	huffmanTree(Node t)		{	m_root = new Node(t);	}
	virtual ~huffmanTree()	{	_clear(m_root);			}
	void _clear(Node *rt){		
		if(rt){
			if(rt->l())	_clear(rt->l());
			if(rt->r())	_clear(rt->r());
			delete rt;
		}			
	}
	Node* m_root;

public:
	void draw(){
		float x = 300;
		float y = 500;		
		float dx = 150;
		float dy = 60;
		_draw(m_root, x, y, dx , dy);	
	}
protected:
	void _draw(Node * rt, float x, float y, float dx, float dy){

		if(rt){
			glRasterPos2f(x, y);
			rt->draw(x,y+15);

 			if(rt->l()){	
				glBegin(GL_LINES);
				glVertex2f(x,y);
				glVertex2f(x-dx, y-dy);
				glEnd();
				_draw(rt->l(), x-dx,  y-dy, dx*0.8, dy*0.95);

			}
 			if(rt->r()){
				glBegin(GL_LINES);
				glVertex2f(x,y);
				glVertex2f(x+dx, y-dy);
				glEnd();
				_draw(rt->r(), x+dx, y-dy, dx*0.8, dy*0.95);
			}
		}
	}
};

}