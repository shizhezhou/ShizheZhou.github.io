//simple heap class for students, if you detect bugs, please email to szhou@ustc.edu.cn
#pragma  once

#include <Windows.h>
#include "StopWatch.hpp"
#include <vector>
#include <iterator>
#include <iostream>
#include "c:\Lib\glut\include\GL\glut.h"
Stopwatch timer;

/*A MINHEAP */

enum buildHeapStrategy{topDown = 0, downTop = 1};
template<class keyType ,class ValueType>  
class heapNodeType{
public:
	keyType key;
	ValueType _a; //associated value
	heapNodeType *_l , *_r;
	heapNodeType()
	{
		_l = NULL;	_r = NULL;	
	}
	heapNodeType(const keyType &_k, const ValueType & aa){
		key = _k;
		_a = aa;
		_l = NULL;	_r = NULL; _a = aa;
	}
	heapNodeType(ValueType t)
	{
		key = -1000;
		_a = t;
		_l = NULL;	_r = NULL; _a = t;
	}
	heapNodeType(const heapNodeType& x)
	{
		key = x.key;	_a = x._a;	
		_l = x._l;	_r = x._r;	
	}
	(heapNodeType*) & l()	{ return _l; }
	heapNodeType* l() const { return _l; }

	(heapNodeType*) & r()	{ return _r; }
	heapNodeType* r() const { return _r; }

	ValueType& a()		{return _a;}
	ValueType  a()const	{return _a;}  

	void draw(float x, float y){
		glPrintString(a(), x,y);
	}


	friend std::ostream &operator<<(std::ostream &os, heapNodeType& n)
	{
		os<<n.key;
		return os;
	}

	heapNodeType operator+(const heapNodeType &_t){
		return heapNodeType(key+_t.key, _a+_t._a);
	}
	
	bool operator>(const heapNodeType &a){
		return key>a.key;
	}
	bool operator<(const heapNodeType &a){
		return key<a.key;
	}
};

template<class Node>  
class Heap{
public: 
	buildHeapStrategy strategy;
	Heap(Node *array, int _n, buildHeapStrategy _strategy){
		if(array&&_n){
			strategy = _strategy;
			m_h = array;
			m_n= _n;
			m_capacity = m_n;
			if(strategy==topDown)
				buildHeapTopDown();
			else
				buildHeapBottomUp();

			if(!isValidHeap())	
				std::cerr<<"build failed!\n";
		
		}
	}
	Heap(buildHeapStrategy _strategy){
		strategy = _strategy;
		m_n = 0;
		m_capacity = 0;
		m_h =NULL;
	}
	~Heap(){ if(m_h) delete[] m_h; }
	int m_capacity;
	void insert(Node a){
		m_n++;
		if(m_n>m_capacity){
			m_capacity=2*m_n;

			Node *newH = new Node[m_capacity];
			for (int i=0; i<m_n-1; i++)
				newH[i] = m_h[i];
			if(m_h) delete[] m_h;
			m_h = newH;	
		}
		m_h[m_n-1] = a;
		node_climb_at(m_n-1);
	}
	int size(){
		return m_n;
	}
	void draw(){
		float x = 333;
		float y = 900;		
		float dx = 150;
		float dy = 60;
		_draw(0, x, y, dx , dy);	
	}
	void _draw(int i, float x, float y, float dx, float dy){
		glRasterPos2f(x, y);
		m_h[i].draw(x, y+15);
		int lChild = i*2+1;
		int rChild = i*2+2;
		if(lChild<=m_n-1){	
			glBegin(GL_LINES);
			glVertex2f(x,y);
			glVertex2f(x-dx, y-dy);
			glEnd();
			_draw(lChild, x-dx,  y-dy, dx*0.8, dy*0.95);

		}
		if(rChild<=m_n-1){	
			glBegin(GL_LINES);
			glVertex2f(x,y);
			glVertex2f(x+dx, y-dy);
			glEnd();
			_draw(rChild, x+dx, y-dy, dx*0.8, dy*0.95);
		}
	}

protected:
	void buildHeapTopDown(){  //make inplace heap by insertion one-after one !  this is top-down manner, slow!
		timer.Reset();
		for(int i=0; i<m_n; i++){
			node_climb_at(i);
		}
		std::cerr<<"top-down building: "<<timer.GetTime()*1000<<"ms\n";
	}
	void node_climb_at(int i){

		int parent = int((i+1)/2)-1;
		int child = i;
		while(parent>=0){
			if( m_h[child]<m_h[parent] ){
				swap(m_h[child], m_h[parent]);
				child = parent;
				parent = int((parent+1)/2) - 1;
			}
			else
				break;
		}
	}
	void buildHeapBottomUp(){
		timer.Reset();
		
		int node = m_n/2-1;// the subheap top, skip all the leaves!

		while(node>=0){
			
			int i = node ; //now we iteratively adjust the heap lead by this node. So i will climb down the tree!
			 
			while (i <= m_n/2-1){
				int child_L = i*2+1;
				int child_R = i*2+2;

				int proxyChild;

				//get the bigger child!
				if(child_R>m_n-1){
					proxyChild = child_L;
				}
				else{
					if(m_h[child_L] < m_h[child_R])
						proxyChild = child_L;
					else
						proxyChild  = child_R;
				}
			
				if(m_h[i]>m_h[proxyChild]){
					swap(m_h[proxyChild], m_h[i]);
					i = proxyChild;
				}
				else 
					break;
			}
			node--;
		}
		std::cerr<<"bottom-Up building: "<<timer.GetTime()*1000<<"ms\n";
	}

	bool isValidHeap(){
		int i = 0;
		while(i<m_n/2){

			int child_L = i*2+1;
			int child_R = i*2+2;
			if(child_R>m_n-1){
				if( m_h[i]>m_h[child_L])
					return false;
			}
			else{
				if( m_h[i]>m_h[child_L] ||  m_h[i]>m_h[child_R]){
					return false;
				}
			}
			
			i++;
		}
		return true;
	}
	

protected:
	int m_n;	
	Node  *m_h;

public:
	Node pop(){
		if(m_n>0){
			Node top = m_h[0];
			m_h[0] = m_h[m_n-1];
			m_n--;
			int parent = 0;
			int child = parent*2+1;  
	
			while( child <=m_n-1 ){
				if(m_h[child]>m_h[child+1])
					child = child + 1; 
				if(m_h[child]<m_h[parent]){
					swap(m_h[child], m_h[parent]);
					parent = child;
					child = child*2+1; 
				}
				else
					break;
			}
			return top;
		}
		else{
			return Node();
		}
	}

	Node top(){ return m_h[0]; }

	void print(){
		std::cerr<<"the heap:";
		for (int i=0; i<m_n; i++)	std::cerr<<m_h[i]<<",";
		std::cerr<<"\n";
	}
};
