// maxConsecuSubSeq.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <vector>
using namespace std;
template<typename T>
T maxConsecuetiveSubsequence(const vector<T>& a, int& bgn, int& end){
	T g_max = 0;
	T suffix_max = 0;
	
	bgn = 0, end;
	
	int bgn_maxSuffix = 0;
	int end_maxSuffix ;

	for (unsigned i=0; i<a.size(); i++)
	{
		if(a[i]+suffix_max>g_max){
			suffix_max = a[i]+suffix_max;
			g_max = suffix_max;
			bgn = bgn_maxSuffix;
			end = i;
		}
		else{
			if(a[i]+suffix_max>0){
				suffix_max = a[i]+suffix_max;
				end_maxSuffix = i;
			}
			else{
				suffix_max = 0;
				bgn_maxSuffix  = i+1;
				end_maxSuffix  = bgn_maxSuffix;
			}
		}
	}

	return g_max;
}

int _tmain(int argc, _TCHAR* argv[])
{
	vector<float> a;
	a.push_back(2);
	a.push_back(-3);
	a.push_back(1.5);
	a.push_back(-1.9);
	a.push_back(-3);
	a.push_back(-2);
	a.push_back(-.5);
	a.push_back(3);
	a.push_back(1);
	a.push_back(2);
	a.push_back(-4);
	a.push_back(-1);
	a.push_back(11);
	a.push_back(5);
	a.push_back(0.5);

// 	a.push_back(2);
// 	a.push_back(-3);
// 	a.push_back(1.5);
// 	a.push_back(-1);
// 	a.push_back(3);
// 	a.push_back(-2);
// 	a.push_back(-3);
// 	a.push_back(3);
	
	int bgn , end;
	std::cerr<<"�������������֮��:"<<maxConsecuetiveSubsequence(a, bgn, end);
	std::cerr<<", from "<<bgn<<" to "<<end<<".\n";

	return 0;
}

