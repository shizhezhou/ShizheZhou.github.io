*****IMPORTANT: keep the "exe" and "data"'s folder structure, otherwise Unishop.exe may not start. *****

USAGE:
1. open Unishop.exe, a dialog named as "Polygon and Region" is displayed.
2. click "load" on the top to load an exemplar, which is a *.sply file.  In the "data" folder, we share 10 exemplars along with their thumbnail images.
3. click "Init synthesis".
4. drag the right/left handles(2 green box) to resize the exemplar.
5. click "load" on the top to load another exemplar to redo step 3~4.

OTHER FUNCTIONS :
1. click "auxdata" to show technical information overlay.
2. tune "#part*" slider to control the number of connected components. Check on its "Auto" to let synthesizer automatically find the optimal number.
3. tune "#hole*" slider to control the number of holes. Check on its "Auto" to let synthesizer automatically find the optimal number.
4. mouse wheel to zoom in/out.

*****Copyright*****
Unishop.exe depends on open source libraries including CGAL, BOOST, ANN, FreeImage. We are very grateful to be able to use their code in developing Unishop. 
This code and data is provided as is without warranties of any kind, for educational and research purposes only. Please contact us for any other use. The authors retain the exclusive copyright on all files.
@All rights reserved.
Shizhe Zhou
Sylvain Lefebvre