#ifndef SKETCHER_H
#define SKETCHER_H

#include <iostream>
#include <algorithm>
#include <numeric>
#include "shared\arthurwidgets.h"
#include "stopwatch.hpp"
#include <QtGui>
#include <QEvent>
#include <Qtimer>
#include <QPixmap>
#include <Qgraphicsview>

#include <phonon/phononnamespace.h>
#include <phonon/audiooutput.h>
#include <phonon/mediaobject.h>

#include "CameraMotionDlg.h"

inline qreal squareMagnitude(QPointF a);

enum TimeEventType{RT_DrawLine,RT_TransferPen, RT_CameraMotion};

QString s2q(const std::string &s);
std::string q2s(const QString &s);
void NormalizeVct( QVector<float> &V);
void NormalizeQPointF(QPointF &p);
#define CLIP(x,a,b) __min(__max((x),a),b)

extern float IDX_TAG_OFFSET;
extern float lnIdxTextHlfSize ;
extern float SkeqDirArrowSz ;
extern float ArrowAngle ;

void drawArrow( const QPointF& head, const QPointF& tail, double axLen, QPainter *painter);
class LINE{
public:
	LINE(){		m_skqingSegId = 0;	m_bSkqing = false;	m_bUseTex = false; }
	float		m_fLineWidth;
	bool		m_bClosed, m_bFilled;
	int			m_nHoles;
	QColor		m_LineColor, m_FillColor;
	QPointF		m_midP;
	QPointF		m_lnIdxPos;	
	QPointF		m_midSegDir;
	int			m_linePattern;
	float		m_TotalLength;
	QPointF		m_headDir, m_tailDir; 
	bool m_bOuterBorder;
	std::vector<LINE*> m_holes;
	void read(FILE *fp)
	{
		int nv, closed, nholes(0), filled, r, g, b, a, patternType;
		float linewidth;
		fscanf_s(fp, "%d %d,%d\n", &nv, &closed, &nholes);
		fscanf_s(fp, "%d (%d,%d,%d),%d\n", &filled, &r, &g, &b, &a);	

		m_bClosed = closed;
		m_bFilled = filled;
		m_nHoles = nholes;
		
		a = CLIP(a, 0, 255);
		m_FillColor = QColor(r,g,b,a);

		fscanf_s( fp, "%f %d (%d,%d,%d)\n", &linewidth, &patternType, &r, &g, &b );
		m_fLineWidth = linewidth;
		m_LineColor = QColor(r,g,b);

		m_linePattern = patternType;
		if(patternType==5)	m_bUseTex = true;
		else				m_bUseTex = false;

		m_pts.resize(nv);		
		for( int j=0; j<nv; j++ )
		{
			double x, y;
			fscanf_s(fp, "%lf %lf\n", &x, &y );
			(*this)[j] = QPointF( x, y );
		}	
		m_bOuterBorder = true;
		for( int j=0; j<nholes; j++ ){
			LINE *h = new LINE;
			h->read(fp);
			h->m_bOuterBorder = false;
			m_holes.push_back(h);
		}
		initDrawStaticInfo();		
	}
	
	void LINE::debug(){
		std::cerr<<"m_pts.size() "<<m_pts.size()<<"\n";
		std::cerr<<"m_bClosed "<<m_bClosed<<"\n";
		std::cerr<<"m_nHoles "<<m_nHoles<<"\n";
		std::cerr<<"m_bFilled "<<m_bFilled<<"\n";
		std::cerr<<"m_FillColor "<<m_FillColor.red()<<","<<m_FillColor.green()<<","<<m_FillColor.blue()<<","<<m_FillColor.alpha()<<"\n";
	}

	void reverse(){
		std::reverse(m_pts.begin(), m_pts.end());
		std::reverse(m_drawPts.begin(), m_drawPts.end());
		allSegLenAndVct();		
		allSegCurvature();	
		allSegDrawSpeed();
		std::swap(m_headDir, m_tailDir);
	}

	QPointF	fitHeadDir(){
		const float RNG = 0.25 * m_TotalLength;	
		float sqrRNG = RNG*RNG;

		//head 
		int inv = 1;
		while( squareMagnitude(m_pts[inv]-m_pts[0]) < sqrRNG )	{
			if( inv>=nP()-1 )	break;
			inv++;
		}
		std::vector<float> wt(inv, 0.0f);
		for (int i=0; i<inv; ++i){
			for (int j=0; j<=i;  ++j)	wt[i] += m_segLen[j];
			wt[i] = 1.0f/wt[i];
		}	
		QPointF headDir(.0f, .0f);
		for (int i=0; i<inv; ++i)	headDir+= m_segDir[i] * wt[i]; 
		NormalizeQPointF(headDir);	headDir*=-1.0f;	
		return headDir;
	};

	void fitHeadTailDir(){
		QPointF headDir = fitHeadDir();			reverse();
		QPointF tailDir = fitHeadDir();			reverse();
		m_headDir = headDir;		m_tailDir = tailDir;
	}
	void DrawHeadTailDir(QPainter *painter){
		QPen pen;
		pen.setWidth(2.5);
		pen.setColor(Qt::darkYellow);
		pen.setJoinStyle(Qt::MiterJoin);
		pen.setCapStyle(Qt::SquareCap);
		painter->setPen(pen);
		
		painter->drawLine(m_drawPts[0],			m_drawPts[0]+m_headDir * 50.0f);				
		painter->drawLine(m_drawPts[nP()-1],	m_drawPts[nP()-1]+m_tailDir* 50.0f);		
		
		drawArrow( m_drawPts[0]+m_headDir,		m_drawPts[0],		SkeqDirArrowSz, painter);
		drawArrow( m_drawPts[nP()-1]+m_tailDir,	m_drawPts[nP()-1],	SkeqDirArrowSz, painter);
	}
	
	QPointF		LineMidPoint(){
		int idx_lastEP = nP()-1;
		if(nP()<=2){
			m_midP = 0.5*(m_pts[0]+m_pts[idx_lastEP]);
			m_midSegDir = m_pts[idx_lastEP] - m_pts[0];
		}
		else{
			if(idx_lastEP%2==0){ //odd number, then the idx of the middle point is idx_lstEP/2;
				int idx_midP = idx_lastEP/2;
				m_midP = m_pts[idx_midP];				
				
				m_midSegDir = m_segDir[idx_midP - 1] + m_segDir[idx_midP];
			
			}
			else{ //even number, then we have two middle points..
				int idx_midP_1 = idx_lastEP/2;
				int idx_midP_2 = idx_midP_1+1;
				m_midP = 0.5*( m_pts[idx_midP_1] + m_pts[idx_midP_2] );

				m_midSegDir = m_segDir[idx_midP_1];
			}
		}
		NormalizeQPointF(m_midSegDir);
		QPointF invDir = QPointF( m_midSegDir.y(), -m_midSegDir.x() );
		m_lnIdxPos = m_midP + IDX_TAG_OFFSET*invDir;
		return m_midP;
	}

	void updateLnIdxPos(){	
		QPointF invDir = QPointF( m_midSegDir.y(), -m_midSegDir.x() );	
		m_lnIdxPos = m_midP + IDX_TAG_OFFSET*invDir;	
	}
	
	void DrawMidArrow(QPainter *painter){
		QPen pen;
		
		pen.setWidth(2.5);
		pen.setJoinStyle(Qt::MiterJoin);
		pen.setCapStyle(Qt::SquareCap);
		painter->setPen(pen);

		drawArrow( Real2Draw(m_midP), Real2Draw(m_midP)-m_midSegDir, SkeqDirArrowSz, painter);
	}
	

	int nP()					{	return m_pts.size();	}
	QPointF& operator[](int i)	{	return m_pts[i];		}
	QVector<QPointF>& getP()	{	return m_pts;			}	
	QVector<QPointF>& getDrawP(){	return m_drawPts;		}	
	void updateDrawPts()		{	
		for (int i=0; i<nP(); ++i)  m_drawPts[i] = Real2Draw(m_pts[i]); 		
	}
	void initDrawStaticInfo();
	void allSegLenAndVct();
	inline void updateFullPainterPath(QPainterPath &paintPath);
	inline void updateFullTexturedPainterPath();

	static Stopwatch	m_skqTimer;
	int m_skqingSegId;
	bool m_bSkqing;

	bool m_bUseTex;
	QVector<QPainterPath>	m_SegOutLinePath;
	QVector<QTransform>		m_SegBrushTrfm;		
	inline void initAllSegOutLinePathAndTrfm();
	static	float m_fFadingLenRatio,m_fTexLineWidth;
	
	std::vector<QImage>	m_SegBrushTexImg;
	
	void initSegBrushTex(QImage &img){
		if(!m_bUseTex) return;
		int nS = m_bClosed? nP() : nP() - 1 ;
		m_SegBrushTexImg.clear();		m_SegBrushTexImg.resize(nS);
		for (int i=0; i<nS; ++i)
			m_SegBrushTexImg[i] = QImage(img.width(), img.height(), QImage::Format_ARGB32);
	}

	void synthSegBrushTex(QImage &img){
		if(!m_bUseTex) return;
		float acLen(.0f);
		int nS = m_bClosed? nP() : nP() - 1 ;
		for (int i=0; i<nS; ++i)
		{
			/*make alpha*/
			for (int x=0; x<img.width(); ++x)
			{
				float exactLen = x/(float)img.width() * m_segLen[i] + acLen;
				float LenRt = exactLen/m_TotalLength ;
				LenRt = LenRt<=0.5 ? LenRt : 1.0-LenRt;
				LenRt = LenRt<=m_fFadingLenRatio ? LenRt : m_fFadingLenRatio;
				float alphaRt =  LenRt/m_fFadingLenRatio;
			
				for (int y=0; y<img.height(); ++y)	{
					QRgb c = img.pixel(x,y);
					m_SegBrushTexImg[i].setPixel(x,y,	
						QColor(	qRed(c),qGreen(c),qBlue(c),	alphaRt*255).rgba() );
				}
			}
			acLen += m_segLen[i];
		}
	}	

	void DrawTexturePath_Texture(QPainter *painter);

	std::vector< float >	m_vAlpha;
	void getValpha(){
		if(!m_bUseTex) return;
		m_vAlpha.clear();	m_vAlpha.resize(nP(), 1.0f);
		float fadingLen = m_TotalLength * m_fFadingLenRatio;

		float L(.0f);	int i(0);
		while(L<fadingLen){
			m_vAlpha[i] = L/fadingLen;
			L += m_segLen[i];		
			i++;
		}

		i = nP()-1;
		if(m_bClosed)
			L = m_segLen.back();
		else
			L = 0.0f;
		while(L<fadingLen){
			m_vAlpha[i] = L/fadingLen;
			L += m_segLen[i-1];		
			i--;
		}

		for (int i=0; i<nP(); ++i)	m_vAlpha[i]  = m_vAlpha[i] * 255;	
	}

	void DrawTexturePath_Gradient(QPainter *painter){
		if(m_bSkqing){			
			for (int i=0; i<m_skqingSegId+1;  ++i){	
				QLinearGradient linearGrad(m_drawPts[i], m_drawPts[i+1]);
				linearGrad.setColorAt(0,	QColor(0,0,0,m_vAlpha[i]));
				linearGrad.setColorAt(1,	QColor(0,0,0, m_vAlpha[i+1]));
				QBrush LGAlpha(linearGrad);	
				painter->fillPath(m_SegOutLinePath[i], LGAlpha); 									
			}
		}
		else{

			int nS = m_bClosed? nP() : nP() - 1 ;

			for (int i=0; i<nS; ++i){		
				QLinearGradient linearGrad(m_drawPts[i%nP()], m_drawPts[(i+1)%nP()]);
				linearGrad.setColorAt(0,	QColor(0,0,0,m_vAlpha[i%nP()]));
				linearGrad.setColorAt(1,	QColor(0,0,0, m_vAlpha[(i+1)%nP()]));
				QBrush LGAlpha(linearGrad);	
				painter->fillPath(m_SegOutLinePath[i], LGAlpha ); 									
			}
		}
	}

	bool ProduceAnimatingLinePath( QPainterPath &paintPath, QPointF &PencilPos)
	{
		float dist2Skq = m_drawSpeed[m_skqingSegId] * m_spdRadtio * m_skqTimer.GetTime();
		if( dist2Skq <= m_segLen[m_skqingSegId] )
		{
			paintPath.moveTo(m_drawPts[0]);
			if(m_skqingSegId>=1){				
				for (int i=1; i<m_skqingSegId+1; ++i)	paintPath.lineTo( m_drawPts[i] );				
			}
			PencilPos = m_drawPts[m_skqingSegId] + m_segDir[m_skqingSegId]*dist2Skq*m_zoom;						
			paintPath.moveTo( m_drawPts[m_skqingSegId] );
			paintPath.lineTo( PencilPos );
			
			return false; //unfinished yet, still drawing this segments.
		}    
		else{
			++m_skqingSegId;
			if(m_skqingSegId >= nP()-1)	{//the line skqing finished, start transferring.
				m_skqTimer.Reset();			
				updateFullPainterPath(paintPath);
				m_bSkqing = false;
				return true;  
			}
			else{//unfinished yet, turning at the corner vertex.
				m_skqTimer.Reset();
				paintPath.moveTo(m_drawPts[0]);
				for (int i=1; i<m_skqingSegId+1; ++i)	paintPath.lineTo( m_drawPts[i] );
				return false;  
			}
		}		
	}
	inline bool ProduceAnimatingTexturedLinePath(QPointF &PencilPos);

	float				m_trsfLen;	//dist for the pen to move after skq a line. end[this line]->head[next line].	
	QPointF				m_trsfDir;
	float				m_trsfSpeed;  //the longer to transfer, the faster.
	bool transferPencil(QPointF &PencilPos){
		float dist2trsf = m_trsfSpeed * m_spdRadtio * m_skqTimer.GetTime();
		if(dist2trsf > m_trsfLen ){			
			return true;
		}
		else{
			PencilPos = m_drawPts[nP()-1] + m_trsfDir * dist2trsf * m_zoom;
			return false;
		}
	}
	bool	Left(QPointF a, QPointF b, QPointF c);
	double	Curvature(int i);
	void	allSegCurvature();
	void	allSegDrawSpeed(int R = 4, bool bSeeDbg = true);
	
	void	OrientByHanded(bool bRight = true/*if it is false, by left handed*/){
		const float R = 0.3f;   /*Smaller R gives more Topdown strokes.*/
		QPointF End_Str = m_pts[nP()-1] - m_pts[0];

		if( fabs(End_Str.y()) > fabs(End_Str.x())*R ) {	//apply Topdown rule
			if(m_pts[0].y() > m_pts[nP()-1].y())
				reverse();
		}
		else{
			if(bRight){
				if(m_pts[0].x() > m_pts[nP()-1].x())	reverse();
			}
			else{
				if(m_pts[0].x() < m_pts[nP()-1].x())	reverse();
			}
		}
	}

	static QPointF Real2Draw(QPointF p){	return p*m_zoom + m_origin;	}
	static QPointF Draw2Real(QPointF p){	return (p - m_origin)/m_zoom;	}
	static QPointF m_origin;
	static float m_zoom;
	static float m_smthSpeed, m_curvySpeed, m_spdRadtio;

private:
	QVector<QPointF>	m_pts;	
	QVector<QPointF>	m_drawPts;
	QVector<float>		m_segLen;
	QVector<QPointF>	m_segDir;	
	QVector<float>		m_curvature;
	QVector<float>		m_drawSpeed;
	QVector<float>		m_segAngel;
};

class SketcherControls;

class SketcherRenderer : public ArthurFrame
{
    Q_OBJECT
	Q_PROPERTY(bool animation READ animation WRITE startAnimation)
public:
	bool	m_bAnimating;
	int		m_skqingLnId;
	static Stopwatch	m_cameraTimer;
	QVector<CamMotionScript>	m_Scripts;
	QVector<CamMotionScript>::iterator m_iterScript;
	
	TimeEventType m_TE;

	SketcherControls* m_controller;
	
	int m_nShownLn;
	static	QImage			m_brushTexImg, m_brushAlphaImg;	
	QPainterPathStroker myPathStroker;
	bool m_bControlTexedLnWidth;
	static	bool	m_bFadingTex; //ture:fade with texture; false: fade with gradient.
	CameraMotionDlg *m_ConfigScriptDlg;
	
	//QGraphicsItem qGItem;
	void initTextureBrush();
	SketcherRenderer(QWidget *parent, bool smallScreen = false);

    void paint(QPainter *);
	void timerEvent(QTimerEvent *e);
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent *e);
	void mouseDoubleClickEvent(QMouseEvent *e);
    void wheelEvent(QWheelEvent *event);
	
    QSize sizeHint() const { return QSize(500, 500); }

    bool animation() const { return m_timer.isActive(); }

signals:
    void clicked();

public slots:
	void popScriptDlg();

	void setNumShownLn(int sz);
	void setArrowSz(int sz)		{	SkeqDirArrowSz = sz/ 3.0f;		update(); }
	void setLnIdxSz(int sz)		{	lnIdxTextHlfSize = sz/ 3.0f;	update();}
	void setLnIdxOffset(int sz){
		IDX_TAG_OFFSET = sz/ 3.0f; 
		for (int i=0; i<m_nL; ++i)		m_Lines[i].updateLnIdxPos();
		update();
	}	
	void setPencilSize(int sz){
		m_pencilImg = m_pencilImg_Save.scaledToWidth(sz,Qt::SmoothTransformation);
		update();
	}

    void setPenWidth(int penWidth) { 
		m_penWidth = penWidth / 2.0;  
		if(m_bControlTexedLnWidth){
			LINE::m_fTexLineWidth = m_penWidth;
			for (int i=0; i<m_nL; ++i){
				if(m_Lines[i].m_bUseTex)	m_Lines[i].updateFullTexturedPainterPath();				
			}
		}
		else{
			for (int i=0; i<m_nL; ++i){
				if(!m_Lines[i].m_bUseTex)	m_Lines[i].m_fLineWidth = m_penWidth;
			}
		}
		update();
	}

	void setTRaceLineCurvy(int curvy) { 
		m_trLnGapRate = curvy / 100.0;  
		MakeTraceLine();
		update();
	}
	
	void setPenSpeed(int penSpeed) { LINE::m_spdRadtio = float(penSpeed) / 50.0f; /*update();*/ }
	
	void startAnimation(bool A);
	void pauseAnimation();
	
	void setShowPen(bool bShowPen) { m_bShowPen = bShowPen; 						update(); }
	void setShowTag(bool bShowTag) { m_bShowTag = bShowTag; 						update(); }
	void setShowEndDir(bool bShowEndDir) { m_bShowEndDir = bShowEndDir;				update(); }
	void setDefaultLineRenderProperty(bool bDefault);
    void setFlatCap() { m_capStyle = Qt::FlatCap;		updateContentForCamera();	update(); }
    void setSquareCap() { m_capStyle = Qt::SquareCap;	updateContentForCamera();	update(); }
    void setRoundCap() { m_capStyle = Qt::RoundCap;		updateContentForCamera();	update(); }
    void setSolidLine() { m_penStyle = Qt::SolidLine;								update(); }
    void setDashLine() { m_penStyle = Qt::DashLine;									update(); }
    void setDotLine() { m_penStyle = Qt::DotLine;									update(); }
    void setDashDotLine() { m_penStyle = Qt::DashDotLine;							update(); }
    void setDashDotDotLine() { m_penStyle = Qt::DashDotDotLine; 					update(); }
	void setDrawTraceLine(bool bDrawTrLn) { m_bDrawTraceLn = bDrawTrLn;				update(); }
	void setControlTexturedLineWidth(bool bControlTexedLnWidth) { m_bControlTexedLnWidth = bControlTexedLnWidth; }
	void RemakeFadingTexture();
	void RemakeFadingGradient();

	void openLineFile();
	void pickLineColor();
	void openBackPaperImg();
	void loadBrushTex();
	void loadBrushTexAlpha();
	void moveCamUp();
	void moveCamDown();
	void moveCamRight();
	void moveCamLeft();
	void zoomCamOut();
	void zoomCamIn();
	void updateContentForCamera();
	void orientStroke();
	void FadingType();
public:
	void AnimateCamera();
    void updateContentForAnim();
	void transferPencil();
	void updateAllLnDrawingPts();

	QBasicTimer m_timer;
	
    qreal	m_penWidth;
    int		m_pointCount;
	QImage	m_pencilImg_Save, m_pencilImg;	
	QPointF m_pencilPos;
	QPointF	m_pencilOffset;
	bool	m_bRightHanded;
	bool	m_bShowPen;
	bool	m_bDrawTraceLn;
	QColor	m_color;

	int m_nL, m_AllnV;	
	QVector<LINE> m_Lines;
	QVector<QPainterPath> m_AllPaths;

	QVector<QPainterPath> m_traceLines;
	float m_trLnGapRate;
	QVector<float>	m_trLnThick;

	void MakeTraceLine(){
		int nTrL = m_nL - 1;
		m_traceLines.clear();
		m_traceLines.resize(nTrL);		
		QPointF startP, ctrlP1, ctrlP2, endP;
		float gap, startLen, endLen;
		
		//1.Link between 2 line
		for (int i=0; i<nTrL; ++i)	{

			int nv = m_Lines[i].nP();

			startP = m_Lines[i].getDrawP()[nv-1];
			endP = m_Lines[i+1].getDrawP()[0];

			gap = sqrt( squareMagnitude(startP-endP) ) * m_trLnGapRate;

			startLen = m_Lines[i].m_TotalLength/(m_Lines[i].m_TotalLength+m_Lines[i+1].m_TotalLength)  * gap;
			endLen =   m_Lines[i+1].m_TotalLength/(m_Lines[i].m_TotalLength+m_Lines[i+1].m_TotalLength)* gap;

			ctrlP1 = startP + m_Lines[i].m_tailDir * startLen;
			ctrlP2 = endP   + m_Lines[i+1].m_headDir * endLen;

			m_traceLines[i].moveTo(startP );			
			m_traceLines[i].cubicTo(ctrlP1, ctrlP2, endP);			
		}		
		
		//2.Link against 1 line-self
		float mm;
		for (int i=0; i<m_nL; ++i)
		{
			int nv = m_Lines[i].nP();

			startP = m_Lines[i].getDrawP()[0];
			endP   = m_Lines[i].getDrawP()[nv-1];


			gap = sqrt( squareMagnitude(m_Lines[i].getP()[0] - m_Lines[i].getP()[nv-1]) ) ;

			mm = (2.1 - gap/m_Lines[i].m_TotalLength) *m_trLnGapRate*0.5*m_Lines[i].m_TotalLength * LINE::m_zoom;			

			ctrlP1 = startP - m_Lines[i].m_headDir * mm;
			ctrlP2 = endP   - m_Lines[i].m_tailDir * mm;
			
			QPainterPath LApath;
			LApath.moveTo(startP );			
			LApath.cubicTo(ctrlP1, ctrlP2, endP);			
			
			m_traceLines.push_back(LApath);
			
		}
	}

	void DrawTraceLine(QPainter *painter,  QPainterPathStroker  &Stroker, QImage &pix){
		QBrush brush;
		for (int i=0; i<m_traceLines.size(); ++i){

			QPainterPath outLinePath; 
			outLinePath = Stroker.createStroke(m_traceLines[i]);
			brush.setTextureImage(pix);
			painter->fillPath(outLinePath, brush); 									
		}	
	}
	
	bool	m_bDefaultLook; //true: all line with same width and same color; false: stylized rendering
	bool	m_bShowTag;
	bool	m_bShowEndDir;

	static Qt::PenJoinStyle m_joinStyle;
    static Qt::PenCapStyle	m_capStyle;
    static Qt::PenStyle		m_penStyle;

	QPoint m_mousePos;
	QPoint m_mouseRbtnDownPos;

	QString	currentPath;
	bool m_bDrawV;
	float m_fZoomSv;
		
	void initTransferInfo(){
		QVector<float> len(m_nL-1);
		for (int i=0; i<m_nL-1; ++i)	{
			int nv = m_Lines[i].nP();
			m_Lines[i].m_trsfDir = m_Lines[i+1][0] - m_Lines[i][nv-1];
			
			m_Lines[i].m_trsfLen = sqrt( squareMagnitude(m_Lines[i].m_trsfDir) );
			len[i] = m_Lines[i].m_trsfLen;
			m_Lines[i].m_trsfDir  /= m_Lines[i].m_trsfLen;
		}
		m_Lines[m_nL-1].m_trsfDir = QPointF(.0f, .0f);
		m_Lines[m_nL-1].m_trsfLen = 0.0f;

		NormalizeVct(len);
		for (int i=0; i<m_nL-1; ++i)
		{
			m_Lines[i].m_trsfSpeed = 150 * (1.0+len[i]);
		}		
	}	

private:
	static Phonon::MediaObject *m_MediaObject;
	static Phonon::AudioOutput *m_AudioOutput;
	static Phonon::Path m_audioOutputPath;
	void initSound(){
		m_AudioOutput =	new Phonon::AudioOutput(Phonon::NotificationCategory, this);
		m_MediaObject = new Phonon::MediaObject(this);
		Phonon::createPath(m_MediaObject, m_AudioOutput);
		m_MediaObject->setCurrentSource(Phonon::MediaSource(".\\media\\skqsound.mp3") );	
		//m_AudioOutput->setVolume(0.99);	
	}

	static void playSound(){	m_MediaObject->play();	}
	static void pauseSound(){	m_MediaObject->pause();	}
	static void stopSound(){	m_MediaObject->stop();	}
	static void restartSound(){	m_MediaObject->stop();m_MediaObject->play();	}	
};

class SketcherControls : public QWidget
{
    Q_OBJECT
public:
    SketcherControls(QWidget* parent, SketcherRenderer* renderer, bool smallScreen);
	QPushButton		*m_pauseAnimBtn; 
	QSlider			*m_NumShownLnSld;
	QGroupBox		*m_ShownLnGrp; 
	QCheckBox		*m_CHKdrawTrLn;
	QRadioButton	*m_LeftHandedCHK,		*m_RightHandedCHK;
	QRadioButton	*m_fadingTextureCHK,	*m_fadingGradientCHK;
	QSlider			*m_fadingRatioSld;
	QPushButton		*m_ChkdefaultDraw;
	
signals:
    void okPressed();
    void quitPressed();

private:
	QTabWidget *m_TabWidget;
    SketcherRenderer* m_renderer;
	
    QGroupBox *m_capGroup;
    QGroupBox *m_styleGroup;
	
    void createCommonControls(QWidget* parent);
    void layoutForDesktop();
    void keyPressEvent( QKeyEvent *event );	
private slots:
    void emitQuitSignal();
    void emitOkSignal();	
	void swapDefaultDrawBtnText(bool b);
};

class SketcherWidget : public QWidget
{
    Q_OBJECT
public:
    SketcherWidget(bool smallScreen);
    void setStyle ( QStyle * style );
	
private:
    SketcherRenderer *m_renderer;
    SketcherControls *m_controls;

private slots:
    void showControls();
    void hideControls();
};

#endif // SKETCHER_H
