#include "sketcher.h"
#include "shared\arthurstyle.h"
#include "shared\arthurwidgets.h"

#pragma	warning(disable : 4100)

float IDX_TAG_OFFSET;
float lnIdxTextHlfSize ;
float SkeqDirArrowSz ;
float ArrowAngle ;

const float ML_LOW_TOLERANCE	=	0.000001f;

QString s2q(const std::string &s)	{  	return QString(QString::fromLocal8Bit(s.c_str()));  }  
std::string q2s(const QString &s)	{  	return std::string((const char *)s.toLocal8Bit());  }
qreal squareMagnitude(QPointF a)	{	return a.x()*a.x() + a.y()*a.y();					}
void NormalizeQPointF(QPointF &p)	{	qreal l = squareMagnitude(p); if(l) p/= sqrt(l);	}

void NormalizeVct( QVector<float> &V)
{
	int sz = V.size();
	float maxE = *std::max_element(V.begin(), V.end());
	float minE = *std::min_element(V.begin(), V.end());
	float rng = maxE - minE;
	if( rng > ML_LOW_TOLERANCE )
		for (int i=0; i<sz; ++i)	V[i] = (V[i] - minE) / rng;
}

float		LINE::m_zoom = 1.0f;
QPointF 	LINE::m_origin= QPointF(0.0f, 0.0f);
float		LINE::m_curvySpeed = 36.0f;
float		LINE::m_smthSpeed = 300.0f;
float		LINE::m_spdRadtio = 1.0f;
float 		LINE::m_fFadingLenRatio = 0.3f;
float 		LINE::m_fTexLineWidth= 1.5f;
Stopwatch	LINE::m_skqTimer;
Stopwatch SketcherRenderer::m_cameraTimer;
Qt::PenJoinStyle	SketcherRenderer::m_joinStyle = Qt::BevelJoin;
Qt::PenCapStyle		SketcherRenderer::m_capStyle	= Qt::RoundCap;
Qt::PenStyle		SketcherRenderer::m_penStyle	= Qt::SolidLine;
QImage				SketcherRenderer::m_brushTexImg;
QImage				SketcherRenderer::m_brushAlphaImg;
bool				SketcherRenderer::m_bFadingTex = true;

Phonon::MediaObject *SketcherRenderer::m_MediaObject = NULL;
Phonon::AudioOutput *SketcherRenderer::m_AudioOutput = NULL;

extern void draw_round_rect(QPainter *p, const QRect &bounds, int radius);

SketcherControls::SketcherControls(QWidget* parent, SketcherRenderer* renderer, bool smallScreen)
      : QWidget(parent)
{
    m_renderer = renderer;
	layoutForDesktop();
}

void SketcherControls::createCommonControls(QWidget* parent)
{
    m_capGroup = new QGroupBox(parent);
    m_capGroup->setAttribute(Qt::WA_ContentsPropagated);
    m_capGroup->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
    QRadioButton *flatCap = new QRadioButton(m_capGroup);
    QRadioButton *squareCap = new QRadioButton(m_capGroup);
    QRadioButton *roundCap = new QRadioButton(m_capGroup);
    m_capGroup->setTitle("Cap Style");
	flatCap->setText("|"); squareCap->setText("]"); roundCap->setText(")");
    flatCap->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    squareCap->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    roundCap->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
   
    m_styleGroup = new QGroupBox(parent);
    m_styleGroup->setAttribute(Qt::WA_ContentsPropagated);
    m_styleGroup->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
    QRadioButton *solidLine = new QRadioButton(m_styleGroup);
    QRadioButton *dashLine = new QRadioButton(m_styleGroup);
    QRadioButton *dotLine = new QRadioButton(m_styleGroup);
    QRadioButton *dashDotLine = new QRadioButton(m_styleGroup);
    QRadioButton *dashDotDotLine = new QRadioButton(m_styleGroup);
    m_styleGroup->setTitle("Pen Style");

    QPixmap line_solid(":res/images/line_solid.png");
    solidLine->setIcon(line_solid);
    solidLine->setIconSize(line_solid.size());
    QPixmap line_dashed(":res/images/line_dashed.png");
    dashLine->setIcon(line_dashed);
    dashLine->setIconSize(line_dashed.size());
    QPixmap line_dotted(":res/images/line_dotted.png");
    dotLine->setIcon(line_dotted);
    dotLine->setIconSize(line_dotted.size());
    QPixmap line_dash_dot(":res/images/line_dash_dot.png");
    dashDotLine->setIcon(line_dash_dot);
    dashDotLine->setIconSize(line_dash_dot.size());
    QPixmap line_dash_dot_dot(":res/images/line_dash_dot_dot.png");
    dashDotDotLine->setIcon(line_dash_dot_dot);
    dashDotDotLine->setIconSize(line_dash_dot_dot.size());

    int fixedHeight = 18;//bevelJoin->sizeHint().height();
	solidLine->setFixedHeight(fixedHeight);
    dashLine->setFixedHeight(fixedHeight);
    dotLine->setFixedHeight(fixedHeight);
    dashDotLine->setFixedHeight(fixedHeight);
    dashDotDotLine->setFixedHeight(fixedHeight);

    // Layouts
    QGridLayout *capGroupLayout = new QGridLayout(m_capGroup);
    capGroupLayout->addWidget(flatCap,0,0);
    capGroupLayout->addWidget(squareCap,0,1);
    capGroupLayout->addWidget(roundCap,0,2);

    QGridLayout *styleGroupLayout = new QGridLayout(m_styleGroup);
    styleGroupLayout->addWidget(solidLine,0,0);
    styleGroupLayout->addWidget(dashLine,0,1);
    styleGroupLayout->addWidget(dotLine,0,2);
    styleGroupLayout->addWidget(dashDotLine,0,3);
    styleGroupLayout->addWidget(dashDotDotLine,0,4);

    // Connections
    connect(flatCap, SIGNAL(clicked()), m_renderer, SLOT(setFlatCap()));
    connect(squareCap, SIGNAL(clicked()), m_renderer, SLOT(setSquareCap()));
    connect(roundCap, SIGNAL(clicked()), m_renderer, SLOT(setRoundCap()));

    connect(solidLine, SIGNAL(clicked()), m_renderer, SLOT(setSolidLine()));
    connect(dashLine, SIGNAL(clicked()), m_renderer, SLOT(setDashLine()));
    connect(dotLine, SIGNAL(clicked()), m_renderer, SLOT(setDotLine()));
    connect(dashDotLine, SIGNAL(clicked()), m_renderer, SLOT(setDashDotLine()));
    connect(dashDotDotLine, SIGNAL(clicked()), m_renderer, SLOT(setDashDotDotLine()));

    // Set the defaults:
    roundCap->setChecked(true);
    solidLine->setChecked(true);
}

void SketcherControls::layoutForDesktop()
{
	setFixedWidth(180);
	QVBoxLayout * TabLayout = new QVBoxLayout(this);
	m_TabWidget = new QTabWidget;
	m_TabWidget->setFixedWidth(180);
	m_TabWidget->setTabPosition(QTabWidget::South);
	m_TabWidget->setTabShape(QTabWidget::Triangular);
	TabLayout->addWidget(m_TabWidget);
	TabLayout->setMargin(0);

	QGroupBox *AnimateGroup = new QGroupBox("Animation", this);
	AnimateGroup->setFixedWidth(180);		
	QGroupBox *illustrGroup = new QGroupBox("Illustration", this);
	illustrGroup->setFixedWidth(180);	

	m_TabWidget->addTab(AnimateGroup,"Animation");
	m_TabWidget->addTab(illustrGroup,"Illustration");	

	//tab 1
	QVBoxLayout *AnimateGrpLyt = new QVBoxLayout(AnimateGroup); // mainGroupLayout->setMargin(3);
	
	QPushButton *loadLinesButton = new QPushButton("Open",AnimateGroup);
	loadLinesButton->setShortcut(QKeySequence(tr("o")));
		
	QPushButton *startAnim = new QPushButton(AnimateGroup);
	QPixmap pixStart = QPixmap( tr(".\\media\\start.bmp") );
	pixStart.setAlphaChannel( tr(".\\media\\start_mask.bmp")  );
	QIcon sticon(pixStart);
	startAnim->setIcon(sticon);
	startAnim->setIconSize(pixStart.size());
	startAnim->setCheckable(false);

	m_pauseAnimBtn = new QPushButton(AnimateGroup);
	QPixmap pixPause = QPixmap( tr(".\\media\\pause.bmp") );
	pixPause.setAlphaChannel( tr(".\\media\\pause_mask.bmp")  );
	QIcon psicon(pixPause);
	m_pauseAnimBtn->setIcon(psicon);
	m_pauseAnimBtn->setIconSize(pixPause.size());
	m_pauseAnimBtn->setCheckable(false);

	QGridLayout *drawLayout = new QGridLayout();
	drawLayout->addWidget(startAnim,0, 0);
	drawLayout->addWidget(m_pauseAnimBtn,0, 1);

	QGroupBox* penSpeedGroup = new QGroupBox(AnimateGroup);
	penSpeedGroup ->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *penSpeed = new QSlider(Qt::Horizontal, penSpeedGroup );
	penSpeed->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	penSpeedGroup->setTitle("Drawing Speed");
	penSpeed->setRange(4, 3000);
	QVBoxLayout *penSpeedLayout = new QVBoxLayout(penSpeedGroup);
	penSpeedLayout->addWidget(penSpeed);

	m_ShownLnGrp = new QGroupBox(tr("Numbers to Display:"), AnimateGroup);
	m_ShownLnGrp ->setAttribute(Qt::WA_ContentsPropagated);
	m_NumShownLnSld = new QSlider(Qt::Horizontal, m_ShownLnGrp);
	m_NumShownLnSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	m_NumShownLnSld->setRange(0,0);	
	QGridLayout *ShownLnSzLayout = new QGridLayout(m_ShownLnGrp);
	ShownLnSzLayout->addWidget(m_NumShownLnSld,0,0);	
	
	QGroupBox* penWidthGroup = new QGroupBox("Line Width", AnimateGroup); 
	penWidthGroup->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *penWidthSld = new QSlider(Qt::Horizontal, penWidthGroup);
	penWidthSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	penWidthSld->setRange(0, 500);
	QCheckBox *CHKCtrlTexLine = new QCheckBox("Control Textured Line",penWidthGroup);
	CHKCtrlTexLine->setChecked(false);
	QVBoxLayout *penWidthLayout = new QVBoxLayout(penWidthGroup);
	penWidthLayout->addWidget(penWidthSld);
	penWidthLayout->addWidget(CHKCtrlTexLine);

	m_ChkdefaultDraw = new QPushButton("Stylized", AnimateGroup);
	m_ChkdefaultDraw->setCheckable(true);
	QPushButton *newColor = new QPushButton("Color", AnimateGroup);
	QHBoxLayout *colorGroupLayout = new QHBoxLayout();
	colorGroupLayout->addWidget(m_ChkdefaultDraw);
	colorGroupLayout->addWidget(newColor);

	QGridLayout *cameraGroupLayout = new QGridLayout();
	QPushButton *scriptBtn		= new QPushButton("Camera Motion Script", AnimateGroup);
	cameraGroupLayout->addWidget(scriptBtn);


	QGroupBox* strokeDirGroup = new QGroupBox("Dominant Hand", AnimateGroup); 
	QHBoxLayout *StrokeDirGroupLayout = new QHBoxLayout(strokeDirGroup);
	m_LeftHandedCHK = new QRadioButton("Left", strokeDirGroup);
	m_RightHandedCHK = new QRadioButton("Right", strokeDirGroup);
	StrokeDirGroupLayout->addWidget(m_LeftHandedCHK);
	StrokeDirGroupLayout->addWidget(m_RightHandedCHK);
	m_RightHandedCHK->setChecked(true);

	QGroupBox* fadingRatioGrp = new QGroupBox(AnimateGroup);
	fadingRatioGrp->setAttribute(Qt::WA_ContentsPropagated);
	QGridLayout *fadingRenderingLyt = new QGridLayout(fadingRatioGrp);
	m_fadingTextureCHK = new QRadioButton("Texture", fadingRatioGrp);
	m_fadingGradientCHK = new QRadioButton("Gradient", fadingRatioGrp);
	m_fadingTextureCHK->setMinimumWidth(68);
	m_fadingGradientCHK->setMinimumWidth(70);
	fadingRenderingLyt->addWidget(m_fadingTextureCHK,0,0);
	fadingRenderingLyt->addWidget(m_fadingGradientCHK,0,1);
	m_fadingTextureCHK->setChecked(true);
	m_fadingRatioSld = new QSlider(Qt::Horizontal, fadingRatioGrp );
	m_fadingRatioSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	fadingRatioGrp->setTitle("Fading effects");
	m_fadingRatioSld->setRange(0, 400);
	fadingRenderingLyt->addWidget(m_fadingRatioSld,1,0,1,2);
	fadingRatioGrp->setEnabled(false);


	AnimateGrpLyt->addWidget(loadLinesButton);
	AnimateGrpLyt->addLayout(drawLayout, 0);
	AnimateGrpLyt->addWidget(strokeDirGroup);	
	AnimateGrpLyt->addWidget(penSpeedGroup);
	AnimateGrpLyt->addWidget(m_ShownLnGrp);
	AnimateGrpLyt->addWidget(penWidthGroup);
	AnimateGrpLyt->addLayout(colorGroupLayout, 0);
	AnimateGrpLyt->addWidget(fadingRatioGrp);
	AnimateGrpLyt->addLayout(cameraGroupLayout);
	AnimateGrpLyt->addStretch(1);

	//tab 2
	createCommonControls(illustrGroup);
	QVBoxLayout *illustraGrpLyt = new QVBoxLayout(illustrGroup);

	QGroupBox* traceLineGroup = new QGroupBox("Gesture Draw",illustrGroup);
	traceLineGroup ->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *trLnCurvySld = new QSlider(Qt::Horizontal, traceLineGroup );
	trLnCurvySld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
	trLnCurvySld->setRange(0,200);
	m_CHKdrawTrLn = new QCheckBox("Draw",illustrGroup);
	m_CHKdrawTrLn->setEnabled(false);
	QHBoxLayout *traceLineLayout = new QHBoxLayout(traceLineGroup);
	traceLineLayout->addWidget(m_CHKdrawTrLn);
	traceLineLayout->addWidget(trLnCurvySld);	
	trLnCurvySld->setEnabled(false);

	QPushButton *CHKshowPen = new QPushButton("Pen",illustrGroup);
	CHKshowPen->setCheckable(true);
	QPushButton *CHKshowTag = new QPushButton("Tag",illustrGroup);
	CHKshowTag->setCheckable(true);
	QPushButton *CHKDrawEndDir = new QPushButton("Tangent",illustrGroup);
	CHKDrawEndDir->setCheckable(true);
  

	QGridLayout *ShowItemLayout = new QGridLayout();
	ShowItemLayout->addWidget(CHKshowTag, 0,  0);
	ShowItemLayout->addWidget(CHKshowPen, 0,  1);		
	ShowItemLayout->addWidget(CHKDrawEndDir,0, 2);
	
	QPushButton *btnLoadPaper = new QPushButton("Paper",illustrGroup);
	QPushButton *btnLoadBrush = new QPushButton("Brush",illustrGroup);
	QPushButton *btnLoadBrushAlpha = new QPushButton("Alpha",illustrGroup);

	QGridLayout *LoadMaterialLayout = new QGridLayout();
	LoadMaterialLayout->addWidget(btnLoadPaper,		0,	0);
	LoadMaterialLayout->addWidget(btnLoadBrush,		0,	1);
	LoadMaterialLayout->addWidget(btnLoadBrushAlpha,	0,	2);
	
	QGroupBox* arrowSzSldGrp = new QGroupBox("Arrow Size",illustrGroup);
	arrowSzSldGrp->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *arrowSzSld = new QSlider(Qt::Horizontal, arrowSzSldGrp);
	arrowSzSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
	arrowSzSld->setRange(0, 100);

	QGroupBox* lnIdxSzSldGrp = new QGroupBox("Index Size",illustrGroup);
	lnIdxSzSldGrp->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *lnIdxSzSld = new QSlider(Qt::Horizontal, lnIdxSzSldGrp);
	lnIdxSzSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	lnIdxSzSld->setRange(0, 100);

	QGroupBox* lnIdxOffsetSldGrp = new QGroupBox("Index Offset",illustrGroup);
	lnIdxOffsetSldGrp ->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *lnIdxOffsetSld = new QSlider(Qt::Horizontal, lnIdxOffsetSldGrp );
	lnIdxOffsetSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	lnIdxOffsetSld->setRange(-100, 100);

	QGroupBox* pencilSizeGroup = new QGroupBox("Pencil Size",illustrGroup);
	pencilSizeGroup->setAttribute(Qt::WA_ContentsPropagated);
	QSlider *pencilSizeSld = new QSlider(Qt::Horizontal, penSpeedGroup );
	pencilSizeSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	pencilSizeSld->setRange(10, 500);

	QVBoxLayout *arrowSzLayout = new QVBoxLayout(arrowSzSldGrp);
	arrowSzLayout ->addWidget(arrowSzSld);	
	QVBoxLayout *LnIdxSzLayout = new QVBoxLayout(lnIdxSzSldGrp);
	LnIdxSzLayout->addWidget(lnIdxSzSld);	
	QVBoxLayout *LnIdxOffsetLayout = new QVBoxLayout(lnIdxOffsetSldGrp);
	LnIdxOffsetLayout ->addWidget(lnIdxOffsetSld);
	QVBoxLayout *PencilSizeLayout= new QVBoxLayout(pencilSizeGroup);
	PencilSizeLayout->addWidget(pencilSizeSld);
				
	illustraGrpLyt->addWidget(m_capGroup);
	illustraGrpLyt->addWidget(m_styleGroup);
	illustraGrpLyt->addWidget(traceLineGroup);
	illustraGrpLyt->addLayout(ShowItemLayout, 0);
	illustraGrpLyt->addLayout(LoadMaterialLayout,0);
	illustraGrpLyt->addWidget(arrowSzSldGrp);
	illustraGrpLyt->addWidget(lnIdxSzSldGrp);
	illustraGrpLyt->addWidget(lnIdxOffsetSldGrp);	
	illustraGrpLyt->addWidget(pencilSizeGroup);	
	illustraGrpLyt->addStretch(1);

    /***********Set up Connections**********************/
	connect(loadLinesButton,	SIGNAL(clicked()),			m_renderer, 	SLOT(openLineFile()));
	connect(startAnim,			SIGNAL(clicked(bool)),		m_renderer, 	SLOT(startAnimation(bool)));
	connect(startAnim,			SIGNAL(clicked(bool)),		m_pauseAnimBtn,	SLOT(setChecked(bool)));
	connect(m_pauseAnimBtn,		SIGNAL(toggled(bool)),		m_renderer, 	SLOT(pauseAnimation()));
	connect(m_NumShownLnSld,	SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setNumShownLn(int)));
	connect(CHKshowPen,			SIGNAL(toggled(bool)),		m_renderer, 	SLOT(setShowPen(bool)));
	connect(CHKshowTag,			SIGNAL(toggled(bool)),		m_renderer,		SLOT(setShowTag(bool)));
	connect(m_CHKdrawTrLn,		SIGNAL(toggled(bool)),		m_renderer,		SLOT(setDrawTraceLine(bool)));
	connect(m_CHKdrawTrLn,		SIGNAL(toggled(bool)),		trLnCurvySld,	SLOT(setEnabled(bool)));
	connect(CHKDrawEndDir,		SIGNAL(toggled(bool)),		m_renderer, 	SLOT(setShowEndDir(bool)));	
	connect(btnLoadPaper,		SIGNAL(clicked()),			m_renderer, 	SLOT(openBackPaperImg()));
	connect(btnLoadBrush,		SIGNAL(clicked()),			m_renderer, 	SLOT(loadBrushTex()));
	connect(btnLoadBrushAlpha,	SIGNAL(clicked()),			m_renderer, 	SLOT(loadBrushTexAlpha()));
    connect(penWidthSld,		SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setPenWidth(int)));
	connect(CHKCtrlTexLine,		SIGNAL(toggled(bool)),		m_renderer, 	SLOT(setControlTexturedLineWidth(bool)));
	connect(penSpeed,			SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setPenSpeed(int)));
	connect(trLnCurvySld,		SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setTRaceLineCurvy(int)));
	connect(m_ChkdefaultDraw,	SIGNAL(toggled(bool)),		m_renderer, 	SLOT(setDefaultLineRenderProperty(bool)));
	connect(m_ChkdefaultDraw,	SIGNAL(toggled(bool)),		this, 			SLOT(swapDefaultDrawBtnText(bool)));
	connect(m_ChkdefaultDraw,	SIGNAL(toggled(bool)),		fadingRatioGrp,	SLOT(setDisabled(bool)));	
	connect(m_ChkdefaultDraw,	SIGNAL(toggled(bool)),		CHKCtrlTexLine,	SLOT(setDisabled(bool)));	
	connect(m_ChkdefaultDraw,	SIGNAL(toggled(bool)),		newColor,		SLOT(setEnabled(bool)));	
	connect(newColor,			SIGNAL(clicked()),			m_renderer, 	SLOT(pickLineColor()));
	connect(arrowSzSld,			SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setArrowSz(int)));
	connect(lnIdxSzSld,			SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setLnIdxSz(int)));
	connect(lnIdxOffsetSld,		SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setLnIdxOffset(int)));
	connect(pencilSizeSld,		SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(setPencilSize(int)));
	connect(scriptBtn,			SIGNAL(clicked()),			m_renderer, 	SLOT(popScriptDlg()));
	connect(m_LeftHandedCHK,	SIGNAL(clicked()),			m_renderer, 	SLOT(orientStroke()));
	connect(m_RightHandedCHK,	SIGNAL(clicked()),			m_renderer, 	SLOT(orientStroke()));
	connect(m_fadingTextureCHK,	SIGNAL(clicked()),			m_renderer, 	SLOT(FadingType()));
	connect(m_fadingGradientCHK,SIGNAL(clicked()),			m_renderer, 	SLOT(FadingType()));
	connect(m_fadingRatioSld,	SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(RemakeFadingTexture()));
	connect(m_fadingRatioSld,	SIGNAL(valueChanged(int)),	m_renderer, 	SLOT(RemakeFadingGradient()));
	

	// Set the defaults
	startAnim->setChecked(false);
	m_pauseAnimBtn->setChecked(false);
	penSpeed->setValue(240);    
	penWidthSld->setValue(2);
	m_ChkdefaultDraw->setChecked(false);
	arrowSzSld->setValue(45);
	lnIdxSzSld->setValue(37);
	newColor->setDisabled(true);

	lnIdxOffsetSld->setValue(39);		
	CHKshowPen->setChecked(true);
	pencilSizeSld->setValue(100);
	CHKshowTag->setChecked(false);
	CHKDrawEndDir->setChecked(false);
}

void SketcherControls::swapDefaultDrawBtnText(bool b){
	if(b)	m_ChkdefaultDraw->setText(tr("Default"));
	else	m_ChkdefaultDraw->setText(tr("Stylized"));
}

void SketcherRenderer::popScriptDlg(){
	m_ConfigScriptDlg->setWindowModality(Qt::NonModal);
	m_ConfigScriptDlg->activateWindow();
	m_ConfigScriptDlg->setWindowState(Qt::WindowNoState);
	m_ConfigScriptDlg->show();
}

const float enh(10.0);
void SketcherRenderer::moveCamUp(){
	LINE::m_origin.ry() -= 10.0 * enh;		
	updateContentForCamera();	update();
}
void SketcherRenderer::moveCamDown(){
	LINE::m_origin.ry() += 10.0* enh;
	updateContentForCamera();	update();
}
void SketcherRenderer::moveCamRight(){
	LINE::m_origin.rx() += 10.0* enh;
	updateContentForCamera();	update();
}
void SketcherRenderer::moveCamLeft(){
	LINE::m_origin.rx() -= 10.0* enh;
	updateContentForCamera();	update();
}
void SketcherRenderer::zoomCamOut(){
	LINE::m_zoom += 0.05f;
	updateContentForCamera();	update();
}
void SketcherRenderer::zoomCamIn(){
	LINE::m_zoom -= 0.05f;
	updateContentForCamera();	update();
}

void SketcherControls::emitQuitSignal()
{   emit quitPressed();  }

void SketcherControls::emitOkSignal()
{   emit okPressed();   }


void SketcherControls::keyPressEvent( QKeyEvent *event )
{
	switch (event->key() )
	{

	case Qt::Key_W:
		m_renderer->moveCamUp();
		break;
	case Qt::Key_S:
		m_renderer->moveCamDown();
		break;
	case Qt::Key_A:
		m_renderer->moveCamLeft();
		break;
	case Qt::Key_D:
		m_renderer->moveCamRight();
		break;
	case Qt::Key_BracketLeft:
		m_renderer->zoomCamIn();
		break;
	case Qt::Key_BracketRight:
		m_renderer->zoomCamOut();
		break;
	default:
		event->ignore();
		return;
	}
	event->ignore();
	event->accept();
}

SketcherWidget::SketcherWidget(bool smallScreen)
{
    setWindowTitle(tr("Sketcher"));

	// Widget construction and property setting
    m_renderer = new SketcherRenderer(this, smallScreen);

    m_controls = new SketcherControls(0, m_renderer, smallScreen);
	
    // Layouting
    QHBoxLayout *viewLayout = new QHBoxLayout(this);
    viewLayout->addWidget(m_renderer);

    if (!smallScreen)
        viewLayout->addWidget(m_controls);

    m_renderer->loadSourceFile(":res/sketcher.cpp");
    m_renderer->loadDescription(":res/sketcher.html");

    connect(m_renderer, SIGNAL(clicked()), this, SLOT(showControls()));
    connect(m_controls, SIGNAL(okPressed()), this, SLOT(hideControls()));
    connect(m_controls, SIGNAL(quitPressed()), QApplication::instance(), SLOT(quit()));
	
	m_renderer->m_controller = m_controls;
}


void SketcherWidget::showControls()
{
    m_controls->showFullScreen();
}


void SketcherWidget::hideControls()
{
    m_controls->hide();
}


void SketcherWidget::setStyle( QStyle * style )
{
    QWidget::setStyle(style);
    if (m_controls != 0)
    {
        m_controls->setStyle(style);
        
        QList<QWidget *> widgets = qFindChildren<QWidget *>(m_controls);
        foreach (QWidget *w, widgets)
            w->setStyle(style);
    }
}

SketcherRenderer::SketcherRenderer(QWidget *parent, bool smallScreen)
: ArthurFrame(parent)
{
	m_ConfigScriptDlg = NULL;
	m_nShownLn = 0;
	initSound();

	initTextureBrush();

    m_capStyle = Qt::RoundCap;
    m_joinStyle = Qt::BevelJoin;
    m_penWidth = 1;
    m_penStyle = Qt::SolidLine;
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
		
	setMouseTracking(true);

	setBackgroundImg( tr(".\\media\\paper.png") );

	m_pencilImg_Save.load( tr(".\\media\\pencil.png") );
	m_pencilImg_Save.setAlphaChannel( QImage( tr(".\\media\\pencil_mask.png") ) );
	m_pencilImg = m_pencilImg_Save;

	m_bRightHanded = true;	//true means right handed. left the verse.

	m_pencilPos= QPointF(-510,-510);
	m_pencilOffset = QPointF(2,2);

	m_bShowPen = false;
	m_bAnimating = false;

	m_color = Qt::darkGray;

	LINE::m_skqTimer.Stop();
	m_skqingLnId = -1;
	
	///////////////SkqSound.setLoops(10000);
	///////////////F1.pause();

	m_nL =  0;
	m_trLnGapRate = 1.0f;
	m_bControlTexedLnWidth = false;
	m_bDrawTraceLn = false;
	m_bShowPen = true;
	m_bShowTag = false;
	m_bShowEndDir = false;

	IDX_TAG_OFFSET = 10;
	lnIdxTextHlfSize = 10;
	SkeqDirArrowSz = 22;
	ArrowAngle = 8.5;

	m_color.setRed(65);	m_color.setGreen(65);	m_color.setBlue(65);

	m_TE = RT_DrawLine;

	m_ConfigScriptDlg = new CameraMotionDlg(this, this);
}

void SketcherRenderer::mousePressEvent(QMouseEvent *e)
{
    setDescriptionEnabled(false);
   
    if(e->button() == Qt::RightButton){
		m_mouseRbtnDownPos = e->pos();		
		m_fZoomSv = LINE::m_zoom;		
	}    
	m_mousePos =  e->pos();	
}


void SketcherRenderer::mouseDoubleClickEvent( QMouseEvent *e )
{
	LINE::m_origin = QPointF(0.0f, 0.0f);	LINE::m_zoom = 1.0f;
	updateContentForCamera();
	update();
}

void SketcherRenderer::mouseMoveEvent(QMouseEvent *e)
{
	if(e->buttons() == Qt::MidButton || e->buttons() == Qt::LeftButton){
		LINE::m_origin += e->pos() - m_mousePos ;			
 		updateContentForCamera();
 		update();
	}
		
	if(e->buttons() == Qt::RightButton){		
		QPointF realMsPos = LINE::Draw2Real(m_mouseRbtnDownPos);	
		LINE::m_zoom = m_fZoomSv + ( e->pos().y() - m_mouseRbtnDownPos.y() ) *0.002;
		LINE::m_origin = m_mouseRbtnDownPos - realMsPos*LINE::m_zoom;
		updateContentForCamera();
		update();
    }
	m_mousePos =  e->pos();	
}

void SketcherRenderer::mouseReleaseEvent(QMouseEvent *)
{
}

void SketcherRenderer::wheelEvent(QWheelEvent *e)
{
	int zDelta = e->delta();
	
	QPointF realMsPos = LINE::Draw2Real( m_mousePos );

	LINE::m_zoom += zDelta * 0.0008f ;
	LINE::m_origin = m_mousePos - realMsPos*LINE::m_zoom;
	updateContentForCamera();
	update();
}

void SketcherRenderer::startAnimation(bool A)
{
	if(m_nL==0)	return;
	m_nShownLn = m_nL;
	m_controller->m_NumShownLnSld->setValue(m_nL);
	
	m_iterScript = m_Scripts.begin();
	
	m_skqingLnId = 0;

	if(m_nL){
		LINE & Ln = m_Lines[0];	
		Ln.m_bSkqing = true; //you need to get started.	
		Ln.m_skqingSegId = 0;
		m_bAnimating = true;
		LINE::m_skqTimer.Start();
		m_cameraTimer.Start();		
		LINE::m_skqTimer.Reset();	
		m_timer.start(0, this);
		restartSound();
		m_controller->m_NumShownLnSld->setValue(m_skqingLnId);
		m_controller->m_ShownLnGrp->setTitle("Now drawing line " + QString::number(m_skqingLnId) );
		m_ConfigScriptDlg->m_NumLineSld->setValue(m_skqingLnId);
		m_ConfigScriptDlg->m_ShownLnGrp->setTitle("Now drawing line " + QString::number(m_skqingLnId) );
	}	
}

void SketcherRenderer::pauseAnimation()
{
	if(m_nL==0)	return;
	if(!m_bAnimating){		
		m_bAnimating = true;
		m_timer.start(0, this);
		playSound();
	}
	else{
		m_bAnimating = false;
		m_timer.stop();
		pauseSound();
	}	
	update();
}

inline void SketcherRenderer::timerEvent(QTimerEvent *e)
{
	switch(m_TE){
		case RT_DrawLine:
			updateContentForAnim();
			break;
		case RT_TransferPen:
			transferPencil();
			break;
		case RT_CameraMotion:
			AnimateCamera();
			break;
	}	
	update();	
}

inline void SketcherRenderer::AnimateCamera()
{	
	if(m_cameraTimer.GetTime()>m_iterScript->life) {
		updateAllLnDrawingPts();
		m_TE = RT_TransferPen;
		m_iterScript++;
		return;
	}
	LINE::m_zoom = m_cameraTimer.GetTime() * m_iterScript->Zoom_Ratio + m_iterScript->Zoom_bgn;

	LINE::m_origin = m_cameraTimer.GetTime() * m_iterScript->Org_Ratio + m_iterScript->Org_bgn;

	m_AllPaths.clear();	m_AllPaths.resize(m_nL); 

	for (int i=0; i<m_skqingLnId+1; ++i)
	{
		m_Lines[i].updateDrawPts();
		m_Lines[i].updateFullPainterPath(m_AllPaths[i] );
	}
}

inline void SketcherRenderer::transferPencil()
{	
	if( m_Lines[m_skqingLnId].transferPencil(m_pencilPos) )
	{
		m_skqingLnId++;
		m_Lines[m_skqingLnId].m_bSkqing = true;
		m_Lines[m_skqingLnId].m_skqingSegId = 0;
		m_TE = RT_DrawLine;
		LINE::m_skqTimer.Reset(); 	
		restartSound();
		m_controller->m_NumShownLnSld->setValue(m_skqingLnId);
		m_controller->m_ShownLnGrp->setTitle("Now drawing line " + QString::number(m_skqingLnId) );
		m_ConfigScriptDlg->m_NumLineSld->setValue(m_skqingLnId);
		m_ConfigScriptDlg->m_ShownLnGrp->setTitle("Now drawing line " + QString::number(m_skqingLnId) );
	}
}

void SketcherRenderer::updateContentForCamera(){
	if(m_nL==0)	return;
	updateAllLnDrawingPts();
	m_AllPaths.clear(); m_AllPaths.resize(m_nL);

	if(m_bAnimating){
		if(m_TE == RT_TransferPen){
			for (int i=0; i<m_skqingLnId+1; ++i)
				m_Lines[i].updateFullPainterPath( m_AllPaths[i] );
		}
	}
	else{//update full drawing paths

		for (int i=0; i<m_nL; ++i){
			m_Lines[i].updateDrawPts();
			m_Lines[i].updateFullPainterPath(m_AllPaths[i]);
		}

		m_pencilPos = LINE::Real2Draw(m_Lines[0][0]);

		if(m_bDrawTraceLn)	MakeTraceLine();
	}
	if(!m_bDefaultLook){
		for (int i=0; i<m_nL; ++i){
			if(m_Lines[i].m_bUseTex)	m_Lines[i].updateFullTexturedPainterPath();
		}
	}
}

inline void SketcherRenderer::updateContentForAnim()
{	
	m_AllPaths.clear(); m_AllPaths.resize(m_nL);
	
	for( int i=0; i<m_nL; ++i)
	{
		if(m_Lines[i].m_bSkqing ){  //the one single line in the current animation progress.			
			bool bFinished;
			if(m_bDefaultLook)
				bFinished = m_Lines[i].ProduceAnimatingLinePath(m_AllPaths[i], m_pencilPos);
			else{
				if(!m_Lines[i].m_bUseTex)
					bFinished = m_Lines[i].ProduceAnimatingLinePath(m_AllPaths[i], m_pencilPos);
				else
					bFinished = m_Lines[i].ProduceAnimatingTexturedLinePath(m_pencilPos);
			}
			if(bFinished){				
				//if it's been finished, start to transfer or stop.
				if( i==m_nL-1 ){  //there is no lines left, so stop.				
					stopSound();
					m_TE = RT_DrawLine;
					return;
				}	
				stopSound();
				m_TE = RT_TransferPen;
				LINE::m_skqTimer.Reset(); 
				//camera
				if(m_iterScript->IdxLn == i){
					m_cameraTimer.Reset();
					m_TE = RT_CameraMotion;
				}			
			}		
			return; //stop drawing more.
		}
		else{	
			if(m_bDefaultLook){
				m_Lines[i].updateFullPainterPath(m_AllPaths[i] );
			}			
			else{
				if(m_Lines[i].m_bUseTex)
					m_Lines[i].updateFullTexturedPainterPath();
				else
					m_Lines[i].updateFullPainterPath(m_AllPaths[i] );
			}		
		}
	}
}

void SketcherRenderer::openLineFile()
{
	QDir lastDir = QDir::current();
	currentPath = QFileDialog::getOpenFileName(this, tr("Open Line File"), lastDir.absolutePath() , "*.sply");
		
	if(!currentPath.isEmpty()){
		lastDir = QFileInfo(currentPath).absoluteDir();
		QDir::setCurrent( lastDir.absolutePath());			
	}
	else return;

	std::string fn = q2s(currentPath);
	const char* ch_filename = fn.c_str();
	
	FILE *fp;
	if( (fopen_s(&fp, ch_filename, "rt"))==NULL ){
		
		stopSound();
		m_Lines.clear(); m_nL = 0; m_AllnV = 0;

		// skip the comment lines
		char str[256];
		fgets( str, 256, fp );
		fgets( str, 256, fp );
		
		fscanf_s( fp, "%d\n", &m_nL);
		m_Lines.resize(m_nL);
		
		for( int i=0; i<m_nL; i++ )
		{
			m_Lines[i].read(fp);
			
			m_AllnV += m_Lines[i].nP();;
			
		}
		fclose(fp);

		updateContentForCamera();
	
		initTransferInfo();
		MakeTraceLine();
		
		LINE::m_skqTimer.Stop();
		m_bAnimating = false;
		m_TE = RT_DrawLine;
		m_skqingLnId = -1;

		m_pencilPos = m_Lines[0].getDrawP()[0];
		m_controller->m_CHKdrawTrLn->setEnabled(true);
		m_controller->m_pauseAnimBtn->setCheckable(true);

		m_Scripts.clear();
		m_iterScript = m_Scripts.begin();
		if(m_ConfigScriptDlg) {
			m_ConfigScriptDlg->m_NumLineSld->setRange(0,m_nL);
			m_ConfigScriptDlg->m_NumLineSld->setValue(m_nL);
			m_ConfigScriptDlg->m_NumLineSld->setEnabled(true);
			m_ConfigScriptDlg->RefreshList();
		}
	}

	m_nShownLn = m_nL;
	
	m_controller->m_NumShownLnSld->setRange(0,m_nL);
	m_controller->m_NumShownLnSld->setValue(m_nL);
	orientStroke();
	update();	
}

void SketcherRenderer::openBackPaperImg(){
	QString file = QFileDialog::getOpenFileName(this, tr("Open image"), tr(".\\media"));
	if(!file.isEmpty()){
		setBackgroundImg( file );
		update();	
	}
}

#define station_brush_texture 0

void SketcherRenderer::loadBrushTex(){
	QString file = QFileDialog::getOpenFileName(this, tr("Open image"), tr(".\\media"));
	if(!file.isEmpty()){		
		m_brushTexImg.load(file);	
#if  station_brush_texture 
#else
		for (int i=0; i<m_nL; ++i)	{
			m_Lines[i].initSegBrushTex(m_brushTexImg);		m_Lines[i].synthSegBrushTex(m_brushTexImg);
		}
#endif
		update();	
	}
}

void SketcherRenderer::loadBrushTexAlpha(){
	QString file = QFileDialog::getOpenFileName(this, tr("Open image"), tr(".\\media"));
	if(!file.isEmpty()){
		m_brushAlphaImg.load(file);		m_brushTexImg.setAlphaChannel(m_brushAlphaImg);
		update();	
	}
}

void SketcherRenderer::pickLineColor(){
	QColor col= QColorDialog::getColor(col , this);
	if (!col.isValid())	return;
	m_color = col;
	update();	
}

void SketcherRenderer::initTextureBrush(){	
	m_brushTexImg.load(tr(".\\media\\brush.bmp"));
}

void SketcherRenderer::paint(QPainter *painter){
 	painter->setRenderHint(QPainter::SmoothPixmapTransform);
	painter->setRenderHint(QPainter::HighQualityAntialiasing);

	QPalette pal = palette();

 	/* Draw the path */
		
	if(m_bDrawTraceLn){
		myPathStroker.setWidth(m_penWidth);
		myPathStroker.setCapStyle(m_capStyle);
		myPathStroker.setDashPattern(m_penStyle);
		DrawTraceLine(painter, myPathStroker, m_brushTexImg);	
	}
	else{
		QPen pen(m_color, m_penWidth, m_penStyle, m_capStyle, m_joinStyle);
		int nL =  m_bAnimating ? m_skqingLnId+1 : m_nShownLn; 
		if(m_bDefaultLook){
			for (int i=0; i<nL; ++i)	painter->strokePath(m_AllPaths[i], pen);		
		}
		else{	
			for (int i=0; i<nL; ++i){
				if (m_Lines[i].m_bUseTex) {  //use textured brush.
					if(m_bFadingTex)	m_Lines[i].DrawTexturePath_Texture(painter);			
					else				m_Lines[i].DrawTexturePath_Gradient(painter);
					m_Lines[i].updateFullTexturedPainterPath();
				}	
				else{
					pen.setColor(m_Lines[i].m_LineColor);
					pen.setWidth(m_Lines[i].m_fLineWidth);
					painter->strokePath(m_AllPaths[i], pen);			
				}
			}
		}

		if(m_bShowTag){
			painter->setFont( QFont( "SansSerif", lnIdxTextHlfSize, QFont::DemiBold ) );
			for (int i=0; i<m_nL; ++i){
				painter->drawText(	
					LINE::Real2Draw(m_Lines[i].m_lnIdxPos).x() - lnIdxTextHlfSize ,
					LINE::Real2Draw(m_Lines[i].m_lnIdxPos).y() - lnIdxTextHlfSize ,
					2*lnIdxTextHlfSize , 2*lnIdxTextHlfSize , 
					Qt::AlignCenter , QString::number(i));
			}
			for (int i=0; i<m_nL; ++i)	m_Lines[i].DrawMidArrow(painter);
		}

		if(m_bShowEndDir)
			for (int i=0; i<m_nL; ++i)	m_Lines[i].DrawHeadTailDir(painter);	
		
		if(m_bShowPen)
			painter->drawImage(	m_pencilPos-m_pencilOffset, m_pencilImg);
	}	
}

void SketcherRenderer::updateAllLnDrawingPts()
{
	for (int i=0; i<m_nL; ++i)	m_Lines[i].updateDrawPts();	
}

void SketcherRenderer::setNumShownLn( int sz )
{
	if(!m_bAnimating){
		updateContentForCamera();
		m_nShownLn = sz;			
		m_controller->m_ShownLnGrp->setTitle("Number to Display:" + QString::number(m_nShownLn) );
		m_ConfigScriptDlg->m_NumLineSld->setValue(m_nShownLn);
		m_ConfigScriptDlg->m_ShownLnGrp->setTitle("Number to Display:" + QString::number(m_nShownLn) );
	}
	else{
		if(sz>m_nL-1) return;
		m_skqingLnId = sz;
		m_controller->m_ShownLnGrp->setTitle("Now drawing line " + QString::number(m_skqingLnId) );
		for (int i=0; i<m_skqingLnId; ++i)	m_Lines[i].m_bSkqing = false;
		m_Lines[m_skqingLnId].m_bSkqing = true;	m_Lines[m_skqingLnId].m_skqingSegId = 0;
		m_ConfigScriptDlg->m_NumLineSld->setValue(m_skqingLnId);
		m_ConfigScriptDlg->m_ShownLnGrp->setTitle("Now drawing line " + QString::number(m_skqingLnId) );
	}
	update();
}

void SketcherRenderer::orientStroke()
{
	if(m_nL==0)	return;
	
	if( m_controller->m_RightHandedCHK->isChecked() ){	
		for (int i=0; i<m_nL; ++i)		m_Lines[i].OrientByHanded();
		m_pencilOffset = QPointF(2,2);		
	}		
	else{
		for (int i=0; i<m_nL; ++i)		m_Lines[i].OrientByHanded(false);
		m_pencilOffset = QPointF(-2,2) + QPointF(m_pencilImg.size().rwidth(),0);
	}

	if(m_bRightHanded!=m_controller->m_RightHandedCHK->isChecked()){
		m_pencilImg_Save = m_pencilImg_Save.mirrored(true, false);
		m_pencilImg = m_pencilImg.mirrored(true, false);
	}

	m_bRightHanded = m_controller->m_RightHandedCHK->isChecked();
	m_pencilPos = m_Lines[0].getDrawP()[0];
	initTransferInfo();
	update();
}


void SketcherRenderer::FadingType()
{
	if(m_nL==0)	return;

	if( m_controller->m_fadingGradientCHK->isChecked() ){	
		m_bFadingTex = false;			
	}		
	else{
		m_bFadingTex = true;
		for (int i=0; i<m_nL; ++i)	m_Lines[i].updateFullTexturedPainterPath();		
	}
	update();
}


void SketcherRenderer::RemakeFadingTexture()
{
	if(!m_bFadingTex) return;
	LINE::m_fFadingLenRatio = m_controller->m_fadingRatioSld->value()/600.0f;	
	LINE::m_fFadingLenRatio = LINE::m_fFadingLenRatio > .0f? LINE::m_fFadingLenRatio : 0.0001;
	
	for (int i=0; i<m_nL; ++i)	{
		m_Lines[i].synthSegBrushTex(m_brushTexImg);
		m_Lines[i].updateFullTexturedPainterPath();
	}
	update();	
}

void SketcherRenderer::RemakeFadingGradient()
{
	if(m_bFadingTex)	return;
	LINE::m_fFadingLenRatio = m_controller->m_fadingRatioSld->value()/600.0f;	
	LINE::m_fFadingLenRatio = LINE::m_fFadingLenRatio > .0f? LINE::m_fFadingLenRatio : 0.0001;
	for (int i=0; i<m_nL; ++i)	{
		m_Lines[i].getValpha();
		m_Lines[i].updateFullTexturedPainterPath();
	}
	update();	
}

void SketcherRenderer::setDefaultLineRenderProperty( bool bDefault )
{
	m_bDefaultLook = bDefault;		update();
}


bool LINE::Left( QPointF a, QPointF b, QPointF c ) /* Returns true iff c is strictly to the left of the directed line through a to b. */
{
	double CrossZ = ( b.x()-a.x() )*( c.y()-a.y() ) - ( c.x()-a.x() )*( b.y()-a.y() );
	return (CrossZ > 0.0);
}

double LINE::Curvature( int i ) /* curvature for the Seg_i(Vi, Vi+1) */
{
	int nv = nP();
	if ( i==0 || i==nv-1 ) return 0.0;

	QPointF dRdsA, dRdsB, CurvVector;
	double Length, LengthFracA, LengthFracB;

	// if R(t) is a parametric curve with arc length s, then the tangent vector
	// to the curve R(t) is T(t) = R'(t) / |R(t)|, which can be rewritten as
	// T(s) = dR/ds

	// Calculate unit tangent vector to curve using points i and i-1
	Length = m_segLen[i-1];		

	LengthFracA = double(1.0) / Length;
	dRdsA = ( m_pts[i] - m_pts[i-1] ) * LengthFracA;	

	// Calculate unit tangent vector to curve using points i and i+1
	Length = m_segLen[i];

	LengthFracB = double(1.0) / Length;
	dRdsB = ( m_pts[i+1] - m_pts[i] ) * LengthFracB;		

	// The curvature is defined as k(s) = |dT/ds| ( = |T'|/|R'|, '=d/dt)
	// Warning: dodgy averaging used here :)

	CurvVector = (dRdsB - dRdsA ) * LengthFracA;		

	double Curvature = sqrt( squareMagnitude(CurvVector) );

	if (!Left(m_pts[i-1],m_pts[i], m_pts[i+1]))
		Curvature = -Curvature;

	return Curvature;
}

const float ML_DEG_TO_RAD		= 0.0174532925f;
const float ML_RAD_TO_DEG		= 57.295779513f;

void LINE::allSegLenAndVct()
{
	int ns = m_bClosed? nP() : nP() - 1 ;

	m_segLen.clear();	m_segLen.resize(ns);	
	m_segDir.clear();	m_segDir.resize(ns);
	m_segAngel.clear();	m_segAngel.resize(ns);

	for (int i=0; i<ns; ++i){
		m_segDir[i] = m_pts[ (i+1)%nP() ] - m_pts[i%nP()];

		m_segAngel[i] = atan( m_segDir[i].y()/m_segDir[i].x() ) * ML_RAD_TO_DEG;

		m_segLen[i] = sqrt( squareMagnitude(m_segDir[i]) );

		m_segDir[i] /= m_segLen[i];		
	}

	m_TotalLength = std::accumulate(m_segLen.begin(), m_segLen.end(), 0.0);
}

void LINE::allSegCurvature()
{
	int ns = m_bClosed? nP() : nP() - 1 ;
	m_curvature.clear();	m_curvature.resize(ns);
	//fishy
	for (int i=0; i<ns-1; ++i)	m_curvature[i] = Curvature(i);
	if(m_bClosed) m_curvature.push_back(m_curvature.back());
}


void LINE::allSegDrawSpeed( int R /*= 5*/, bool bSeeDbg /*= true*/ )
{
	int nSeg = m_bClosed? nP() : nP() - 1 ;

	QVector<float> curvAbs(nSeg);
	for (int i=0; i<nSeg; ++i)	curvAbs[i] = fabs(m_curvature[i]);
	
	m_drawSpeed.clear();	m_drawSpeed.resize(nSeg);
	
	for (int i=0; i<nSeg; ++i)
	{
		if(curvAbs[i]>0.0185)
			m_drawSpeed[i] = m_curvySpeed;
		else{
			m_drawSpeed[i] = m_smthSpeed;
		}
	}

	//smooth twice!	
	int nHalfRng = nSeg > R ? R : nSeg-1;

	for (int i=0; i<nSeg; ++i){
		int head = CLIP(i-nHalfRng, 0, nSeg-1);
		int tail = CLIP(i+nHalfRng, 0, nSeg-1); tail++;
		float totalWt(0.0f);
		curvAbs[i] = 0.0f;
		for (int ii=head; ii<tail; ++ii)
		{
			float wt = R - fabs( float(ii-i) ); 
			wt = wt * wt * wt* wt * wt * wt ;
			curvAbs[i] += m_drawSpeed[ii] * wt;
			totalWt += wt;
		}			
		curvAbs[i] /= totalWt;
	}	

	for (int i=0; i<nSeg; ++i){
		int head = CLIP(i-nHalfRng, 0, nSeg-1);
		int tail = CLIP(i+nHalfRng, 0, nSeg-1); tail++;
		float totalWt(0.0f);
		m_drawSpeed[i] = 0.0f;
		for (int ii=head; ii<tail; ++ii)
		{
			float wt = R - fabs( float(ii-i) ); 
			wt = wt * wt * wt* wt * wt * wt ;
			m_drawSpeed[i] += curvAbs[ii] * wt;
			totalWt += wt;
		}			
		m_drawSpeed[i] /= totalWt;
	}	

	//begin end slowing down.
	int h = nSeg>6? 6 : nSeg;
	for (int i=0; i<h; ++i)
	{
		m_drawSpeed[i] = 50;	m_drawSpeed[nSeg-i-1] = 85;
	}
}

void LINE::initDrawStaticInfo( )
{
	m_drawPts.clear();	m_drawPts.resize( nP() ); 		
	allSegLenAndVct();
	allSegCurvature();	
	allSegDrawSpeed();
	LineMidPoint();
	fitHeadTailDir();	
	getValpha();
	initSegBrushTex(SketcherRenderer::m_brushTexImg);
	synthSegBrushTex(SketcherRenderer::m_brushTexImg);
	if(m_bUseTex)	initAllSegOutLinePathAndTrfm();
}

void LINE::updateFullPainterPath( QPainterPath &paintPath )
{
	paintPath.moveTo( m_drawPts[0] );
	for (int i=1; i<nP(); ++i)	paintPath.lineTo( m_drawPts[i] );
	if (m_bClosed) paintPath.lineTo( m_drawPts[0] );
}

void LINE::updateFullTexturedPainterPath()
{
	if(!m_bUseTex) return;
	QPainterPathStroker  Stroker;
	Stroker.setWidth(LINE::m_fTexLineWidth);	

	if(LINE::m_fTexLineWidth>4.5)	Stroker.setCapStyle(Qt::RoundCap);
	else							Stroker.setCapStyle(Qt::FlatCap);

	int nS = m_bClosed? nP() : nP() - 1 ;
	for (int i=0; i<nS; ++i){
		QPainterPath basePath;
		basePath.moveTo(m_drawPts[i%nP()]);
		basePath.lineTo(m_drawPts[(i+1)%nP()]);
		m_SegOutLinePath[i] = Stroker.createStroke(basePath);	
	}
}

bool LINE::ProduceAnimatingTexturedLinePath( QPointF &PencilPos )
{
	float dist2Skq = m_drawSpeed[m_skqingSegId] * m_spdRadtio * m_skqTimer.GetTime();

	QPainterPathStroker Stroker;
	Stroker.setWidth(LINE::m_fTexLineWidth);		
	if(SketcherRenderer::m_bFadingTex)	Stroker.setCapStyle(Qt::FlatCap);
	else								Stroker.setCapStyle(Qt::RoundCap);

	if( dist2Skq <= m_segLen[m_skqingSegId] )
	{
		QPainterPath basePath; 
		PencilPos = m_drawPts[m_skqingSegId] + m_segDir[m_skqingSegId]*dist2Skq*m_zoom;						
		basePath.moveTo( m_drawPts[m_skqingSegId] );
		basePath.lineTo( PencilPos );
		m_SegOutLinePath[m_skqingSegId] = Stroker.createStroke(basePath);
		return false; //unfinished yet, still drawing this segments.
	}    
	else{
		++m_skqingSegId;
		if(m_skqingSegId >= nP()-1)	{//the line skqing finished, start transferring.
			m_skqTimer.Reset();			
			m_bSkqing = false;
			return true;  
		}
		else{//unfinished yet, turning at the corner vertex.
			m_skqTimer.Reset();

			QPainterPath basePath; 
			basePath.moveTo(m_drawPts[m_skqingSegId-1]);
			basePath.lineTo(m_drawPts[m_skqingSegId]);
			m_SegOutLinePath[m_skqingSegId-1] = Stroker.createStroke(basePath);

			return false;  
		}
	}
}

void LINE::initAllSegOutLinePathAndTrfm()
{
	QPainterPathStroker Stroker;
	Stroker.setWidth(LINE::m_fTexLineWidth);		
	if(SketcherRenderer::m_bFadingTex)	Stroker.setCapStyle(Qt::FlatCap);
	else									Stroker.setCapStyle(Qt::RoundCap);

	int nS = m_bClosed? nP() : nP() - 1 ;

	m_SegOutLinePath.clear();	m_SegOutLinePath.resize(nS);
	m_SegBrushTrfm.clear();		m_SegBrushTrfm.resize(nS);

	for (int i=0; i<nS; ++i){

		QPainterPath basePath, outLinePath; 

		basePath.moveTo(m_pts[i%nP()]);
		basePath.lineTo(m_pts[(i+1)%nP()]);
		m_SegOutLinePath[i] = Stroker.createStroke(basePath);
		QTransform t; t.rotate(m_segAngel[i]); 			
		m_SegBrushTrfm[i] = t;
	}
}

void LINE::DrawTexturePath_Texture( QPainter *painter )
{
	QBrush brush;
#if 	station_brush_texture
	brush.setTextureImage(SketcherRenderer::m_brushTexImg);	
	if(m_bSkqing)
		for (int i=0; i<m_skqingSegId+1;  ++i)	
			painter->fillPath(m_SegOutLinePath[i], brush); 									
	else
		for (int i=0; i<nP()-1; ++i)			
			painter->fillPath(m_SegOutLinePath[i], brush ); 									
#else
	if(m_bSkqing){			
		for (int i=0; i<m_skqingSegId+1;  ++i){	
			brush.setTextureImage(m_SegBrushTexImg[i]);	
			brush.setTransform(m_SegBrushTrfm[i]);				
			painter->fillPath(m_SegOutLinePath[i], brush); 									
		}
	}
	else{
		int nS = m_bClosed? nP() : nP() - 1 ;
		for (int i=0; i<nS; ++i){			
			brush.setTextureImage(m_SegBrushTexImg[i]);	
			brush.setTransform(m_SegBrushTrfm[i]);
			painter->fillPath(m_SegOutLinePath[i], brush ); 									
		}
	}
#endif
}

void drawArrow( const QPointF& head, const QPointF& tail, double axLen, QPainter *painter)
{
	QPointF pd, pa, pb;
	double tangent;

	QVector<QPointF> arr;

	pd = tail - head;
	
	if (pd.x() == 0 && pd.y() == 0)		return;
	
	tangent = atan2 ((double) pd.y(), (double) pd.x() );

	pa = head + axLen * QPointF( cos(tangent + M_PI / ArrowAngle) , sin(tangent + M_PI / ArrowAngle) );
	pb = head + axLen * QPointF( cos(tangent - M_PI / ArrowAngle) , sin(tangent - M_PI / ArrowAngle) );
	
	arr.push_back(pa);
	arr.push_back(head);
	arr.push_back(pb);
	
	painter->drawPolyline(&arr[0],3);
}

