
#ifndef CAMERA_MOTION_DLG_H
#define CAMERA_MOTION_DLG_H

#include <QDialog>
#include <QtGui>

QT_BEGIN_NAMESPACE
class QCheckBox;
class QLabel;
class QErrorMessage;
QT_END_NAMESPACE


class CamMotionScript{
public:
	CamMotionScript(){ IdxLn=-1; life = 1.0f;}
	void GetRatio(){
		Zoom_Ratio = (Zoom_end - Zoom_bgn)/life;
		Org_Ratio = (Org_end - Org_bgn)/life;
	}
	QString InfoStr(){
		QString R = QString("%0 : <%1> [%2 , %3] --|%4s|--> [%5 , %6] <%7>").
			arg(QString::number(IdxLn),
				QString::number(Zoom_bgn,'g',3),
				QString::number(Org_bgn.x(),'g',3), 
				QString::number(Org_bgn.y(),'g',3),
				QString::number(life,'g',3),
				QString::number(Org_end.x(),'g',3),
				QString::number(Org_end.y(),'g',3),
				QString::number(Zoom_end,'g',3)
				); 
		return R;
	}
	QString LineInfoStr(){
		QString R = QString("%0").
			arg(QString::number(IdxLn)); 
		return R;
	}
	QString BgnInfoStr(){
		QString R = QString("<%0> [%1 , %2]").
			arg(QString::number(Zoom_bgn,'g',3),
				QString::number(Org_bgn.x(),'g',3), 
				QString::number(Org_bgn.y(),'g',3)
				); 
		return R;
	}
	QString LifeInfoStr(){
		QString R = QString("%0s").
			arg(QString::number(life,'g',3));
		return R;
	}
	QString EndInfoStr(){
		QString R = QString("<%0> [%1 , %2]").
			arg(QString::number(Zoom_end,'g',3),
				QString::number(Org_end.x(),'g',3),
				QString::number(Org_end.y(),'g',3)
				); 
		return R;
	}
public:
	int IdxLn; //move cam after this line.
	float Zoom_bgn, Zoom_end;
	float Zoom_Ratio;
	QPointF Org_bgn, Org_end;
	QPointF Org_Ratio;
	float life;
};

class SketcherRenderer;

class CameraMotionDlg : public QDialog
{
    Q_OBJECT

public:
	CameraMotionDlg(QWidget *parent , SketcherRenderer* renderer);
	SketcherRenderer *m_renderer;	
	QTableView *m_ScriptTabView;
	QStandardItemModel *m_ScpListModel;

	int			 m_curScript;
	QLineEdit	*m_LifeEdt;
	QCheckBox	*m_SeeEndSceneCHK;
	QSlider		*m_NumLineSld;
	QGroupBox	*m_ShownLnGrp;

private slots:
	void Add();
	void Remove();
	void SetBegin();
    void SetEnd();
	void ModifyDurance();
    void LoadScript();
    void SaveScript();
	void SetScene(const QModelIndex & index);
public slots:
	void RefreshList();
	void setNumShownLn( int nL );
private:
    QCheckBox *native;
	QLabel *LineIdxLabel; 
	QLabel *RenderInfoLabel;
};

#endif
