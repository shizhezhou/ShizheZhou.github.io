
#include "CameraMotionDlg.h"
#include "sketcher.h"

#define MESSAGE \
    CameraMotionDlg::tr(" camera motion script system" \
						"Shizhe Zhou @ CityU HongKong/ZJU China" )\
               
               

CameraMotionDlg::CameraMotionDlg(QWidget *parent, SketcherRenderer* renderer)
    : QDialog(parent)
{
	m_renderer = renderer;
	///////////////////////
	m_ScriptTabView = new QTableView;
	m_ScriptTabView->setSortingEnabled(false);
	m_ScriptTabView->setAlternatingRowColors(true);

	m_ScpListModel = new QStandardItemModel(0, 4, this);

	m_ScpListModel->setHeaderData(0, Qt::Horizontal, QObject::tr("Line"));
	m_ScpListModel->setHeaderData(1, Qt::Horizontal, QObject::tr("Begin"));
	m_ScpListModel->setHeaderData(2, Qt::Horizontal, QObject::tr("Durance"));
	m_ScpListModel->setHeaderData(3, Qt::Horizontal, QObject::tr("End"));
	m_ScriptTabView->setModel(m_ScpListModel);
	m_ScriptTabView->setColumnWidth(0,30);
	m_ScriptTabView->setColumnWidth(1,168);
	m_ScriptTabView->setColumnWidth(2,55);
	m_ScriptTabView->setColumnWidth(3,168);
	m_ScriptTabView->setSelectionMode(QTableView::SingleSelection);
	m_ScriptTabView->setSelectionBehavior(QTableView::SelectRows);
	m_ScriptTabView->setEditTriggers(QTableView::NoEditTriggers);
	///////////////////////
		
	m_NumLineSld = new QSlider(Qt::Horizontal);
	m_NumLineSld->setMinimumWidth(100);
	m_NumLineSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
	m_NumLineSld->setEnabled(false);

	m_ShownLnGrp = new QGroupBox(tr("Numbers to Display:"));
	m_ShownLnGrp ->setAttribute(Qt::WA_ContentsPropagated);
	m_NumLineSld = new QSlider(Qt::Horizontal, m_ShownLnGrp);
	m_NumLineSld->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
	m_NumLineSld->setRange(0,0);	
	QGridLayout *ShownLnSzLayout = new QGridLayout(m_ShownLnGrp);
	ShownLnSzLayout->addWidget(m_NumLineSld,0,0);	
	m_ShownLnGrp->setMaximumHeight(58);

	if(m_renderer->m_nL){
		m_NumLineSld->setRange(0,m_renderer->m_nL);
		m_NumLineSld->setValue(m_renderer->m_nL);
		m_NumLineSld->setEnabled(true);
	}

	QPushButton *AddBtn = new QPushButton(tr("+"));
	AddBtn->setMaximumSize(50,30);
	QPushButton *RemoveBtn= new QPushButton(tr("-"));
	RemoveBtn->setMaximumSize(50,30);
	QPushButton *SetBgnBtn = new QPushButton(tr("Set Begin"));
	SetBgnBtn->setGeometry(105, 50, 60,30);
	QPushButton *SetEndBtn = new QPushButton(tr("Set End"));
	SetBgnBtn->setGeometry(250, 50, 60,30);
	QPushButton *FreshBtn = new QPushButton(tr("Refresh"));
	FreshBtn->setMaximumSize(50,30);

	QHBoxLayout *SetDuranceLayout = new QHBoxLayout();
	QLabel *SetDuranceLabel = new QLabel(tr("Set Durance:"));
	m_LifeEdt = new QLineEdit();
	
	m_LifeEdt->setMaximumSize(40,30);
	SetDuranceLayout->addStretch();
	SetDuranceLayout->addWidget(SetDuranceLabel);
	SetDuranceLayout->addWidget(m_LifeEdt);
	SetDuranceLayout->addStretch();

	QPushButton *LoadBtn = new QPushButton(tr("Load Script File"));
    QPushButton *SaveBtn = new QPushButton(tr("Save Script File"));

	connect(AddBtn,			SIGNAL(clicked()), this, SLOT(Add()));
	connect(RemoveBtn,		SIGNAL(clicked()), this, SLOT(Remove()));
	connect(m_NumLineSld,	SIGNAL(valueChanged(int)),	this, SLOT(setNumShownLn(int)));
    connect(SetBgnBtn,		SIGNAL(clicked()), this, SLOT(SetBegin()));
    connect(SetEndBtn,		SIGNAL(clicked()), this, SLOT(SetEnd()));
	connect(FreshBtn ,		SIGNAL(clicked()), this, SLOT(RefreshList()));
    connect(LoadBtn,		SIGNAL(clicked()), this, SLOT(LoadScript()));
	connect(SaveBtn,		SIGNAL(clicked()), this, SLOT(SaveScript()));
	connect(m_LifeEdt,		SIGNAL(textChanged(const QString &)), this, SLOT(ModifyDurance()));
	connect(m_ScriptTabView,SIGNAL(doubleClicked(const QModelIndex &)), this, SLOT(SetScene(const QModelIndex &)));

#ifndef Q_WS_WIN
#ifndef Q_OS_MAC
    native->hide();
#endif
#endif

	QHBoxLayout *layout1 = new QHBoxLayout ;
	layout1->addWidget(AddBtn);
	layout1->addWidget(m_ShownLnGrp);
	layout1->addWidget(RemoveBtn);

    QHBoxLayout *Alayout = new QHBoxLayout;
    Alayout->addWidget(SetBgnBtn);
	Alayout->addLayout(SetDuranceLayout);
    Alayout->addWidget(SetEndBtn);
	
	QHBoxLayout *Clayout = new QHBoxLayout;
    Clayout ->addWidget(LoadBtn);
    Clayout ->addWidget(SaveBtn);
    Clayout ->addWidget(FreshBtn);
	
	QVBoxLayout *Blayout = new QVBoxLayout;
	Blayout->addLayout(layout1);
	Blayout->addLayout(Alayout);
	Blayout->addWidget(m_ScriptTabView);
	Blayout->addLayout(Clayout);


	setLayout(Blayout);

    setWindowTitle(tr("Config Camera Motion"));

	resize(488,300);
	setMaximumSize(488,300);
	setMinimumSize(488,300);
}


void SetAllItemTextAlign(QStandardItemModel *model, int r, int c, Qt::Alignment alignment){
	model->item(r,c)->setTextAlignment(alignment);
}

void SetAllItemTextAlign(QStandardItemModel *model, Qt::Alignment alignment ){
	int nC = model->columnCount();
	int nR = model->rowCount();
	for (int i=0; i<nR; ++i)
	for (int j=0; j<nC; ++j)
		model->item(i,j)->setTextAlignment(alignment);
}

void InsertScript(QStandardItemModel *model, int nR, const QString &line, const QString &bgn,
			 const QString &durance, const QString &end)
{
	model->insertRow(nR);
	model->setData(model->index(nR, 0), line);
	model->setData(model->index(nR, 1), bgn);
	model->setData(model->index(nR, 2), durance);
	model->setData(model->index(nR, 3), end);
	SetAllItemTextAlign(model, Qt::AlignHCenter);
}

void CameraMotionDlg::Add(){
	int nR = m_ScpListModel->rowCount();
	if(m_renderer->m_nShownLn<1) return;
	CamMotionScript S;
	S.IdxLn = m_renderer->m_nShownLn-1;
	S.Org_bgn = LINE::m_origin;	S.Zoom_bgn = LINE::m_zoom;
	S.Org_end = S.Org_bgn;	S.Zoom_end = S.Zoom_bgn;
	S.GetRatio();

	m_renderer->m_Scripts.push_back(S);
	InsertScript(m_ScpListModel, nR, S.LineInfoStr(), S.BgnInfoStr(), S.LifeInfoStr(), S.EndInfoStr());
}

void CameraMotionDlg::Remove(){
	QModelIndex index = m_ScriptTabView->selectionModel()->currentIndex();

	int R = index.row();
	if(R>=0){
		m_ScpListModel->removeRow(R);
		m_renderer->m_Scripts.remove(R);
	}
}

void CameraMotionDlg::SetBegin()
{  
	QModelIndex index = m_ScriptTabView->selectionModel()->currentIndex();
	int R = index.row();
 	if(R<0)	return;
 	
	CamMotionScript &S = m_renderer->m_Scripts[R];
 	S.Org_bgn = LINE::m_origin;
 	S.Zoom_bgn = LINE::m_zoom;
	S.GetRatio();
	
	QStandardItem *item = m_ScpListModel->item(R,1);
	item->setText(S.BgnInfoStr());
}

void CameraMotionDlg::SetEnd()
{	
	QModelIndex index = m_ScriptTabView->selectionModel()->currentIndex();
	int R = index.row();
	if(R<0)	return;
	
	CamMotionScript &S = m_renderer->m_Scripts[R];
	S.Org_end = LINE::m_origin;
	S.Zoom_end = LINE::m_zoom;
	S.GetRatio();

	QStandardItem *item = m_ScpListModel->item(R,3);
	item->setText(S.EndInfoStr());
}

void CameraMotionDlg::ModifyDurance()
{
	QModelIndex index = m_ScriptTabView->selectionModel()->currentIndex();
	int R = index.row();
	
	if( R<0 || R>=m_ScpListModel->rowCount()) return;

	CamMotionScript &S = m_renderer->m_Scripts[R];
	S.life = m_LifeEdt->text().toFloat();
	S.GetRatio();

	m_ScpListModel->setData(m_ScpListModel->index(R, 2), S.LifeInfoStr());		
}

void CameraMotionDlg::RefreshList()
{
	m_ScpListModel->removeRows(0,m_ScpListModel->rowCount());
	for (int i=0; i<m_renderer->m_Scripts.size(); ++i){
		CamMotionScript &S = m_renderer->m_Scripts[i];
		InsertScript(m_ScpListModel, i, 
			S.LineInfoStr(), S.BgnInfoStr(),
			S.LifeInfoStr(), S.EndInfoStr());
	}
}

void CameraMotionDlg::SetScene(const QModelIndex & index)
{
	int R = index.row();	int C = index.column();
	if(m_renderer->m_Scripts[R].IdxLn+1>m_renderer->m_nL)
		return;

	m_renderer->m_nShownLn = m_renderer->m_Scripts[R].IdxLn+1;
	
	if(C==3){
		LINE::m_zoom = m_renderer->m_Scripts[R].Zoom_end;
		LINE::m_origin = m_renderer->m_Scripts[R].Org_end;
	}
	else if(C==1){
		LINE::m_zoom = m_renderer->m_Scripts[R].Zoom_bgn;
		LINE::m_origin = m_renderer->m_Scripts[R].Org_bgn;
	}
	
	m_renderer->m_bAnimating = true;
	m_renderer->pauseAnimation();
	m_renderer->updateContentForCamera();
	m_renderer->update();	
}

void CameraMotionDlg::LoadScript()
{
	QString currentPath = QFileDialog::getOpenFileName(this, 
		tr("Open Camera Motion Script File"), 
		tr(".\\ordering_results\\Storytelling\\story1\\script") , "*.scp");

	if(!currentPath.isEmpty()){
		QDir::setCurrent( QFileInfo(currentPath).absoluteDir().absolutePath());			
	}
	else return;

	std::string fn = q2s(currentPath);	const char* ch_filename = fn.c_str();

	FILE *fp;
	if( (fopen_s(&fp, ch_filename, "rt"))==NULL ){
		m_renderer->m_Scripts.clear();
		
		int nS;
		fscanf_s( fp, "%d\n", &nS);
		m_renderer->m_Scripts.clear();
		m_renderer->m_Scripts.resize(nS);

		for( int i=0; i<nS; i++ )
		{
			float bx, by , ex ,ey;
			CamMotionScript &S = m_renderer->m_Scripts[i];
			fscanf_s( fp, "%d %f %f %f %f %f %f %f\n", 
				&S.IdxLn,
 				&S.Zoom_bgn,	&S.Zoom_end,
 				&bx,	&by,
				&ex,	&ey,
 				&S.life
				);
			S.Org_bgn = QPointF(bx,by);
			S.Org_end = QPointF(ex,ey);
			S.GetRatio();
		
		}
		fclose(fp);
		RefreshList();
	}	
	
	if(m_renderer->m_Scripts[0].IdxLn+1>m_renderer->m_nL)
		return;
	m_renderer->m_nShownLn = m_renderer->m_Scripts[0].IdxLn+1;

	LINE::m_zoom = m_renderer->m_Scripts[0].Zoom_bgn;
	LINE::m_origin = m_renderer->m_Scripts[0].Org_bgn;

	m_renderer->m_bAnimating = true;
	m_renderer->pauseAnimation();
	m_renderer->updateContentForCamera();
	m_renderer->update();	
}

void CameraMotionDlg::SaveScript()
{
	int nS = m_renderer->m_Scripts.size(); if(nS==0) return;

	QString currentPath = QFileDialog::getSaveFileName(this, 
		tr("Save Camera Motion Script File"), 
		tr("D:\\Project\\LineOrdering\\Data\\example\\story telling 1\\script") , "*.scp");

	if(!currentPath.isEmpty()){
		QDir::setCurrent( QFileInfo(currentPath).absoluteDir().absolutePath());			
	}
	else return;
	
	std::string fn = q2s(currentPath);	const char* ch_filename = fn.c_str();

	FILE *fp;
	if( fopen_s(&fp, ch_filename, "wt") )	return;

	
	fprintf_s( fp, "%d\n", nS );

	for( int i=0; i<nS; i++ )
	{
		CamMotionScript &S = m_renderer->m_Scripts[i];
		fprintf_s( fp, "%d %f %f %f %f %f %f %f\n", 
			S.IdxLn,
			S.Zoom_bgn,	S.Zoom_end,
			S.Org_bgn.rx(),	S.Org_bgn.ry(),
			S.Org_end.rx(),	S.Org_end.ry(),
			S.life
			);
	}
	fclose(fp);
}

void CameraMotionDlg::setNumShownLn( int  sz )
{
	if(!m_renderer->m_bAnimating){
		m_ShownLnGrp->setTitle("Number to Display:" + QString::number(sz) );
	}
	else{
		if(sz>m_renderer->m_nL-1) return;
		m_ShownLnGrp->setTitle("Now drawing line " + QString::number(sz) );		

		for (int i=0; i<m_renderer->m_Scripts.size(); ++i)
		{
			if(m_renderer->m_Scripts[i].IdxLn>=m_renderer->m_skqingLnId){
				m_renderer->m_iterScript = &m_renderer->m_Scripts[i];
 				LINE::m_zoom = m_renderer->m_Scripts[i].Zoom_bgn;
 				LINE::m_origin = m_renderer->m_Scripts[i].Org_bgn;
				m_renderer->updateContentForCamera();
				break;
			}
		}
	}
	m_renderer->m_controller->m_NumShownLnSld->setValue(sz);
}