
#include "sketcher.h"
#include <QApplication>

int main(int argc, char **argv)
{
	QApplication app(argc, argv);
	app.setApplicationName("Sketcher");
	app.setQuitOnLastWindowClosed(true);

	SketcherWidget sketcherWidget(false);
	
    QStyle *arthurStyle = new ArthurStyle();
    sketcherWidget.setStyle(arthurStyle);

    QList<QWidget *> widgets = qFindChildren<QWidget *>(&sketcherWidget);
 
	foreach (QWidget *w, widgets)
		w->setStyle(arthurStyle);

	sketcherWidget.setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));

	sketcherWidget.show();
	//pathStrokeWidget.showFullScreen();

    return app.exec();
}
