This is the demo application for the paper : Efficient Simulation of Water Puddle(in Chinese). 
necessary runtime library: http://www.microsoft.com/en-us/download/details.aspx?id=40784

Usage:
left mouse button :  drag the underlying fluid particles
right mouse button :  rotate the 3d Scene.

Other requirements:
OpenGL version 330 (or higher);

Author: JianFang Li



